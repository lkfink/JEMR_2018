# 1 "csrc/eyelinkmodule_processed1.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "csrc/eyelinkmodule_processed1.c"
# 1 "csrc/eyelinkmodule.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "csrc/eyelinkmodule.c"
# 33 "csrc/eyelinkmodule.c"

# 1 "/usr/include/python2.7/Python.h" 1







# 1 "/usr/include/python2.7/patchlevel.h" 1
# 8 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/pyconfig.h" 1
# 9 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/pymacconfig.h" 1
# 10 "/usr/include/python2.7/Python.h" 2
# 19 "/usr/include/python2.7/Python.h"

# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include-fixed/limits.h" 1 3 4
# 11 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include-fixed/limits.h" 3 4

# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include-fixed/syslimits.h" 1 3 4







# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include-fixed/limits.h" 1 3 4
# 122 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include-fixed/limits.h" 3 4

# 1 "/usr/include/limits.h" 1 3 4
# 27 "/usr/include/limits.h" 3 4

# 1 "/usr/include/features.h" 1 3 4
# 322 "/usr/include/features.h" 3 4

# 1 "/usr/include/bits/predefs.h" 1 3 4
# 323 "/usr/include/features.h" 2 3 4
# 355 "/usr/include/features.h" 3 4

# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 353 "/usr/include/sys/cdefs.h" 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 354 "/usr/include/sys/cdefs.h" 2 3 4
# 356 "/usr/include/features.h" 2 3 4
# 387 "/usr/include/features.h" 3 4

# 1 "/usr/include/gnu/stubs.h" 1 3 4




# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 5 "/usr/include/gnu/stubs.h" 2 3 4



# 1 "/usr/include/gnu/stubs-32.h" 1 3 4
# 8 "/usr/include/gnu/stubs.h" 2 3 4
# 388 "/usr/include/features.h" 2 3 4
# 28 "/usr/include/limits.h" 2 3 4
# 145 "/usr/include/limits.h" 3 4

# 1 "/usr/include/bits/posix1_lim.h" 1 3 4
# 157 "/usr/include/bits/posix1_lim.h" 3 4

# 1 "/usr/include/bits/local_lim.h" 1 3 4
# 39 "/usr/include/bits/local_lim.h" 3 4

# 1 "/usr/include/linux/limits.h" 1 3 4
# 40 "/usr/include/bits/local_lim.h" 2 3 4
# 158 "/usr/include/bits/posix1_lim.h" 2 3 4
# 146 "/usr/include/limits.h" 2 3 4




# 1 "/usr/include/bits/posix2_lim.h" 1 3 4
# 150 "/usr/include/limits.h" 2 3 4




# 1 "/usr/include/bits/xopen_lim.h" 1 3 4
# 34 "/usr/include/bits/xopen_lim.h" 3 4

# 1 "/usr/include/bits/stdio_lim.h" 1 3 4
# 35 "/usr/include/bits/xopen_lim.h" 2 3 4
# 154 "/usr/include/limits.h" 2 3 4
# 123 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include-fixed/limits.h" 2 3 4
# 8 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include-fixed/syslimits.h" 2 3 4
# 12 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include-fixed/limits.h" 2 3 4
# 20 "/usr/include/python2.7/Python.h" 2
# 33 "/usr/include/python2.7/Python.h"

# 1 "/usr/include/stdio.h" 1 3 4
# 30 "/usr/include/stdio.h" 3 4





# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 1 3 4
# 211 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 3 4
typedef unsigned int size_t;
# 35 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/bits/types.h" 1 3 4
# 28 "/usr/include/bits/types.h" 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 29 "/usr/include/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;




__extension__ typedef signed long long int __int64_t;
__extension__ typedef unsigned long long int __uint64_t;







__extension__ typedef long long int __quad_t;
__extension__ typedef unsigned long long int __u_quad_t;
# 131 "/usr/include/bits/types.h" 3 4

# 1 "/usr/include/bits/typesizes.h" 1 3 4
# 132 "/usr/include/bits/types.h" 2 3 4


__extension__ typedef __u_quad_t __dev_t;
__extension__ typedef unsigned int __uid_t;
__extension__ typedef unsigned int __gid_t;
__extension__ typedef unsigned long int __ino_t;
__extension__ typedef __u_quad_t __ino64_t;
__extension__ typedef unsigned int __mode_t;
__extension__ typedef unsigned int __nlink_t;
__extension__ typedef long int __off_t;
__extension__ typedef __quad_t __off64_t;
__extension__ typedef int __pid_t;
__extension__ typedef struct { int __val[2]; } __fsid_t;
__extension__ typedef long int __clock_t;
__extension__ typedef unsigned long int __rlim_t;
__extension__ typedef __u_quad_t __rlim64_t;
__extension__ typedef unsigned int __id_t;
__extension__ typedef long int __time_t;
__extension__ typedef unsigned int __useconds_t;
__extension__ typedef long int __suseconds_t;

__extension__ typedef int __daddr_t;
__extension__ typedef long int __swblk_t;
__extension__ typedef int __key_t;


__extension__ typedef int __clockid_t;


__extension__ typedef void * __timer_t;


__extension__ typedef long int __blksize_t;




__extension__ typedef long int __blkcnt_t;
__extension__ typedef __quad_t __blkcnt64_t;


__extension__ typedef unsigned long int __fsblkcnt_t;
__extension__ typedef __u_quad_t __fsblkcnt64_t;


__extension__ typedef unsigned long int __fsfilcnt_t;
__extension__ typedef __u_quad_t __fsfilcnt64_t;

__extension__ typedef int __ssize_t;



typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;


__extension__ typedef int __intptr_t;


__extension__ typedef unsigned int __socklen_t;
# 37 "/usr/include/stdio.h" 2 3 4
# 45 "/usr/include/stdio.h" 3 4
struct _IO_FILE;



typedef struct _IO_FILE FILE;
# 65 "/usr/include/stdio.h" 3 4
typedef struct _IO_FILE __FILE;
# 75 "/usr/include/stdio.h" 3 4

# 1 "/usr/include/libio.h" 1 3 4
# 32 "/usr/include/libio.h" 3 4

# 1 "/usr/include/_G_config.h" 1 3 4
# 15 "/usr/include/_G_config.h" 3 4

# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 1 3 4
# 16 "/usr/include/_G_config.h" 2 3 4





# 1 "/usr/include/wchar.h" 1 3 4
# 83 "/usr/include/wchar.h" 3 4
typedef struct
{
  int __count;
  union
  {

    unsigned int __wch;



    char __wchb[4];
  } __value;
} __mbstate_t;
# 21 "/usr/include/_G_config.h" 2 3 4

typedef struct
{
  __off_t __pos;
  __mbstate_t __state;
} _G_fpos_t;
typedef struct
{
  __off64_t __pos;
  __mbstate_t __state;
} _G_fpos64_t;
# 53 "/usr/include/_G_config.h" 3 4
typedef int _G_int16_t __attribute__ ((__mode__ (__HI__)));
typedef int _G_int32_t __attribute__ ((__mode__ (__SI__)));
typedef unsigned int _G_uint16_t __attribute__ ((__mode__ (__HI__)));
typedef unsigned int _G_uint32_t __attribute__ ((__mode__ (__SI__)));
# 33 "/usr/include/libio.h" 2 3 4
# 53 "/usr/include/libio.h" 3 4

# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 54 "/usr/include/libio.h" 2 3 4
# 170 "/usr/include/libio.h" 3 4
struct _IO_jump_t; struct _IO_FILE;
# 180 "/usr/include/libio.h" 3 4
typedef void _IO_lock_t;





struct _IO_marker {
  struct _IO_marker *_next;
  struct _IO_FILE *_sbuf;



  int _pos;
# 203 "/usr/include/libio.h" 3 4
};


enum __codecvt_result
{
  __codecvt_ok,
  __codecvt_partial,
  __codecvt_error,
  __codecvt_noconv
};
# 271 "/usr/include/libio.h" 3 4
struct _IO_FILE {
  int _flags;




  char* _IO_read_ptr;
  char* _IO_read_end;
  char* _IO_read_base;
  char* _IO_write_base;
  char* _IO_write_ptr;
  char* _IO_write_end;
  char* _IO_buf_base;
  char* _IO_buf_end;

  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;



  int _flags2;

  __off_t _old_offset;



  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];



  _IO_lock_t *_lock;
# 319 "/usr/include/libio.h" 3 4
  __off64_t _offset;
# 328 "/usr/include/libio.h" 3 4
  void *__pad1;
  void *__pad2;
  void *__pad3;
  void *__pad4;
  size_t __pad5;

  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];

};


typedef struct _IO_FILE _IO_FILE;


struct _IO_FILE_plus;

extern struct _IO_FILE_plus _IO_2_1_stdin_;
extern struct _IO_FILE_plus _IO_2_1_stdout_;
extern struct _IO_FILE_plus _IO_2_1_stderr_;
# 364 "/usr/include/libio.h" 3 4
typedef __ssize_t __io_read_fn (void *__cookie, char *__buf, size_t __nbytes);







typedef __ssize_t __io_write_fn (void *__cookie, __const char *__buf,
     size_t __n);







typedef int __io_seek_fn (void *__cookie, __off64_t *__pos, int __w);


typedef int __io_close_fn (void *__cookie);




typedef __io_read_fn cookie_read_function_t;
typedef __io_write_fn cookie_write_function_t;
typedef __io_seek_fn cookie_seek_function_t;
typedef __io_close_fn cookie_close_function_t;


typedef struct
{
  __io_read_fn *read;
  __io_write_fn *write;
  __io_seek_fn *seek;
  __io_close_fn *close;
} _IO_cookie_io_functions_t;
typedef _IO_cookie_io_functions_t cookie_io_functions_t;

struct _IO_cookie_file;


extern void _IO_cookie_init (struct _IO_cookie_file *__cfile, int __read_write,
        void *__cookie, _IO_cookie_io_functions_t __fns);







extern int __underflow (_IO_FILE *);
extern int __uflow (_IO_FILE *);
extern int __overflow (_IO_FILE *, int);
# 460 "/usr/include/libio.h" 3 4
extern int _IO_getc (_IO_FILE *__fp);
extern int _IO_putc (int __c, _IO_FILE *__fp);
extern int _IO_feof (_IO_FILE *__fp) __attribute__ ((__nothrow__));
extern int _IO_ferror (_IO_FILE *__fp) __attribute__ ((__nothrow__));

extern int _IO_peekc_locked (_IO_FILE *__fp);





extern void _IO_flockfile (_IO_FILE *) __attribute__ ((__nothrow__));
extern void _IO_funlockfile (_IO_FILE *) __attribute__ ((__nothrow__));
extern int _IO_ftrylockfile (_IO_FILE *) __attribute__ ((__nothrow__));
# 490 "/usr/include/libio.h" 3 4
extern int _IO_vfscanf (_IO_FILE * __restrict, const char * __restrict,
   __gnuc_va_list, int *__restrict);
extern int _IO_vfprintf (_IO_FILE *__restrict, const char *__restrict,
    __gnuc_va_list);
extern __ssize_t _IO_padn (_IO_FILE *, int, __ssize_t);
extern size_t _IO_sgetn (_IO_FILE *, void *, size_t);

extern __off64_t _IO_seekoff (_IO_FILE *, __off64_t, int, int);
extern __off64_t _IO_seekpos (_IO_FILE *, __off64_t, int);

extern void _IO_free_backup_area (_IO_FILE *) __attribute__ ((__nothrow__));
# 76 "/usr/include/stdio.h" 2 3 4




typedef __gnuc_va_list va_list;
# 93 "/usr/include/stdio.h" 3 4
typedef __off64_t off_t;




typedef __off64_t off64_t;




typedef __ssize_t ssize_t;
# 113 "/usr/include/stdio.h" 3 4
typedef _G_fpos64_t fpos_t;



typedef _G_fpos64_t fpos64_t;
# 161 "/usr/include/stdio.h" 3 4

# 1 "/usr/include/bits/stdio_lim.h" 1 3 4
# 162 "/usr/include/stdio.h" 2 3 4



extern struct _IO_FILE *stdin;
extern struct _IO_FILE *stdout;
extern struct _IO_FILE *stderr;







extern int remove (__const char *__filename) __attribute__ ((__nothrow__));

extern int rename (__const char *__old, __const char *__new) __attribute__ ((__nothrow__));




extern int renameat (int __oldfd, __const char *__old, int __newfd,
       __const char *__new) __attribute__ ((__nothrow__));
# 195 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void) __asm__ ("" "tmpfile64") ;






extern FILE *tmpfile64 (void) ;



extern char *tmpnam (char *__s) __attribute__ ((__nothrow__)) ;





extern char *tmpnam_r (char *__s) __attribute__ ((__nothrow__)) ;
# 224 "/usr/include/stdio.h" 3 4
extern char *tempnam (__const char *__dir, __const char *__pfx)
     __attribute__ ((__nothrow__)) __attribute__ ((__malloc__)) ;
# 234 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream);




extern int fflush (FILE *__stream);
# 249 "/usr/include/stdio.h" 3 4
extern int fflush_unlocked (FILE *__stream);
# 259 "/usr/include/stdio.h" 3 4
extern int fcloseall (void);
# 280 "/usr/include/stdio.h" 3 4
extern FILE *fopen (__const char *__restrict __filename, __const char *__restrict __modes) __asm__ ("" "fopen64")

  ;
extern FILE *freopen (__const char *__restrict __filename, __const char *__restrict __modes, FILE *__restrict __stream) __asm__ ("" "freopen64")


  ;







extern FILE *fopen64 (__const char *__restrict __filename,
        __const char *__restrict __modes) ;
extern FILE *freopen64 (__const char *__restrict __filename,
   __const char *__restrict __modes,
   FILE *__restrict __stream) ;




extern FILE *fdopen (int __fd, __const char *__modes) __attribute__ ((__nothrow__)) ;





extern FILE *fopencookie (void *__restrict __magic_cookie,
     __const char *__restrict __modes,
     _IO_cookie_io_functions_t __io_funcs) __attribute__ ((__nothrow__)) ;




extern FILE *fmemopen (void *__s, size_t __len, __const char *__modes)
  __attribute__ ((__nothrow__)) ;




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__)) ;






extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__));





extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__));


extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__));
# 353 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *__restrict __stream,
      __const char *__restrict __format, ...);




extern int printf (__const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      __const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, __const char *__restrict __format,
       __gnuc_va_list __arg);




extern int vprintf (__const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, __const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));





extern int snprintf (char *__restrict __s, size_t __maxlen,
       __const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        __const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));






extern int vasprintf (char **__restrict __ptr, __const char *__restrict __f,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0))) ;
extern int __asprintf (char **__restrict __ptr,
         __const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;
extern int asprintf (char **__restrict __ptr,
       __const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;
# 414 "/usr/include/stdio.h" 3 4
extern int vdprintf (int __fd, __const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, __const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));
# 427 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *__restrict __stream,
     __const char *__restrict __format, ...) ;




extern int scanf (__const char *__restrict __format, ...) ;

extern int sscanf (__const char *__restrict __s,
     __const char *__restrict __format, ...) __attribute__ ((__nothrow__));
# 465 "/usr/include/stdio.h" 3 4
# 473 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, __const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) ;





extern int vscanf (__const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


extern int vsscanf (__const char *__restrict __s,
      __const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__scanf__, 2, 0)));
# 524 "/usr/include/stdio.h" 3 4
# 533 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream);
extern int getc (FILE *__stream);





extern int getchar (void);
# 552 "/usr/include/stdio.h" 3 4
extern int getc_unlocked (FILE *__stream);
extern int getchar_unlocked (void);
# 563 "/usr/include/stdio.h" 3 4
extern int fgetc_unlocked (FILE *__stream);
# 575 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream);
extern int putc (int __c, FILE *__stream);





extern int putchar (int __c);
# 596 "/usr/include/stdio.h" 3 4
extern int fputc_unlocked (int __c, FILE *__stream);







extern int putc_unlocked (int __c, FILE *__stream);
extern int putchar_unlocked (int __c);






extern int getw (FILE *__stream);


extern int putw (int __w, FILE *__stream);
# 624 "/usr/include/stdio.h" 3 4
extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     ;






extern char *gets (char *__s) ;
# 642 "/usr/include/stdio.h" 3 4
extern char *fgets_unlocked (char *__restrict __s, int __n,
        FILE *__restrict __stream) ;
# 658 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
          size_t *__restrict __n, int __delimiter,
          FILE *__restrict __stream) ;
extern __ssize_t getdelim (char **__restrict __lineptr,
        size_t *__restrict __n, int __delimiter,
        FILE *__restrict __stream) ;







extern __ssize_t getline (char **__restrict __lineptr,
       size_t *__restrict __n,
       FILE *__restrict __stream) ;
# 682 "/usr/include/stdio.h" 3 4
extern int fputs (__const char *__restrict __s, FILE *__restrict __stream);





extern int puts (__const char *__s);






extern int ungetc (int __c, FILE *__stream);






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream) ;




extern size_t fwrite (__const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s);
# 719 "/usr/include/stdio.h" 3 4
extern int fputs_unlocked (__const char *__restrict __s,
      FILE *__restrict __stream);
# 730 "/usr/include/stdio.h" 3 4
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream) ;
extern size_t fwrite_unlocked (__const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream);
# 742 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence);




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream);
# 774 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off64_t __off, int __whence) __asm__ ("" "fseeko64");


extern __off64_t ftello (FILE *__stream) __asm__ ("" "ftello64");
# 799 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos) __asm__ ("" "fgetpos64");

extern int fsetpos (FILE *__stream, __const fpos_t *__pos) __asm__ ("" "fsetpos64");
# 811 "/usr/include/stdio.h" 3 4
extern int fseeko64 (FILE *__stream, __off64_t __off, int __whence);
extern __off64_t ftello64 (FILE *__stream) ;
extern int fgetpos64 (FILE *__restrict __stream, fpos64_t *__restrict __pos);
extern int fsetpos64 (FILE *__stream, __const fpos64_t *__pos);




extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__)) ;

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__)) ;




extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__)) ;
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__)) ;
# 839 "/usr/include/stdio.h" 3 4
extern void perror (__const char *__s);







# 1 "/usr/include/bits/sys_errlist.h" 1 3 4
# 27 "/usr/include/bits/sys_errlist.h" 3 4
extern int sys_nerr;
extern __const char *__const sys_errlist[];


extern int _sys_nerr;
extern __const char *__const _sys_errlist[];
# 847 "/usr/include/stdio.h" 2 3 4




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__)) ;




extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__)) ;
# 866 "/usr/include/stdio.h" 3 4
extern FILE *popen (__const char *__command, __const char *__modes) ;





extern int pclose (FILE *__stream);





extern char *ctermid (char *__s) __attribute__ ((__nothrow__));





extern char *cuserid (char *__s);




struct obstack;


extern int obstack_printf (struct obstack *__restrict __obstack,
      __const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3)));
extern int obstack_vprintf (struct obstack *__restrict __obstack,
       __const char *__restrict __format,
       __gnuc_va_list __args)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0)));







extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__)) ;


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__));
# 936 "/usr/include/stdio.h" 3 4
# 34 "/usr/include/python2.7/Python.h" 2





# 1 "/usr/include/string.h" 1 3 4
# 29 "/usr/include/string.h" 3 4






# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 1 3 4
# 35 "/usr/include/string.h" 2 3 4
# 44 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest,
       __const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, __const void *__src, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));






extern void *memccpy (void *__restrict __dest, __const void *__restrict __src,
        int __c, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (__const void *__s1, __const void *__s2, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 95 "/usr/include/string.h" 3 4
extern void *memchr (__const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 109 "/usr/include/string.h" 3 4
extern void *rawmemchr (__const void *__s, int __c)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *memrchr (__const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern char *strcpy (char *__restrict __dest, __const char *__restrict __src)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        __const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, __const char *__restrict __src)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, __const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (__const char *__s1, __const char *__s2)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (__const char *__s1, __const char *__s2, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (__const char *__s1, __const char *__s2)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         __const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));







# 1 "/usr/include/xlocale.h" 1 3 4
# 28 "/usr/include/xlocale.h" 3 4
typedef struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
} *__locale_t;


typedef __locale_t locale_t;
# 163 "/usr/include/string.h" 2 3 4


extern int strcoll_l (__const char *__s1, __const char *__s2, __locale_t __l)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));

extern size_t strxfrm_l (char *__dest, __const char *__src, size_t __n,
    __locale_t __l) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2, 4)));





extern char *strdup (__const char *__s)
     __attribute__ ((__nothrow__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (__const char *__string, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 210 "/usr/include/string.h" 3 4
# 235 "/usr/include/string.h" 3 4
extern char *strchr (__const char *__s, int __c)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 262 "/usr/include/string.h" 3 4
extern char *strrchr (__const char *__s, int __c)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 276 "/usr/include/string.h" 3 4
extern char *strchrnul (__const char *__s, int __c)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern size_t strcspn (__const char *__s, __const char *__reject)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (__const char *__s, __const char *__accept)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 314 "/usr/include/string.h" 3 4
extern char *strpbrk (__const char *__s, __const char *__accept)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 342 "/usr/include/string.h" 3 4
extern char *strstr (__const char *__haystack, __const char *__needle)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, __const char *__restrict __delim)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));




extern char *__strtok_r (char *__restrict __s,
    __const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, __const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2, 3)));
# 373 "/usr/include/string.h" 3 4
extern char *strcasestr (__const char *__haystack, __const char *__needle)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (__const void *__haystack, size_t __haystacklen,
       __const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)));



extern void *__mempcpy (void *__restrict __dest,
   __const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        __const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));





extern size_t strlen (__const char *__s)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strnlen (__const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern char *strerror (int __errnum) __attribute__ ((__nothrow__));
# 438 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));





extern char *strerror_l (int __errnum, __locale_t __l) __attribute__ ((__nothrow__));





extern void __bzero (void *__s, size_t __n) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));



extern void bcopy (__const void *__src, void *__dest, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int bcmp (__const void *__s1, __const void *__s2, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 489 "/usr/include/string.h" 3 4
extern char *index (__const char *__s, int __c)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 517 "/usr/include/string.h" 3 4
extern char *rindex (__const char *__s, int __c)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern int ffs (int __i) __attribute__ ((__nothrow__)) __attribute__ ((__const__));




extern int ffsl (long int __l) __attribute__ ((__nothrow__)) __attribute__ ((__const__));

__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__)) __attribute__ ((__const__));




extern int strcasecmp (__const char *__s1, __const char *__s2)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (__const char *__s1, __const char *__s2, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));





extern int strcasecmp_l (__const char *__s1, __const char *__s2,
    __locale_t __loc)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));

extern int strncasecmp_l (__const char *__s1, __const char *__s2,
     size_t __n, __locale_t __loc)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));





extern char *strsep (char **__restrict __stringp,
       __const char *__restrict __delim)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__));


extern char *__stpcpy (char *__restrict __dest, __const char *__restrict __src)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, __const char *__restrict __src)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   __const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        __const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));




extern int strverscmp (__const char *__s1, __const char *__s2)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
# 606 "/usr/include/string.h" 3 4
extern char *basename (__const char *__filename) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
# 646 "/usr/include/string.h" 3 4
# 39 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/errno.h" 1 3 4
# 32 "/usr/include/errno.h" 3 4





# 1 "/usr/include/bits/errno.h" 1 3 4
# 25 "/usr/include/bits/errno.h" 3 4

# 1 "/usr/include/linux/errno.h" 1 3 4




# 1 "/usr/include/asm/errno.h" 1 3 4

# 1 "/usr/include/asm-generic/errno.h" 1 3 4




# 1 "/usr/include/asm-generic/errno-base.h" 1 3 4
# 5 "/usr/include/asm-generic/errno.h" 2 3 4
# 1 "/usr/include/asm/errno.h" 2 3 4
# 5 "/usr/include/linux/errno.h" 2 3 4
# 26 "/usr/include/bits/errno.h" 2 3 4
# 47 "/usr/include/bits/errno.h" 3 4
extern int *__errno_location (void) __attribute__ ((__nothrow__)) __attribute__ ((__const__));
# 37 "/usr/include/errno.h" 2 3 4
# 55 "/usr/include/errno.h" 3 4
extern char *program_invocation_name, *program_invocation_short_name;
# 69 "/usr/include/errno.h" 3 4
typedef int error_t;
# 41 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/stdlib.h" 1 3 4
# 33 "/usr/include/stdlib.h" 3 4

# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 1 3 4
# 323 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 3 4
typedef int wchar_t;
# 34 "/usr/include/stdlib.h" 2 3 4
# 43 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/bits/waitflags.h" 1 3 4
# 43 "/usr/include/stdlib.h" 2 3 4

# 1 "/usr/include/bits/waitstatus.h" 1 3 4
# 65 "/usr/include/bits/waitstatus.h" 3 4

# 1 "/usr/include/endian.h" 1 3 4
# 37 "/usr/include/endian.h" 3 4

# 1 "/usr/include/bits/endian.h" 1 3 4
# 38 "/usr/include/endian.h" 2 3 4
# 61 "/usr/include/endian.h" 3 4

# 1 "/usr/include/bits/byteswap.h" 1 3 4
# 28 "/usr/include/bits/byteswap.h" 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 29 "/usr/include/bits/byteswap.h" 2 3 4
# 62 "/usr/include/endian.h" 2 3 4
# 66 "/usr/include/bits/waitstatus.h" 2 3 4

union wait
  {
    int w_status;
    struct
      {

 unsigned int __w_termsig:7;
 unsigned int __w_coredump:1;
 unsigned int __w_retcode:8;
 unsigned int:16;







      } __wait_terminated;
    struct
      {

 unsigned int __w_stopval:8;
 unsigned int __w_stopsig:8;
 unsigned int:16;






      } __wait_stopped;
  };
# 44 "/usr/include/stdlib.h" 2 3 4
# 68 "/usr/include/stdlib.h" 3 4
typedef union
  {
    union wait *__uptr;
    int *__iptr;
  } __WAIT_STATUS __attribute__ ((__transparent_union__));
# 96 "/usr/include/stdlib.h" 3 4


typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;







__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 140 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__)) ;




extern double atof (__const char *__nptr)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (__const char *__nptr)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (__const char *__nptr)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





__extension__ extern long long int atoll (__const char *__nptr)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





extern double strtod (__const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;





extern float strtof (__const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;

extern long double strtold (__const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;





extern long int strtol (__const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;

extern unsigned long int strtoul (__const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;




__extension__
extern long long int strtoq (__const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;

__extension__
extern unsigned long long int strtouq (__const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;





__extension__
extern long long int strtoll (__const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;

__extension__
extern unsigned long long int strtoull (__const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;
# 240 "/usr/include/stdlib.h" 3 4
extern long int strtol_l (__const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     __locale_t __loc) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 4))) ;

extern unsigned long int strtoul_l (__const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, __locale_t __loc)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 4))) ;

__extension__
extern long long int strtoll_l (__const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    __locale_t __loc)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 4))) ;

__extension__
extern unsigned long long int strtoull_l (__const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, __locale_t __loc)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 4))) ;

extern double strtod_l (__const char *__restrict __nptr,
   char **__restrict __endptr, __locale_t __loc)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3))) ;

extern float strtof_l (__const char *__restrict __nptr,
         char **__restrict __endptr, __locale_t __loc)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3))) ;

extern long double strtold_l (__const char *__restrict __nptr,
         char **__restrict __endptr,
         __locale_t __loc)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3))) ;
# 311 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__)) ;


extern long int a64l (__const char *__s)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;





# 1 "/usr/include/sys/types.h" 1 3 4
# 28 "/usr/include/sys/types.h" 3 4






typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;




typedef __loff_t loff_t;





typedef __ino64_t ino_t;




typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;
# 99 "/usr/include/sys/types.h" 3 4
typedef __pid_t pid_t;





typedef __id_t id_t;
# 116 "/usr/include/sys/types.h" 3 4
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;
# 133 "/usr/include/sys/types.h" 3 4

# 1 "/usr/include/time.h" 1 3 4
# 58 "/usr/include/time.h" 3 4


typedef __clock_t clock_t;
# 74 "/usr/include/time.h" 3 4


typedef __time_t time_t;
# 92 "/usr/include/time.h" 3 4
typedef __clockid_t clockid_t;
# 104 "/usr/include/time.h" 3 4
typedef __timer_t timer_t;
# 134 "/usr/include/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;






# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 1 3 4
# 148 "/usr/include/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;
# 195 "/usr/include/sys/types.h" 3 4
typedef int int8_t __attribute__ ((__mode__ (__QI__)));
typedef int int16_t __attribute__ ((__mode__ (__HI__)));
typedef int int32_t __attribute__ ((__mode__ (__SI__)));
typedef int int64_t __attribute__ ((__mode__ (__DI__)));


typedef unsigned int u_int8_t __attribute__ ((__mode__ (__QI__)));
typedef unsigned int u_int16_t __attribute__ ((__mode__ (__HI__)));
typedef unsigned int u_int32_t __attribute__ ((__mode__ (__SI__)));
typedef unsigned int u_int64_t __attribute__ ((__mode__ (__DI__)));

typedef int register_t __attribute__ ((__mode__ (__word__)));
# 220 "/usr/include/sys/types.h" 3 4

# 1 "/usr/include/sys/select.h" 1 3 4
# 31 "/usr/include/sys/select.h" 3 4

# 1 "/usr/include/bits/select.h" 1 3 4
# 23 "/usr/include/bits/select.h" 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 24 "/usr/include/bits/select.h" 2 3 4
# 32 "/usr/include/sys/select.h" 2 3 4



# 1 "/usr/include/bits/sigset.h" 1 3 4
# 24 "/usr/include/bits/sigset.h" 3 4
typedef int __sig_atomic_t;




typedef struct
  {
    unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
  } __sigset_t;
# 35 "/usr/include/sys/select.h" 2 3 4



typedef __sigset_t sigset_t;






# 1 "/usr/include/time.h" 1 3 4
# 120 "/usr/include/time.h" 3 4
struct timespec
  {
    __time_t tv_sec;
    long int tv_nsec;
  };
# 45 "/usr/include/sys/select.h" 2 3 4


# 1 "/usr/include/bits/time.h" 1 3 4
# 75 "/usr/include/bits/time.h" 3 4
struct timeval
  {
    __time_t tv_sec;
    __suseconds_t tv_usec;
  };
# 47 "/usr/include/sys/select.h" 2 3 4
# 55 "/usr/include/sys/select.h" 3 4
typedef long int __fd_mask;
# 67 "/usr/include/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 99 "/usr/include/sys/select.h" 3 4
# 109 "/usr/include/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 121 "/usr/include/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 221 "/usr/include/sys/types.h" 2 3 4



# 1 "/usr/include/sys/sysmacros.h" 1 3 4
# 30 "/usr/include/sys/sysmacros.h" 3 4
__extension__
extern unsigned int gnu_dev_major (unsigned long long int __dev)
     __attribute__ ((__nothrow__));
__extension__
extern unsigned int gnu_dev_minor (unsigned long long int __dev)
     __attribute__ ((__nothrow__));
__extension__
extern unsigned long long int gnu_dev_makedev (unsigned int __major,
            unsigned int __minor)
     __attribute__ ((__nothrow__));
# 224 "/usr/include/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;
# 249 "/usr/include/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt_t;



typedef __fsblkcnt64_t fsblkcnt_t;



typedef __fsfilcnt64_t fsfilcnt_t;





typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;






# 1 "/usr/include/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/bits/pthreadtypes.h" 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 24 "/usr/include/bits/pthreadtypes.h" 2 3 4
# 50 "/usr/include/bits/pthreadtypes.h" 3 4
typedef unsigned long int pthread_t;


typedef union
{
  char __size[36];
  long int __align;
} pthread_attr_t;
# 67 "/usr/include/bits/pthreadtypes.h" 3 4
typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;





typedef union
{
  struct __pthread_mutex_s
  {
    int __lock;
    unsigned int __count;
    int __owner;





    int __kind;





    unsigned int __nusers;
    __extension__ union
    {
      int __spins;
      __pthread_slist_t __list;
    };

  } __data;
  char __size[24];
  long int __align;
} pthread_mutex_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  struct
  {
    int __lock;
    unsigned int __futex;
    __extension__ unsigned long long int __total_seq;
    __extension__ unsigned long long int __wakeup_seq;
    __extension__ unsigned long long int __woken_seq;
    void *__mutex;
    unsigned int __nwaiters;
    unsigned int __broadcast_seq;
  } __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;





typedef union
{
# 170 "/usr/include/bits/pthreadtypes.h" 3 4
  struct
  {
    int __lock;
    unsigned int __nr_readers;
    unsigned int __readers_wakeup;
    unsigned int __writer_wakeup;
    unsigned int __nr_readers_queued;
    unsigned int __nr_writers_queued;


    unsigned char __flags;
    unsigned char __shared;
    unsigned char __pad1;
    unsigned char __pad2;
    int __writer;
  } __data;

  char __size[32];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[20];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;
# 272 "/usr/include/sys/types.h" 2 3 4
# 321 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));






extern int rand (void) __attribute__ ((__nothrow__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__));




extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__));







extern double drand48 (void) __attribute__ ((__nothrow__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    unsigned long long int __a;
  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
# 471 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size) __attribute__ ((__nothrow__)) __attribute__ ((__malloc__)) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__)) __attribute__ ((__malloc__)) ;
# 485 "/usr/include/stdlib.h" 3 4
extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__)) __attribute__ ((__warn_unused_result__));

extern void free (void *__ptr) __attribute__ ((__nothrow__));




extern void cfree (void *__ptr) __attribute__ ((__nothrow__));




# 1 "/usr/include/alloca.h" 1 3 4
# 25 "/usr/include/alloca.h" 3 4

# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 1 3 4
# 26 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__));
# 498 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__)) __attribute__ ((__malloc__)) ;




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;




extern void abort (void) __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
# 528 "/usr/include/stdlib.h" 3 4
extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));







extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern void exit (int __status) __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));







extern void quick_exit (int __status) __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));







extern void _Exit (int __status) __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));






extern char *getenv (__const char *__name) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;




extern char *__secure_getenv (__const char *__name)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;





extern int putenv (char *__string) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (__const char *__name, __const char *__value, int __replace)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (__const char *__name) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__));
# 606 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;
# 623 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __asm__ ("" "mkstemp64")
     __attribute__ ((__nonnull__ (1))) ;





extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 645 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __asm__ ("" "mkstemps64") __attribute__ ((__nonnull__ (1))) ;






extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) ;
# 663 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;
# 677 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __asm__ ("" "mkostemp64")
     __attribute__ ((__nonnull__ (1))) ;





extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
# 698 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags) __asm__ ("" "mkostemps64")

     __attribute__ ((__nonnull__ (1))) ;





extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
# 717 "/usr/include/stdlib.h" 3 4
extern int system (__const char *__command) ;






extern char *canonicalize_file_name (__const char *__name)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;
# 734 "/usr/include/stdlib.h" 3 4
extern char *realpath (__const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__)) ;






typedef int (*__compar_fn_t) (__const void *, __const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (__const void *, __const void *, void *);





extern void *bsearch (__const void *__key, __const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;



extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)) ;



__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__)) __attribute__ ((__const__)) ;







extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__)) __attribute__ ((__const__)) ;




__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__)) __attribute__ ((__const__)) ;
# 808 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3))) ;




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3))) ;




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3, 4, 5)));







extern int mblen (__const char *__s, size_t __n) __attribute__ ((__nothrow__)) ;


extern int mbtowc (wchar_t *__restrict __pwc,
     __const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__)) ;


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__)) ;



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   __const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__));

extern size_t wcstombs (char *__restrict __s,
   __const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__));
# 885 "/usr/include/stdlib.h" 3 4
extern int rpmatch (__const char *__response) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;
# 896 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *__const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;





extern void setkey (__const char *__key) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));







extern int posix_openpt (int __oflag) ;







extern int grantpt (int __fd) __attribute__ ((__nothrow__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__)) ;






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
# 964 "/usr/include/stdlib.h" 3 4
# 43 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/unistd.h" 1 3 4
# 28 "/usr/include/unistd.h" 3 4
# 203 "/usr/include/unistd.h" 3 4

# 1 "/usr/include/bits/posix_opt.h" 1 3 4
# 204 "/usr/include/unistd.h" 2 3 4




# 1 "/usr/include/bits/environments.h" 1 3 4
# 23 "/usr/include/bits/environments.h" 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 24 "/usr/include/bits/environments.h" 2 3 4
# 208 "/usr/include/unistd.h" 2 3 4
# 227 "/usr/include/unistd.h" 3 4

# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 1 3 4
# 228 "/usr/include/unistd.h" 2 3 4
# 268 "/usr/include/unistd.h" 3 4
typedef __intptr_t intptr_t;






typedef __socklen_t socklen_t;
# 288 "/usr/include/unistd.h" 3 4
extern int access (__const char *__name, int __type) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int euidaccess (__const char *__name, int __type)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int eaccess (__const char *__name, int __type)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern int faccessat (int __fd, __const char *__file, int __type, int __flag)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2))) ;
# 334 "/usr/include/unistd.h" 3 4
extern __off64_t lseek (int __fd, __off64_t __offset, int __whence) __asm__ ("" "lseek64") __attribute__ ((__nothrow__));







extern __off64_t lseek64 (int __fd, __off64_t __offset, int __whence)
     __attribute__ ((__nothrow__));






extern int close (int __fd);






extern ssize_t read (int __fd, void *__buf, size_t __nbytes) ;





extern ssize_t write (int __fd, __const void *__buf, size_t __n) ;
# 385 "/usr/include/unistd.h" 3 4
extern ssize_t pread (int __fd, void *__buf, size_t __nbytes, __off64_t __offset) __asm__ ("" "pread64") ;


extern ssize_t pwrite (int __fd, __const void *__buf, size_t __nbytes, __off64_t __offset) __asm__ ("" "pwrite64") ;
# 401 "/usr/include/unistd.h" 3 4
extern ssize_t pread64 (int __fd, void *__buf, size_t __nbytes,
   __off64_t __offset) ;


extern ssize_t pwrite64 (int __fd, __const void *__buf, size_t __n,
    __off64_t __offset) ;







extern int pipe (int __pipedes[2]) __attribute__ ((__nothrow__)) ;




extern int pipe2 (int __pipedes[2], int __flags) __attribute__ ((__nothrow__)) ;
# 429 "/usr/include/unistd.h" 3 4
extern unsigned int alarm (unsigned int __seconds) __attribute__ ((__nothrow__));
# 441 "/usr/include/unistd.h" 3 4
extern unsigned int sleep (unsigned int __seconds);







extern __useconds_t ualarm (__useconds_t __value, __useconds_t __interval)
     __attribute__ ((__nothrow__));






extern int usleep (__useconds_t __useconds);
# 466 "/usr/include/unistd.h" 3 4
extern int pause (void);



extern int chown (__const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;



extern int fchown (int __fd, __uid_t __owner, __gid_t __group) __attribute__ ((__nothrow__)) ;




extern int lchown (__const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;






extern int fchownat (int __fd, __const char *__file, __uid_t __owner,
       __gid_t __group, int __flag)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2))) ;



extern int chdir (__const char *__path) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;



extern int fchdir (int __fd) __attribute__ ((__nothrow__)) ;
# 508 "/usr/include/unistd.h" 3 4
extern char *getcwd (char *__buf, size_t __size) __attribute__ ((__nothrow__)) ;





extern char *get_current_dir_name (void) __attribute__ ((__nothrow__));







extern char *getwd (char *__buf)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__)) ;




extern int dup (int __fd) __attribute__ ((__nothrow__)) ;


extern int dup2 (int __fd, int __fd2) __attribute__ ((__nothrow__));




extern int dup3 (int __fd, int __fd2, int __flags) __attribute__ ((__nothrow__));



extern char **__environ;

extern char **environ;





extern int execve (__const char *__path, char *__const __argv[],
     char *__const __envp[]) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));




extern int fexecve (int __fd, char *__const __argv[], char *__const __envp[])
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));




extern int execv (__const char *__path, char *__const __argv[])
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));



extern int execle (__const char *__path, __const char *__arg, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));



extern int execl (__const char *__path, __const char *__arg, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));



extern int execvp (__const char *__file, char *__const __argv[])
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));




extern int execlp (__const char *__file, __const char *__arg, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));




extern int execvpe (__const char *__file, char *__const __argv[],
      char *__const __envp[])
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));





extern int nice (int __inc) __attribute__ ((__nothrow__)) ;




extern void _exit (int __status) __attribute__ ((__noreturn__));






# 1 "/usr/include/bits/confname.h" 1 3 4
# 26 "/usr/include/bits/confname.h" 3 4
enum
  {
    _PC_LINK_MAX,

    _PC_MAX_CANON,

    _PC_MAX_INPUT,

    _PC_NAME_MAX,

    _PC_PATH_MAX,

    _PC_PIPE_BUF,

    _PC_CHOWN_RESTRICTED,

    _PC_NO_TRUNC,

    _PC_VDISABLE,

    _PC_SYNC_IO,

    _PC_ASYNC_IO,

    _PC_PRIO_IO,

    _PC_SOCK_MAXBUF,

    _PC_FILESIZEBITS,

    _PC_REC_INCR_XFER_SIZE,

    _PC_REC_MAX_XFER_SIZE,

    _PC_REC_MIN_XFER_SIZE,

    _PC_REC_XFER_ALIGN,

    _PC_ALLOC_SIZE_MIN,

    _PC_SYMLINK_MAX,

    _PC_2_SYMLINKS

  };


enum
  {
    _SC_ARG_MAX,

    _SC_CHILD_MAX,

    _SC_CLK_TCK,

    _SC_NGROUPS_MAX,

    _SC_OPEN_MAX,

    _SC_STREAM_MAX,

    _SC_TZNAME_MAX,

    _SC_JOB_CONTROL,

    _SC_SAVED_IDS,

    _SC_REALTIME_SIGNALS,

    _SC_PRIORITY_SCHEDULING,

    _SC_TIMERS,

    _SC_ASYNCHRONOUS_IO,

    _SC_PRIORITIZED_IO,

    _SC_SYNCHRONIZED_IO,

    _SC_FSYNC,

    _SC_MAPPED_FILES,

    _SC_MEMLOCK,

    _SC_MEMLOCK_RANGE,

    _SC_MEMORY_PROTECTION,

    _SC_MESSAGE_PASSING,

    _SC_SEMAPHORES,

    _SC_SHARED_MEMORY_OBJECTS,

    _SC_AIO_LISTIO_MAX,

    _SC_AIO_MAX,

    _SC_AIO_PRIO_DELTA_MAX,

    _SC_DELAYTIMER_MAX,

    _SC_MQ_OPEN_MAX,

    _SC_MQ_PRIO_MAX,

    _SC_VERSION,

    _SC_PAGESIZE,


    _SC_RTSIG_MAX,

    _SC_SEM_NSEMS_MAX,

    _SC_SEM_VALUE_MAX,

    _SC_SIGQUEUE_MAX,

    _SC_TIMER_MAX,




    _SC_BC_BASE_MAX,

    _SC_BC_DIM_MAX,

    _SC_BC_SCALE_MAX,

    _SC_BC_STRING_MAX,

    _SC_COLL_WEIGHTS_MAX,

    _SC_EQUIV_CLASS_MAX,

    _SC_EXPR_NEST_MAX,

    _SC_LINE_MAX,

    _SC_RE_DUP_MAX,

    _SC_CHARCLASS_NAME_MAX,


    _SC_2_VERSION,

    _SC_2_C_BIND,

    _SC_2_C_DEV,

    _SC_2_FORT_DEV,

    _SC_2_FORT_RUN,

    _SC_2_SW_DEV,

    _SC_2_LOCALEDEF,


    _SC_PII,

    _SC_PII_XTI,

    _SC_PII_SOCKET,

    _SC_PII_INTERNET,

    _SC_PII_OSI,

    _SC_POLL,

    _SC_SELECT,

    _SC_UIO_MAXIOV,

    _SC_IOV_MAX = _SC_UIO_MAXIOV,

    _SC_PII_INTERNET_STREAM,

    _SC_PII_INTERNET_DGRAM,

    _SC_PII_OSI_COTS,

    _SC_PII_OSI_CLTS,

    _SC_PII_OSI_M,

    _SC_T_IOV_MAX,



    _SC_THREADS,

    _SC_THREAD_SAFE_FUNCTIONS,

    _SC_GETGR_R_SIZE_MAX,

    _SC_GETPW_R_SIZE_MAX,

    _SC_LOGIN_NAME_MAX,

    _SC_TTY_NAME_MAX,

    _SC_THREAD_DESTRUCTOR_ITERATIONS,

    _SC_THREAD_KEYS_MAX,

    _SC_THREAD_STACK_MIN,

    _SC_THREAD_THREADS_MAX,

    _SC_THREAD_ATTR_STACKADDR,

    _SC_THREAD_ATTR_STACKSIZE,

    _SC_THREAD_PRIORITY_SCHEDULING,

    _SC_THREAD_PRIO_INHERIT,

    _SC_THREAD_PRIO_PROTECT,

    _SC_THREAD_PROCESS_SHARED,


    _SC_NPROCESSORS_CONF,

    _SC_NPROCESSORS_ONLN,

    _SC_PHYS_PAGES,

    _SC_AVPHYS_PAGES,

    _SC_ATEXIT_MAX,

    _SC_PASS_MAX,


    _SC_XOPEN_VERSION,

    _SC_XOPEN_XCU_VERSION,

    _SC_XOPEN_UNIX,

    _SC_XOPEN_CRYPT,

    _SC_XOPEN_ENH_I18N,

    _SC_XOPEN_SHM,


    _SC_2_CHAR_TERM,

    _SC_2_C_VERSION,

    _SC_2_UPE,


    _SC_XOPEN_XPG2,

    _SC_XOPEN_XPG3,

    _SC_XOPEN_XPG4,


    _SC_CHAR_BIT,

    _SC_CHAR_MAX,

    _SC_CHAR_MIN,

    _SC_INT_MAX,

    _SC_INT_MIN,

    _SC_LONG_BIT,

    _SC_WORD_BIT,

    _SC_MB_LEN_MAX,

    _SC_NZERO,

    _SC_SSIZE_MAX,

    _SC_SCHAR_MAX,

    _SC_SCHAR_MIN,

    _SC_SHRT_MAX,

    _SC_SHRT_MIN,

    _SC_UCHAR_MAX,

    _SC_UINT_MAX,

    _SC_ULONG_MAX,

    _SC_USHRT_MAX,


    _SC_NL_ARGMAX,

    _SC_NL_LANGMAX,

    _SC_NL_MSGMAX,

    _SC_NL_NMAX,

    _SC_NL_SETMAX,

    _SC_NL_TEXTMAX,


    _SC_XBS5_ILP32_OFF32,

    _SC_XBS5_ILP32_OFFBIG,

    _SC_XBS5_LP64_OFF64,

    _SC_XBS5_LPBIG_OFFBIG,


    _SC_XOPEN_LEGACY,

    _SC_XOPEN_REALTIME,

    _SC_XOPEN_REALTIME_THREADS,


    _SC_ADVISORY_INFO,

    _SC_BARRIERS,

    _SC_BASE,

    _SC_C_LANG_SUPPORT,

    _SC_C_LANG_SUPPORT_R,

    _SC_CLOCK_SELECTION,

    _SC_CPUTIME,

    _SC_THREAD_CPUTIME,

    _SC_DEVICE_IO,

    _SC_DEVICE_SPECIFIC,

    _SC_DEVICE_SPECIFIC_R,

    _SC_FD_MGMT,

    _SC_FIFO,

    _SC_PIPE,

    _SC_FILE_ATTRIBUTES,

    _SC_FILE_LOCKING,

    _SC_FILE_SYSTEM,

    _SC_MONOTONIC_CLOCK,

    _SC_MULTI_PROCESS,

    _SC_SINGLE_PROCESS,

    _SC_NETWORKING,

    _SC_READER_WRITER_LOCKS,

    _SC_SPIN_LOCKS,

    _SC_REGEXP,

    _SC_REGEX_VERSION,

    _SC_SHELL,

    _SC_SIGNALS,

    _SC_SPAWN,

    _SC_SPORADIC_SERVER,

    _SC_THREAD_SPORADIC_SERVER,

    _SC_SYSTEM_DATABASE,

    _SC_SYSTEM_DATABASE_R,

    _SC_TIMEOUTS,

    _SC_TYPED_MEMORY_OBJECTS,

    _SC_USER_GROUPS,

    _SC_USER_GROUPS_R,

    _SC_2_PBS,

    _SC_2_PBS_ACCOUNTING,

    _SC_2_PBS_LOCATE,

    _SC_2_PBS_MESSAGE,

    _SC_2_PBS_TRACK,

    _SC_SYMLOOP_MAX,

    _SC_STREAMS,

    _SC_2_PBS_CHECKPOINT,


    _SC_V6_ILP32_OFF32,

    _SC_V6_ILP32_OFFBIG,

    _SC_V6_LP64_OFF64,

    _SC_V6_LPBIG_OFFBIG,


    _SC_HOST_NAME_MAX,

    _SC_TRACE,

    _SC_TRACE_EVENT_FILTER,

    _SC_TRACE_INHERIT,

    _SC_TRACE_LOG,


    _SC_LEVEL1_ICACHE_SIZE,

    _SC_LEVEL1_ICACHE_ASSOC,

    _SC_LEVEL1_ICACHE_LINESIZE,

    _SC_LEVEL1_DCACHE_SIZE,

    _SC_LEVEL1_DCACHE_ASSOC,

    _SC_LEVEL1_DCACHE_LINESIZE,

    _SC_LEVEL2_CACHE_SIZE,

    _SC_LEVEL2_CACHE_ASSOC,

    _SC_LEVEL2_CACHE_LINESIZE,

    _SC_LEVEL3_CACHE_SIZE,

    _SC_LEVEL3_CACHE_ASSOC,

    _SC_LEVEL3_CACHE_LINESIZE,

    _SC_LEVEL4_CACHE_SIZE,

    _SC_LEVEL4_CACHE_ASSOC,

    _SC_LEVEL4_CACHE_LINESIZE,



    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,

    _SC_RAW_SOCKETS,


    _SC_V7_ILP32_OFF32,

    _SC_V7_ILP32_OFFBIG,

    _SC_V7_LP64_OFF64,

    _SC_V7_LPBIG_OFFBIG,


    _SC_SS_REPL_MAX,


    _SC_TRACE_EVENT_NAME_MAX,

    _SC_TRACE_NAME_MAX,

    _SC_TRACE_SYS_MAX,

    _SC_TRACE_USER_EVENT_MAX,


    _SC_XOPEN_STREAMS,


    _SC_THREAD_ROBUST_PRIO_INHERIT,

    _SC_THREAD_ROBUST_PRIO_PROTECT

  };


enum
  {
    _CS_PATH,


    _CS_V6_WIDTH_RESTRICTED_ENVS,



    _CS_GNU_LIBC_VERSION,

    _CS_GNU_LIBPTHREAD_VERSION,


    _CS_V5_WIDTH_RESTRICTED_ENVS,



    _CS_V7_WIDTH_RESTRICTED_ENVS,



    _CS_LFS_CFLAGS = 1000,

    _CS_LFS_LDFLAGS,

    _CS_LFS_LIBS,

    _CS_LFS_LINTFLAGS,

    _CS_LFS64_CFLAGS,

    _CS_LFS64_LDFLAGS,

    _CS_LFS64_LIBS,

    _CS_LFS64_LINTFLAGS,


    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,

    _CS_XBS5_ILP32_OFF32_LDFLAGS,

    _CS_XBS5_ILP32_OFF32_LIBS,

    _CS_XBS5_ILP32_OFF32_LINTFLAGS,

    _CS_XBS5_ILP32_OFFBIG_CFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LIBS,

    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,

    _CS_XBS5_LP64_OFF64_CFLAGS,

    _CS_XBS5_LP64_OFF64_LDFLAGS,

    _CS_XBS5_LP64_OFF64_LIBS,

    _CS_XBS5_LP64_OFF64_LINTFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LIBS,

    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LIBS,

    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V6_LP64_OFF64_CFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LIBS,

    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LIBS,

    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V7_LP64_OFF64_CFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LIBS,

    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,


    _CS_V6_ENV,

    _CS_V7_ENV

  };
# 607 "/usr/include/unistd.h" 2 3 4


extern long int pathconf (__const char *__path, int __name)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern long int fpathconf (int __fd, int __name) __attribute__ ((__nothrow__));


extern long int sysconf (int __name) __attribute__ ((__nothrow__));



extern size_t confstr (int __name, char *__buf, size_t __len) __attribute__ ((__nothrow__));




extern __pid_t getpid (void) __attribute__ ((__nothrow__));


extern __pid_t getppid (void) __attribute__ ((__nothrow__));




extern __pid_t getpgrp (void) __attribute__ ((__nothrow__));
# 643 "/usr/include/unistd.h" 3 4
extern __pid_t __getpgid (__pid_t __pid) __attribute__ ((__nothrow__));

extern __pid_t getpgid (__pid_t __pid) __attribute__ ((__nothrow__));






extern int setpgid (__pid_t __pid, __pid_t __pgid) __attribute__ ((__nothrow__));
# 669 "/usr/include/unistd.h" 3 4
extern int setpgrp (void) __attribute__ ((__nothrow__));
# 686 "/usr/include/unistd.h" 3 4
extern __pid_t setsid (void) __attribute__ ((__nothrow__));



extern __pid_t getsid (__pid_t __pid) __attribute__ ((__nothrow__));



extern __uid_t getuid (void) __attribute__ ((__nothrow__));


extern __uid_t geteuid (void) __attribute__ ((__nothrow__));


extern __gid_t getgid (void) __attribute__ ((__nothrow__));


extern __gid_t getegid (void) __attribute__ ((__nothrow__));




extern int getgroups (int __size, __gid_t __list[]) __attribute__ ((__nothrow__)) ;



extern int group_member (__gid_t __gid) __attribute__ ((__nothrow__));






extern int setuid (__uid_t __uid) __attribute__ ((__nothrow__));




extern int setreuid (__uid_t __ruid, __uid_t __euid) __attribute__ ((__nothrow__));




extern int seteuid (__uid_t __uid) __attribute__ ((__nothrow__));






extern int setgid (__gid_t __gid) __attribute__ ((__nothrow__));




extern int setregid (__gid_t __rgid, __gid_t __egid) __attribute__ ((__nothrow__));




extern int setegid (__gid_t __gid) __attribute__ ((__nothrow__));





extern int getresuid (__uid_t *__ruid, __uid_t *__euid, __uid_t *__suid)
     __attribute__ ((__nothrow__));



extern int getresgid (__gid_t *__rgid, __gid_t *__egid, __gid_t *__sgid)
     __attribute__ ((__nothrow__));



extern int setresuid (__uid_t __ruid, __uid_t __euid, __uid_t __suid)
     __attribute__ ((__nothrow__));



extern int setresgid (__gid_t __rgid, __gid_t __egid, __gid_t __sgid)
     __attribute__ ((__nothrow__));






extern __pid_t fork (void) __attribute__ ((__nothrow__));







extern __pid_t vfork (void) __attribute__ ((__nothrow__));





extern char *ttyname (int __fd) __attribute__ ((__nothrow__));



extern int ttyname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2))) ;



extern int isatty (int __fd) __attribute__ ((__nothrow__));





extern int ttyslot (void) __attribute__ ((__nothrow__));




extern int link (__const char *__from, __const char *__to)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2))) ;




extern int linkat (int __fromfd, __const char *__from, int __tofd,
     __const char *__to, int __flags)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2, 4))) ;




extern int symlink (__const char *__from, __const char *__to)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2))) ;




extern ssize_t readlink (__const char *__restrict __path,
    char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2))) ;




extern int symlinkat (__const char *__from, int __tofd,
        __const char *__to) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3))) ;


extern ssize_t readlinkat (int __fd, __const char *__restrict __path,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2, 3))) ;



extern int unlink (__const char *__name) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));



extern int unlinkat (int __fd, __const char *__name, int __flag)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));



extern int rmdir (__const char *__path) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));



extern __pid_t tcgetpgrp (int __fd) __attribute__ ((__nothrow__));


extern int tcsetpgrp (int __fd, __pid_t __pgrp_id) __attribute__ ((__nothrow__));






extern char *getlogin (void);







extern int getlogin_r (char *__name, size_t __name_len) __attribute__ ((__nonnull__ (1)));




extern int setlogin (__const char *__name) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
# 890 "/usr/include/unistd.h" 3 4

# 1 "/usr/include/getopt.h" 1 3 4
# 59 "/usr/include/getopt.h" 3 4
extern char *optarg;
# 73 "/usr/include/getopt.h" 3 4
extern int optind;




extern int opterr;



extern int optopt;
# 152 "/usr/include/getopt.h" 3 4
extern int getopt (int ___argc, char *const *___argv, const char *__shortopts)
       __attribute__ ((__nothrow__));
# 891 "/usr/include/unistd.h" 2 3 4







extern int gethostname (char *__name, size_t __len) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern int sethostname (__const char *__name, size_t __len)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;



extern int sethostid (long int __id) __attribute__ ((__nothrow__)) ;





extern int getdomainname (char *__name, size_t __len)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;
extern int setdomainname (__const char *__name, size_t __len)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;





extern int vhangup (void) __attribute__ ((__nothrow__));


extern int revoke (__const char *__file) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;







extern int profil (unsigned short int *__sample_buffer, size_t __size,
     size_t __offset, unsigned int __scale)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));





extern int acct (__const char *__name) __attribute__ ((__nothrow__));



extern char *getusershell (void) __attribute__ ((__nothrow__));
extern void endusershell (void) __attribute__ ((__nothrow__));
extern void setusershell (void) __attribute__ ((__nothrow__));





extern int daemon (int __nochdir, int __noclose) __attribute__ ((__nothrow__)) ;






extern int chroot (__const char *__path) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;



extern char *getpass (__const char *__prompt) __attribute__ ((__nonnull__ (1)));
# 976 "/usr/include/unistd.h" 3 4
extern int fsync (int __fd);






extern long int gethostid (void);


extern void sync (void) __attribute__ ((__nothrow__));





extern int getpagesize (void) __attribute__ ((__nothrow__)) __attribute__ ((__const__));




extern int getdtablesize (void) __attribute__ ((__nothrow__));
# 1011 "/usr/include/unistd.h" 3 4
extern int truncate (__const char *__file, __off64_t __length) __asm__ ("" "truncate64") __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;







extern int truncate64 (__const char *__file, __off64_t __length)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1))) ;
# 1029 "/usr/include/unistd.h" 3 4
extern int ftruncate (int __fd, __off64_t __length) __asm__ ("" "ftruncate64") __attribute__ ((__nothrow__)) ;






extern int ftruncate64 (int __fd, __off64_t __length) __attribute__ ((__nothrow__)) ;
# 1047 "/usr/include/unistd.h" 3 4
extern int brk (void *__addr) __attribute__ ((__nothrow__)) ;





extern void *sbrk (intptr_t __delta) __attribute__ ((__nothrow__));
# 1068 "/usr/include/unistd.h" 3 4
extern long int syscall (long int __sysno, ...) __attribute__ ((__nothrow__));
# 1094 "/usr/include/unistd.h" 3 4
extern int lockf (int __fd, int __cmd, __off64_t __len) __asm__ ("" "lockf64") ;






extern int lockf64 (int __fd, int __cmd, __off64_t __len) ;
# 1122 "/usr/include/unistd.h" 3 4
extern int fdatasync (int __fildes);







extern char *crypt (__const char *__key, __const char *__salt)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));



extern void encrypt (char *__libc_block, int __edflag) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern void swab (__const void *__restrict __from, void *__restrict __to,
    ssize_t __n) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));







extern char *ctermid (char *__s) __attribute__ ((__nothrow__));
# 1160 "/usr/include/unistd.h" 3 4
# 45 "/usr/include/python2.7/Python.h" 2
# 56 "/usr/include/python2.7/Python.h"

# 1 "/usr/include/assert.h" 1 3 4
# 57 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/pyport.h" 1
# 9 "/usr/include/python2.7/pyport.h"

# 1 "/usr/include/inttypes.h" 1 3 4
# 28 "/usr/include/inttypes.h" 3 4

# 1 "/usr/include/stdint.h" 1 3 4
# 27 "/usr/include/stdint.h" 3 4

# 1 "/usr/include/bits/wchar.h" 1 3 4
# 28 "/usr/include/stdint.h" 2 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 49 "/usr/include/stdint.h" 3 4
typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;

typedef unsigned int uint32_t;





__extension__
typedef unsigned long long int uint64_t;






typedef signed char int_least8_t;
typedef short int int_least16_t;
typedef int int_least32_t;



__extension__
typedef long long int int_least64_t;



typedef unsigned char uint_least8_t;
typedef unsigned short int uint_least16_t;
typedef unsigned int uint_least32_t;



__extension__
typedef unsigned long long int uint_least64_t;






typedef signed char int_fast8_t;





typedef int int_fast16_t;
typedef int int_fast32_t;
__extension__
typedef long long int int_fast64_t;



typedef unsigned char uint_fast8_t;





typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
__extension__
typedef unsigned long long int uint_fast64_t;
# 129 "/usr/include/stdint.h" 3 4
typedef unsigned int uintptr_t;
# 138 "/usr/include/stdint.h" 3 4
__extension__
typedef long long int intmax_t;
__extension__
typedef unsigned long long int uintmax_t;
# 29 "/usr/include/inttypes.h" 2 3 4






typedef int __gwchar_t;
# 274 "/usr/include/inttypes.h" 3 4
# 288 "/usr/include/inttypes.h" 3 4
typedef struct
  {
    long long int quot;
    long long int rem;
  } imaxdiv_t;





extern intmax_t imaxabs (intmax_t __n) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern imaxdiv_t imaxdiv (intmax_t __numer, intmax_t __denom)
      __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern intmax_t strtoimax (__const char *__restrict __nptr,
      char **__restrict __endptr, int __base) __attribute__ ((__nothrow__));


extern uintmax_t strtoumax (__const char *__restrict __nptr,
       char ** __restrict __endptr, int __base) __attribute__ ((__nothrow__));


extern intmax_t wcstoimax (__const __gwchar_t *__restrict __nptr,
      __gwchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__));


extern uintmax_t wcstoumax (__const __gwchar_t *__restrict __nptr,
       __gwchar_t ** __restrict __endptr, int __base)
     __attribute__ ((__nothrow__));
# 442 "/usr/include/inttypes.h" 3 4
# 10 "/usr/include/python2.7/pyport.h" 2
# 146 "/usr/include/python2.7/pyport.h"
typedef uintptr_t Py_uintptr_t;
typedef intptr_t Py_intptr_t;
# 170 "/usr/include/python2.7/pyport.h"
typedef ssize_t Py_ssize_t;
# 312 "/usr/include/python2.7/pyport.h"

# 1 "/usr/include/math.h" 1 3 4
# 30 "/usr/include/math.h" 3 4





# 1 "/usr/include/bits/huge_val.h" 1 3 4
# 35 "/usr/include/math.h" 2 3 4


# 1 "/usr/include/bits/huge_valf.h" 1 3 4
# 37 "/usr/include/math.h" 2 3 4

# 1 "/usr/include/bits/huge_vall.h" 1 3 4
# 38 "/usr/include/math.h" 2 3 4



# 1 "/usr/include/bits/inf.h" 1 3 4
# 41 "/usr/include/math.h" 2 3 4



# 1 "/usr/include/bits/nan.h" 1 3 4
# 44 "/usr/include/math.h" 2 3 4




# 1 "/usr/include/bits/mathdef.h" 1 3 4
# 26 "/usr/include/bits/mathdef.h" 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 27 "/usr/include/bits/mathdef.h" 2 3 4
# 38 "/usr/include/bits/mathdef.h" 3 4
typedef long double float_t;

typedef long double double_t;
# 48 "/usr/include/math.h" 2 3 4
# 71 "/usr/include/math.h" 3 4

# 1 "/usr/include/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/bits/mathcalls.h" 3 4


extern double acos (double __x) __attribute__ ((__nothrow__)); extern double __acos (double __x) __attribute__ ((__nothrow__));

extern double asin (double __x) __attribute__ ((__nothrow__)); extern double __asin (double __x) __attribute__ ((__nothrow__));

extern double atan (double __x) __attribute__ ((__nothrow__)); extern double __atan (double __x) __attribute__ ((__nothrow__));

extern double atan2 (double __y, double __x) __attribute__ ((__nothrow__)); extern double __atan2 (double __y, double __x) __attribute__ ((__nothrow__));


extern double cos (double __x) __attribute__ ((__nothrow__)); extern double __cos (double __x) __attribute__ ((__nothrow__));

extern double sin (double __x) __attribute__ ((__nothrow__)); extern double __sin (double __x) __attribute__ ((__nothrow__));

extern double tan (double __x) __attribute__ ((__nothrow__)); extern double __tan (double __x) __attribute__ ((__nothrow__));




extern double cosh (double __x) __attribute__ ((__nothrow__)); extern double __cosh (double __x) __attribute__ ((__nothrow__));

extern double sinh (double __x) __attribute__ ((__nothrow__)); extern double __sinh (double __x) __attribute__ ((__nothrow__));

extern double tanh (double __x) __attribute__ ((__nothrow__)); extern double __tanh (double __x) __attribute__ ((__nothrow__));




extern void sincos (double __x, double *__sinx, double *__cosx) __attribute__ ((__nothrow__)); extern void __sincos (double __x, double *__sinx, double *__cosx) __attribute__ ((__nothrow__));






extern double acosh (double __x) __attribute__ ((__nothrow__)); extern double __acosh (double __x) __attribute__ ((__nothrow__));

extern double asinh (double __x) __attribute__ ((__nothrow__)); extern double __asinh (double __x) __attribute__ ((__nothrow__));

extern double atanh (double __x) __attribute__ ((__nothrow__)); extern double __atanh (double __x) __attribute__ ((__nothrow__));







extern double exp (double __x) __attribute__ ((__nothrow__)); extern double __exp (double __x) __attribute__ ((__nothrow__));


extern double frexp (double __x, int *__exponent) __attribute__ ((__nothrow__)); extern double __frexp (double __x, int *__exponent) __attribute__ ((__nothrow__));


extern double ldexp (double __x, int __exponent) __attribute__ ((__nothrow__)); extern double __ldexp (double __x, int __exponent) __attribute__ ((__nothrow__));


extern double log (double __x) __attribute__ ((__nothrow__)); extern double __log (double __x) __attribute__ ((__nothrow__));


extern double log10 (double __x) __attribute__ ((__nothrow__)); extern double __log10 (double __x) __attribute__ ((__nothrow__));


extern double modf (double __x, double *__iptr) __attribute__ ((__nothrow__)); extern double __modf (double __x, double *__iptr) __attribute__ ((__nothrow__));




extern double exp10 (double __x) __attribute__ ((__nothrow__)); extern double __exp10 (double __x) __attribute__ ((__nothrow__));

extern double pow10 (double __x) __attribute__ ((__nothrow__)); extern double __pow10 (double __x) __attribute__ ((__nothrow__));





extern double expm1 (double __x) __attribute__ ((__nothrow__)); extern double __expm1 (double __x) __attribute__ ((__nothrow__));


extern double log1p (double __x) __attribute__ ((__nothrow__)); extern double __log1p (double __x) __attribute__ ((__nothrow__));


extern double logb (double __x) __attribute__ ((__nothrow__)); extern double __logb (double __x) __attribute__ ((__nothrow__));






extern double exp2 (double __x) __attribute__ ((__nothrow__)); extern double __exp2 (double __x) __attribute__ ((__nothrow__));


extern double log2 (double __x) __attribute__ ((__nothrow__)); extern double __log2 (double __x) __attribute__ ((__nothrow__));
# 154 "/usr/include/bits/mathcalls.h" 3 4
extern double pow (double __x, double __y) __attribute__ ((__nothrow__)); extern double __pow (double __x, double __y) __attribute__ ((__nothrow__));


extern double sqrt (double __x) __attribute__ ((__nothrow__)); extern double __sqrt (double __x) __attribute__ ((__nothrow__));





extern double hypot (double __x, double __y) __attribute__ ((__nothrow__)); extern double __hypot (double __x, double __y) __attribute__ ((__nothrow__));






extern double cbrt (double __x) __attribute__ ((__nothrow__)); extern double __cbrt (double __x) __attribute__ ((__nothrow__));
# 179 "/usr/include/bits/mathcalls.h" 3 4
extern double ceil (double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern double __ceil (double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern double fabs (double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern double __fabs (double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern double floor (double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern double __floor (double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern double fmod (double __x, double __y) __attribute__ ((__nothrow__)); extern double __fmod (double __x, double __y) __attribute__ ((__nothrow__));




extern int __isinf (double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern int __finite (double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));





extern int isinf (double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern int finite (double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern double drem (double __x, double __y) __attribute__ ((__nothrow__)); extern double __drem (double __x, double __y) __attribute__ ((__nothrow__));



extern double significand (double __x) __attribute__ ((__nothrow__)); extern double __significand (double __x) __attribute__ ((__nothrow__));





extern double copysign (double __x, double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern double __copysign (double __x, double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__));






extern double nan (__const char *__tagb) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern double __nan (__const char *__tagb) __attribute__ ((__nothrow__)) __attribute__ ((__const__));





extern int __isnan (double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));



extern int isnan (double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern double j0 (double) __attribute__ ((__nothrow__)); extern double __j0 (double) __attribute__ ((__nothrow__));
extern double j1 (double) __attribute__ ((__nothrow__)); extern double __j1 (double) __attribute__ ((__nothrow__));
extern double jn (int, double) __attribute__ ((__nothrow__)); extern double __jn (int, double) __attribute__ ((__nothrow__));
extern double y0 (double) __attribute__ ((__nothrow__)); extern double __y0 (double) __attribute__ ((__nothrow__));
extern double y1 (double) __attribute__ ((__nothrow__)); extern double __y1 (double) __attribute__ ((__nothrow__));
extern double yn (int, double) __attribute__ ((__nothrow__)); extern double __yn (int, double) __attribute__ ((__nothrow__));






extern double erf (double) __attribute__ ((__nothrow__)); extern double __erf (double) __attribute__ ((__nothrow__));
extern double erfc (double) __attribute__ ((__nothrow__)); extern double __erfc (double) __attribute__ ((__nothrow__));
extern double lgamma (double) __attribute__ ((__nothrow__)); extern double __lgamma (double) __attribute__ ((__nothrow__));






extern double tgamma (double) __attribute__ ((__nothrow__)); extern double __tgamma (double) __attribute__ ((__nothrow__));





extern double gamma (double) __attribute__ ((__nothrow__)); extern double __gamma (double) __attribute__ ((__nothrow__));






extern double lgamma_r (double, int *__signgamp) __attribute__ ((__nothrow__)); extern double __lgamma_r (double, int *__signgamp) __attribute__ ((__nothrow__));







extern double rint (double __x) __attribute__ ((__nothrow__)); extern double __rint (double __x) __attribute__ ((__nothrow__));


extern double nextafter (double __x, double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern double __nextafter (double __x, double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__));

extern double nexttoward (double __x, long double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern double __nexttoward (double __x, long double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__));



extern double remainder (double __x, double __y) __attribute__ ((__nothrow__)); extern double __remainder (double __x, double __y) __attribute__ ((__nothrow__));



extern double scalbn (double __x, int __n) __attribute__ ((__nothrow__)); extern double __scalbn (double __x, int __n) __attribute__ ((__nothrow__));



extern int ilogb (double __x) __attribute__ ((__nothrow__)); extern int __ilogb (double __x) __attribute__ ((__nothrow__));




extern double scalbln (double __x, long int __n) __attribute__ ((__nothrow__)); extern double __scalbln (double __x, long int __n) __attribute__ ((__nothrow__));



extern double nearbyint (double __x) __attribute__ ((__nothrow__)); extern double __nearbyint (double __x) __attribute__ ((__nothrow__));



extern double round (double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern double __round (double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));



extern double trunc (double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern double __trunc (double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));




extern double remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__)); extern double __remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__));






extern long int lrint (double __x) __attribute__ ((__nothrow__)); extern long int __lrint (double __x) __attribute__ ((__nothrow__));
extern long long int llrint (double __x) __attribute__ ((__nothrow__)); extern long long int __llrint (double __x) __attribute__ ((__nothrow__));



extern long int lround (double __x) __attribute__ ((__nothrow__)); extern long int __lround (double __x) __attribute__ ((__nothrow__));
extern long long int llround (double __x) __attribute__ ((__nothrow__)); extern long long int __llround (double __x) __attribute__ ((__nothrow__));



extern double fdim (double __x, double __y) __attribute__ ((__nothrow__)); extern double __fdim (double __x, double __y) __attribute__ ((__nothrow__));


extern double fmax (double __x, double __y) __attribute__ ((__nothrow__)); extern double __fmax (double __x, double __y) __attribute__ ((__nothrow__));


extern double fmin (double __x, double __y) __attribute__ ((__nothrow__)); extern double __fmin (double __x, double __y) __attribute__ ((__nothrow__));



extern int __fpclassify (double __value) __attribute__ ((__nothrow__))
     __attribute__ ((__const__));


extern int __signbit (double __value) __attribute__ ((__nothrow__))
     __attribute__ ((__const__));



extern double fma (double __x, double __y, double __z) __attribute__ ((__nothrow__)); extern double __fma (double __x, double __y, double __z) __attribute__ ((__nothrow__));
# 364 "/usr/include/bits/mathcalls.h" 3 4
extern double scalb (double __x, double __n) __attribute__ ((__nothrow__)); extern double __scalb (double __x, double __n) __attribute__ ((__nothrow__));
# 72 "/usr/include/math.h" 2 3 4
# 94 "/usr/include/math.h" 3 4

# 1 "/usr/include/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/bits/mathcalls.h" 3 4


extern float acosf (float __x) __attribute__ ((__nothrow__)); extern float __acosf (float __x) __attribute__ ((__nothrow__));

extern float asinf (float __x) __attribute__ ((__nothrow__)); extern float __asinf (float __x) __attribute__ ((__nothrow__));

extern float atanf (float __x) __attribute__ ((__nothrow__)); extern float __atanf (float __x) __attribute__ ((__nothrow__));

extern float atan2f (float __y, float __x) __attribute__ ((__nothrow__)); extern float __atan2f (float __y, float __x) __attribute__ ((__nothrow__));


extern float cosf (float __x) __attribute__ ((__nothrow__)); extern float __cosf (float __x) __attribute__ ((__nothrow__));

extern float sinf (float __x) __attribute__ ((__nothrow__)); extern float __sinf (float __x) __attribute__ ((__nothrow__));

extern float tanf (float __x) __attribute__ ((__nothrow__)); extern float __tanf (float __x) __attribute__ ((__nothrow__));




extern float coshf (float __x) __attribute__ ((__nothrow__)); extern float __coshf (float __x) __attribute__ ((__nothrow__));

extern float sinhf (float __x) __attribute__ ((__nothrow__)); extern float __sinhf (float __x) __attribute__ ((__nothrow__));

extern float tanhf (float __x) __attribute__ ((__nothrow__)); extern float __tanhf (float __x) __attribute__ ((__nothrow__));




extern void sincosf (float __x, float *__sinx, float *__cosx) __attribute__ ((__nothrow__)); extern void __sincosf (float __x, float *__sinx, float *__cosx) __attribute__ ((__nothrow__));






extern float acoshf (float __x) __attribute__ ((__nothrow__)); extern float __acoshf (float __x) __attribute__ ((__nothrow__));

extern float asinhf (float __x) __attribute__ ((__nothrow__)); extern float __asinhf (float __x) __attribute__ ((__nothrow__));

extern float atanhf (float __x) __attribute__ ((__nothrow__)); extern float __atanhf (float __x) __attribute__ ((__nothrow__));







extern float expf (float __x) __attribute__ ((__nothrow__)); extern float __expf (float __x) __attribute__ ((__nothrow__));


extern float frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__)); extern float __frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__));


extern float ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__)); extern float __ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__));


extern float logf (float __x) __attribute__ ((__nothrow__)); extern float __logf (float __x) __attribute__ ((__nothrow__));


extern float log10f (float __x) __attribute__ ((__nothrow__)); extern float __log10f (float __x) __attribute__ ((__nothrow__));


extern float modff (float __x, float *__iptr) __attribute__ ((__nothrow__)); extern float __modff (float __x, float *__iptr) __attribute__ ((__nothrow__));




extern float exp10f (float __x) __attribute__ ((__nothrow__)); extern float __exp10f (float __x) __attribute__ ((__nothrow__));

extern float pow10f (float __x) __attribute__ ((__nothrow__)); extern float __pow10f (float __x) __attribute__ ((__nothrow__));





extern float expm1f (float __x) __attribute__ ((__nothrow__)); extern float __expm1f (float __x) __attribute__ ((__nothrow__));


extern float log1pf (float __x) __attribute__ ((__nothrow__)); extern float __log1pf (float __x) __attribute__ ((__nothrow__));


extern float logbf (float __x) __attribute__ ((__nothrow__)); extern float __logbf (float __x) __attribute__ ((__nothrow__));






extern float exp2f (float __x) __attribute__ ((__nothrow__)); extern float __exp2f (float __x) __attribute__ ((__nothrow__));


extern float log2f (float __x) __attribute__ ((__nothrow__)); extern float __log2f (float __x) __attribute__ ((__nothrow__));
# 154 "/usr/include/bits/mathcalls.h" 3 4
extern float powf (float __x, float __y) __attribute__ ((__nothrow__)); extern float __powf (float __x, float __y) __attribute__ ((__nothrow__));


extern float sqrtf (float __x) __attribute__ ((__nothrow__)); extern float __sqrtf (float __x) __attribute__ ((__nothrow__));





extern float hypotf (float __x, float __y) __attribute__ ((__nothrow__)); extern float __hypotf (float __x, float __y) __attribute__ ((__nothrow__));






extern float cbrtf (float __x) __attribute__ ((__nothrow__)); extern float __cbrtf (float __x) __attribute__ ((__nothrow__));
# 179 "/usr/include/bits/mathcalls.h" 3 4
extern float ceilf (float __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern float __ceilf (float __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern float fabsf (float __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern float __fabsf (float __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern float floorf (float __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern float __floorf (float __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern float fmodf (float __x, float __y) __attribute__ ((__nothrow__)); extern float __fmodf (float __x, float __y) __attribute__ ((__nothrow__));




extern int __isinff (float __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern int __finitef (float __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));





extern int isinff (float __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern int finitef (float __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern float dremf (float __x, float __y) __attribute__ ((__nothrow__)); extern float __dremf (float __x, float __y) __attribute__ ((__nothrow__));



extern float significandf (float __x) __attribute__ ((__nothrow__)); extern float __significandf (float __x) __attribute__ ((__nothrow__));





extern float copysignf (float __x, float __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern float __copysignf (float __x, float __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__));






extern float nanf (__const char *__tagb) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern float __nanf (__const char *__tagb) __attribute__ ((__nothrow__)) __attribute__ ((__const__));





extern int __isnanf (float __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));



extern int isnanf (float __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern float j0f (float) __attribute__ ((__nothrow__)); extern float __j0f (float) __attribute__ ((__nothrow__));
extern float j1f (float) __attribute__ ((__nothrow__)); extern float __j1f (float) __attribute__ ((__nothrow__));
extern float jnf (int, float) __attribute__ ((__nothrow__)); extern float __jnf (int, float) __attribute__ ((__nothrow__));
extern float y0f (float) __attribute__ ((__nothrow__)); extern float __y0f (float) __attribute__ ((__nothrow__));
extern float y1f (float) __attribute__ ((__nothrow__)); extern float __y1f (float) __attribute__ ((__nothrow__));
extern float ynf (int, float) __attribute__ ((__nothrow__)); extern float __ynf (int, float) __attribute__ ((__nothrow__));






extern float erff (float) __attribute__ ((__nothrow__)); extern float __erff (float) __attribute__ ((__nothrow__));
extern float erfcf (float) __attribute__ ((__nothrow__)); extern float __erfcf (float) __attribute__ ((__nothrow__));
extern float lgammaf (float) __attribute__ ((__nothrow__)); extern float __lgammaf (float) __attribute__ ((__nothrow__));






extern float tgammaf (float) __attribute__ ((__nothrow__)); extern float __tgammaf (float) __attribute__ ((__nothrow__));





extern float gammaf (float) __attribute__ ((__nothrow__)); extern float __gammaf (float) __attribute__ ((__nothrow__));






extern float lgammaf_r (float, int *__signgamp) __attribute__ ((__nothrow__)); extern float __lgammaf_r (float, int *__signgamp) __attribute__ ((__nothrow__));







extern float rintf (float __x) __attribute__ ((__nothrow__)); extern float __rintf (float __x) __attribute__ ((__nothrow__));


extern float nextafterf (float __x, float __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern float __nextafterf (float __x, float __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__));

extern float nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern float __nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__));



extern float remainderf (float __x, float __y) __attribute__ ((__nothrow__)); extern float __remainderf (float __x, float __y) __attribute__ ((__nothrow__));



extern float scalbnf (float __x, int __n) __attribute__ ((__nothrow__)); extern float __scalbnf (float __x, int __n) __attribute__ ((__nothrow__));



extern int ilogbf (float __x) __attribute__ ((__nothrow__)); extern int __ilogbf (float __x) __attribute__ ((__nothrow__));




extern float scalblnf (float __x, long int __n) __attribute__ ((__nothrow__)); extern float __scalblnf (float __x, long int __n) __attribute__ ((__nothrow__));



extern float nearbyintf (float __x) __attribute__ ((__nothrow__)); extern float __nearbyintf (float __x) __attribute__ ((__nothrow__));



extern float roundf (float __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern float __roundf (float __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));



extern float truncf (float __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern float __truncf (float __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));




extern float remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__)); extern float __remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__));






extern long int lrintf (float __x) __attribute__ ((__nothrow__)); extern long int __lrintf (float __x) __attribute__ ((__nothrow__));
extern long long int llrintf (float __x) __attribute__ ((__nothrow__)); extern long long int __llrintf (float __x) __attribute__ ((__nothrow__));



extern long int lroundf (float __x) __attribute__ ((__nothrow__)); extern long int __lroundf (float __x) __attribute__ ((__nothrow__));
extern long long int llroundf (float __x) __attribute__ ((__nothrow__)); extern long long int __llroundf (float __x) __attribute__ ((__nothrow__));



extern float fdimf (float __x, float __y) __attribute__ ((__nothrow__)); extern float __fdimf (float __x, float __y) __attribute__ ((__nothrow__));


extern float fmaxf (float __x, float __y) __attribute__ ((__nothrow__)); extern float __fmaxf (float __x, float __y) __attribute__ ((__nothrow__));


extern float fminf (float __x, float __y) __attribute__ ((__nothrow__)); extern float __fminf (float __x, float __y) __attribute__ ((__nothrow__));



extern int __fpclassifyf (float __value) __attribute__ ((__nothrow__))
     __attribute__ ((__const__));


extern int __signbitf (float __value) __attribute__ ((__nothrow__))
     __attribute__ ((__const__));



extern float fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__)); extern float __fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__));
# 364 "/usr/include/bits/mathcalls.h" 3 4
extern float scalbf (float __x, float __n) __attribute__ ((__nothrow__)); extern float __scalbf (float __x, float __n) __attribute__ ((__nothrow__));
# 95 "/usr/include/math.h" 2 3 4
# 145 "/usr/include/math.h" 3 4

# 1 "/usr/include/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/bits/mathcalls.h" 3 4


extern long double acosl (long double __x) __attribute__ ((__nothrow__)); extern long double __acosl (long double __x) __attribute__ ((__nothrow__));

extern long double asinl (long double __x) __attribute__ ((__nothrow__)); extern long double __asinl (long double __x) __attribute__ ((__nothrow__));

extern long double atanl (long double __x) __attribute__ ((__nothrow__)); extern long double __atanl (long double __x) __attribute__ ((__nothrow__));

extern long double atan2l (long double __y, long double __x) __attribute__ ((__nothrow__)); extern long double __atan2l (long double __y, long double __x) __attribute__ ((__nothrow__));


extern long double cosl (long double __x) __attribute__ ((__nothrow__)); extern long double __cosl (long double __x) __attribute__ ((__nothrow__));

extern long double sinl (long double __x) __attribute__ ((__nothrow__)); extern long double __sinl (long double __x) __attribute__ ((__nothrow__));

extern long double tanl (long double __x) __attribute__ ((__nothrow__)); extern long double __tanl (long double __x) __attribute__ ((__nothrow__));




extern long double coshl (long double __x) __attribute__ ((__nothrow__)); extern long double __coshl (long double __x) __attribute__ ((__nothrow__));

extern long double sinhl (long double __x) __attribute__ ((__nothrow__)); extern long double __sinhl (long double __x) __attribute__ ((__nothrow__));

extern long double tanhl (long double __x) __attribute__ ((__nothrow__)); extern long double __tanhl (long double __x) __attribute__ ((__nothrow__));




extern void sincosl (long double __x, long double *__sinx, long double *__cosx) __attribute__ ((__nothrow__)); extern void __sincosl (long double __x, long double *__sinx, long double *__cosx) __attribute__ ((__nothrow__));






extern long double acoshl (long double __x) __attribute__ ((__nothrow__)); extern long double __acoshl (long double __x) __attribute__ ((__nothrow__));

extern long double asinhl (long double __x) __attribute__ ((__nothrow__)); extern long double __asinhl (long double __x) __attribute__ ((__nothrow__));

extern long double atanhl (long double __x) __attribute__ ((__nothrow__)); extern long double __atanhl (long double __x) __attribute__ ((__nothrow__));







extern long double expl (long double __x) __attribute__ ((__nothrow__)); extern long double __expl (long double __x) __attribute__ ((__nothrow__));


extern long double frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__)); extern long double __frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__));


extern long double ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__)); extern long double __ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__));


extern long double logl (long double __x) __attribute__ ((__nothrow__)); extern long double __logl (long double __x) __attribute__ ((__nothrow__));


extern long double log10l (long double __x) __attribute__ ((__nothrow__)); extern long double __log10l (long double __x) __attribute__ ((__nothrow__));


extern long double modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__)); extern long double __modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__));




extern long double exp10l (long double __x) __attribute__ ((__nothrow__)); extern long double __exp10l (long double __x) __attribute__ ((__nothrow__));

extern long double pow10l (long double __x) __attribute__ ((__nothrow__)); extern long double __pow10l (long double __x) __attribute__ ((__nothrow__));





extern long double expm1l (long double __x) __attribute__ ((__nothrow__)); extern long double __expm1l (long double __x) __attribute__ ((__nothrow__));


extern long double log1pl (long double __x) __attribute__ ((__nothrow__)); extern long double __log1pl (long double __x) __attribute__ ((__nothrow__));


extern long double logbl (long double __x) __attribute__ ((__nothrow__)); extern long double __logbl (long double __x) __attribute__ ((__nothrow__));






extern long double exp2l (long double __x) __attribute__ ((__nothrow__)); extern long double __exp2l (long double __x) __attribute__ ((__nothrow__));


extern long double log2l (long double __x) __attribute__ ((__nothrow__)); extern long double __log2l (long double __x) __attribute__ ((__nothrow__));
# 154 "/usr/include/bits/mathcalls.h" 3 4
extern long double powl (long double __x, long double __y) __attribute__ ((__nothrow__)); extern long double __powl (long double __x, long double __y) __attribute__ ((__nothrow__));


extern long double sqrtl (long double __x) __attribute__ ((__nothrow__)); extern long double __sqrtl (long double __x) __attribute__ ((__nothrow__));





extern long double hypotl (long double __x, long double __y) __attribute__ ((__nothrow__)); extern long double __hypotl (long double __x, long double __y) __attribute__ ((__nothrow__));






extern long double cbrtl (long double __x) __attribute__ ((__nothrow__)); extern long double __cbrtl (long double __x) __attribute__ ((__nothrow__));
# 179 "/usr/include/bits/mathcalls.h" 3 4
extern long double ceill (long double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern long double __ceill (long double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern long double fabsl (long double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern long double __fabsl (long double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern long double floorl (long double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern long double __floorl (long double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern long double fmodl (long double __x, long double __y) __attribute__ ((__nothrow__)); extern long double __fmodl (long double __x, long double __y) __attribute__ ((__nothrow__));




extern int __isinfl (long double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern int __finitel (long double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));





extern int isinfl (long double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern int finitel (long double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern long double dreml (long double __x, long double __y) __attribute__ ((__nothrow__)); extern long double __dreml (long double __x, long double __y) __attribute__ ((__nothrow__));



extern long double significandl (long double __x) __attribute__ ((__nothrow__)); extern long double __significandl (long double __x) __attribute__ ((__nothrow__));





extern long double copysignl (long double __x, long double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern long double __copysignl (long double __x, long double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__));






extern long double nanl (__const char *__tagb) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern long double __nanl (__const char *__tagb) __attribute__ ((__nothrow__)) __attribute__ ((__const__));





extern int __isnanl (long double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));



extern int isnanl (long double __value) __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern long double j0l (long double) __attribute__ ((__nothrow__)); extern long double __j0l (long double) __attribute__ ((__nothrow__));
extern long double j1l (long double) __attribute__ ((__nothrow__)); extern long double __j1l (long double) __attribute__ ((__nothrow__));
extern long double jnl (int, long double) __attribute__ ((__nothrow__)); extern long double __jnl (int, long double) __attribute__ ((__nothrow__));
extern long double y0l (long double) __attribute__ ((__nothrow__)); extern long double __y0l (long double) __attribute__ ((__nothrow__));
extern long double y1l (long double) __attribute__ ((__nothrow__)); extern long double __y1l (long double) __attribute__ ((__nothrow__));
extern long double ynl (int, long double) __attribute__ ((__nothrow__)); extern long double __ynl (int, long double) __attribute__ ((__nothrow__));






extern long double erfl (long double) __attribute__ ((__nothrow__)); extern long double __erfl (long double) __attribute__ ((__nothrow__));
extern long double erfcl (long double) __attribute__ ((__nothrow__)); extern long double __erfcl (long double) __attribute__ ((__nothrow__));
extern long double lgammal (long double) __attribute__ ((__nothrow__)); extern long double __lgammal (long double) __attribute__ ((__nothrow__));






extern long double tgammal (long double) __attribute__ ((__nothrow__)); extern long double __tgammal (long double) __attribute__ ((__nothrow__));





extern long double gammal (long double) __attribute__ ((__nothrow__)); extern long double __gammal (long double) __attribute__ ((__nothrow__));






extern long double lgammal_r (long double, int *__signgamp) __attribute__ ((__nothrow__)); extern long double __lgammal_r (long double, int *__signgamp) __attribute__ ((__nothrow__));







extern long double rintl (long double __x) __attribute__ ((__nothrow__)); extern long double __rintl (long double __x) __attribute__ ((__nothrow__));


extern long double nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern long double __nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__));

extern long double nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern long double __nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__)) __attribute__ ((__const__));



extern long double remainderl (long double __x, long double __y) __attribute__ ((__nothrow__)); extern long double __remainderl (long double __x, long double __y) __attribute__ ((__nothrow__));



extern long double scalbnl (long double __x, int __n) __attribute__ ((__nothrow__)); extern long double __scalbnl (long double __x, int __n) __attribute__ ((__nothrow__));



extern int ilogbl (long double __x) __attribute__ ((__nothrow__)); extern int __ilogbl (long double __x) __attribute__ ((__nothrow__));




extern long double scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__)); extern long double __scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__));



extern long double nearbyintl (long double __x) __attribute__ ((__nothrow__)); extern long double __nearbyintl (long double __x) __attribute__ ((__nothrow__));



extern long double roundl (long double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern long double __roundl (long double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));



extern long double truncl (long double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__)); extern long double __truncl (long double __x) __attribute__ ((__nothrow__)) __attribute__ ((__const__));




extern long double remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__)); extern long double __remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__));






extern long int lrintl (long double __x) __attribute__ ((__nothrow__)); extern long int __lrintl (long double __x) __attribute__ ((__nothrow__));
extern long long int llrintl (long double __x) __attribute__ ((__nothrow__)); extern long long int __llrintl (long double __x) __attribute__ ((__nothrow__));



extern long int lroundl (long double __x) __attribute__ ((__nothrow__)); extern long int __lroundl (long double __x) __attribute__ ((__nothrow__));
extern long long int llroundl (long double __x) __attribute__ ((__nothrow__)); extern long long int __llroundl (long double __x) __attribute__ ((__nothrow__));



extern long double fdiml (long double __x, long double __y) __attribute__ ((__nothrow__)); extern long double __fdiml (long double __x, long double __y) __attribute__ ((__nothrow__));


extern long double fmaxl (long double __x, long double __y) __attribute__ ((__nothrow__)); extern long double __fmaxl (long double __x, long double __y) __attribute__ ((__nothrow__));


extern long double fminl (long double __x, long double __y) __attribute__ ((__nothrow__)); extern long double __fminl (long double __x, long double __y) __attribute__ ((__nothrow__));



extern int __fpclassifyl (long double __value) __attribute__ ((__nothrow__))
     __attribute__ ((__const__));


extern int __signbitl (long double __value) __attribute__ ((__nothrow__))
     __attribute__ ((__const__));



extern long double fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__)); extern long double __fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__));
# 364 "/usr/include/bits/mathcalls.h" 3 4
extern long double scalbl (long double __x, long double __n) __attribute__ ((__nothrow__)); extern long double __scalbl (long double __x, long double __n) __attribute__ ((__nothrow__));
# 146 "/usr/include/math.h" 2 3 4
# 161 "/usr/include/math.h" 3 4
extern int signgam;
# 202 "/usr/include/math.h" 3 4
enum
  {
    FP_NAN,

    FP_INFINITE,

    FP_ZERO,

    FP_SUBNORMAL,

    FP_NORMAL

  };
# 295 "/usr/include/math.h" 3 4
typedef enum
{
  _IEEE_ = -1,
  _SVID_,
  _XOPEN_,
  _POSIX_,
  _ISOC_
} _LIB_VERSION_TYPE;




extern _LIB_VERSION_TYPE _LIB_VERSION;
# 320 "/usr/include/math.h" 3 4
struct exception

  {
    int type;
    char *name;
    double arg1;
    double arg2;
    double retval;
  };




extern int matherr (struct exception *__exc);
# 476 "/usr/include/math.h" 3 4
# 313 "/usr/include/python2.7/pyport.h" 2







# 1 "/usr/include/sys/time.h" 1 3 4
# 27 "/usr/include/sys/time.h" 3 4

# 1 "/usr/include/time.h" 1 3 4
# 28 "/usr/include/sys/time.h" 2 3 4


# 1 "/usr/include/bits/time.h" 1 3 4
# 30 "/usr/include/sys/time.h" 2 3 4
# 39 "/usr/include/sys/time.h" 3 4
# 57 "/usr/include/sys/time.h" 3 4
struct timezone
  {
    int tz_minuteswest;
    int tz_dsttime;
  };

typedef struct timezone *__restrict __timezone_ptr_t;
# 73 "/usr/include/sys/time.h" 3 4
extern int gettimeofday (struct timeval *__restrict __tv,
    __timezone_ptr_t __tz) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int settimeofday (__const struct timeval *__tv,
    __const struct timezone *__tz)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));





extern int adjtime (__const struct timeval *__delta,
      struct timeval *__olddelta) __attribute__ ((__nothrow__));




enum __itimer_which
  {

    ITIMER_REAL = 0,


    ITIMER_VIRTUAL = 1,



    ITIMER_PROF = 2

  };



struct itimerval
  {

    struct timeval it_interval;

    struct timeval it_value;
  };




typedef enum __itimer_which __itimer_which_t;






extern int getitimer (__itimer_which_t __which,
        struct itimerval *__value) __attribute__ ((__nothrow__));




extern int setitimer (__itimer_which_t __which,
        __const struct itimerval *__restrict __new,
        struct itimerval *__restrict __old) __attribute__ ((__nothrow__));




extern int utimes (__const char *__file, __const struct timeval __tvp[2])
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));



extern int lutimes (__const char *__file, __const struct timeval __tvp[2])
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int futimes (int __fd, __const struct timeval __tvp[2]) __attribute__ ((__nothrow__));






extern int futimesat (int __fd, __const char *__file,
        __const struct timeval __tvp[2]) __attribute__ ((__nothrow__));
# 191 "/usr/include/sys/time.h" 3 4
# 320 "/usr/include/python2.7/pyport.h" 2

# 1 "/usr/include/time.h" 1 3 4
# 30 "/usr/include/time.h" 3 4
# 39 "/usr/include/time.h" 3 4
# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 1 3 4
# 39 "/usr/include/time.h" 2 3 4




# 1 "/usr/include/bits/time.h" 1 3 4
# 43 "/usr/include/time.h" 2 3 4
# 131 "/usr/include/time.h" 3 4


struct tm
{
  int tm_sec;
  int tm_min;
  int tm_hour;
  int tm_mday;
  int tm_mon;
  int tm_year;
  int tm_wday;
  int tm_yday;
  int tm_isdst;


  long int tm_gmtoff;
  __const char *tm_zone;




};
# 161 "/usr/include/time.h" 3 4
struct itimerspec
  {
    struct timespec it_interval;
    struct timespec it_value;
  };


struct sigevent;
# 180 "/usr/include/time.h" 3 4



extern clock_t clock (void) __attribute__ ((__nothrow__));


extern time_t time (time_t *__timer) __attribute__ ((__nothrow__));


extern double difftime (time_t __time1, time_t __time0)
     __attribute__ ((__nothrow__)) __attribute__ ((__const__));


extern time_t mktime (struct tm *__tp) __attribute__ ((__nothrow__));





extern size_t strftime (char *__restrict __s, size_t __maxsize,
   __const char *__restrict __format,
   __const struct tm *__restrict __tp) __attribute__ ((__nothrow__));





extern char *strptime (__const char *__restrict __s,
         __const char *__restrict __fmt, struct tm *__tp)
     __attribute__ ((__nothrow__));







extern size_t strftime_l (char *__restrict __s, size_t __maxsize,
     __const char *__restrict __format,
     __const struct tm *__restrict __tp,
     __locale_t __loc) __attribute__ ((__nothrow__));



extern char *strptime_l (__const char *__restrict __s,
    __const char *__restrict __fmt, struct tm *__tp,
    __locale_t __loc) __attribute__ ((__nothrow__));






extern struct tm *gmtime (__const time_t *__timer) __attribute__ ((__nothrow__));



extern struct tm *localtime (__const time_t *__timer) __attribute__ ((__nothrow__));





extern struct tm *gmtime_r (__const time_t *__restrict __timer,
       struct tm *__restrict __tp) __attribute__ ((__nothrow__));



extern struct tm *localtime_r (__const time_t *__restrict __timer,
          struct tm *__restrict __tp) __attribute__ ((__nothrow__));





extern char *asctime (__const struct tm *__tp) __attribute__ ((__nothrow__));


extern char *ctime (__const time_t *__timer) __attribute__ ((__nothrow__));







extern char *asctime_r (__const struct tm *__restrict __tp,
   char *__restrict __buf) __attribute__ ((__nothrow__));


extern char *ctime_r (__const time_t *__restrict __timer,
        char *__restrict __buf) __attribute__ ((__nothrow__));




extern char *__tzname[2];
extern int __daylight;
extern long int __timezone;




extern char *tzname[2];



extern void tzset (void) __attribute__ ((__nothrow__));



extern int daylight;
extern long int timezone;





extern int stime (__const time_t *__when) __attribute__ ((__nothrow__));
# 313 "/usr/include/time.h" 3 4
extern time_t timegm (struct tm *__tp) __attribute__ ((__nothrow__));


extern time_t timelocal (struct tm *__tp) __attribute__ ((__nothrow__));


extern int dysize (int __year) __attribute__ ((__nothrow__)) __attribute__ ((__const__));
# 328 "/usr/include/time.h" 3 4
extern int nanosleep (__const struct timespec *__requested_time,
        struct timespec *__remaining);



extern int clock_getres (clockid_t __clock_id, struct timespec *__res) __attribute__ ((__nothrow__));


extern int clock_gettime (clockid_t __clock_id, struct timespec *__tp) __attribute__ ((__nothrow__));


extern int clock_settime (clockid_t __clock_id, __const struct timespec *__tp)
     __attribute__ ((__nothrow__));






extern int clock_nanosleep (clockid_t __clock_id, int __flags,
       __const struct timespec *__req,
       struct timespec *__rem);


extern int clock_getcpuclockid (pid_t __pid, clockid_t *__clock_id) __attribute__ ((__nothrow__));




extern int timer_create (clockid_t __clock_id,
    struct sigevent *__restrict __evp,
    timer_t *__restrict __timerid) __attribute__ ((__nothrow__));


extern int timer_delete (timer_t __timerid) __attribute__ ((__nothrow__));


extern int timer_settime (timer_t __timerid, int __flags,
     __const struct itimerspec *__restrict __value,
     struct itimerspec *__restrict __ovalue) __attribute__ ((__nothrow__));


extern int timer_gettime (timer_t __timerid, struct itimerspec *__value)
     __attribute__ ((__nothrow__));


extern int timer_getoverrun (timer_t __timerid) __attribute__ ((__nothrow__));
# 390 "/usr/include/time.h" 3 4
extern int getdate_err;
# 399 "/usr/include/time.h" 3 4
extern struct tm *getdate (__const char *__string);
# 413 "/usr/include/time.h" 3 4
extern int getdate_r (__const char *__restrict __string,
        struct tm *__restrict __resbufp);
# 321 "/usr/include/python2.7/pyport.h" 2
# 377 "/usr/include/python2.7/pyport.h"

# 1 "/usr/include/sys/stat.h" 1 3 4
# 105 "/usr/include/sys/stat.h" 3 4



# 1 "/usr/include/bits/stat.h" 1 3 4
# 46 "/usr/include/bits/stat.h" 3 4
struct stat
  {
    __dev_t st_dev;

    unsigned short int __pad1;




    __ino_t __st_ino;


    __mode_t st_mode;
    __nlink_t st_nlink;




    __uid_t st_uid;
    __gid_t st_gid;



    __dev_t st_rdev;

    unsigned short int __pad2;




    __off64_t st_size;

    __blksize_t st_blksize;



    __blkcnt64_t st_blocks;
# 91 "/usr/include/bits/stat.h" 3 4
    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;
# 112 "/usr/include/bits/stat.h" 3 4
    __ino64_t st_ino;


  };



struct stat64
  {
    __dev_t st_dev;





    unsigned int __pad1;
    __ino_t __st_ino;
    __mode_t st_mode;
    __nlink_t st_nlink;

    __uid_t st_uid;
    __gid_t st_gid;





    __dev_t st_rdev;
    unsigned int __pad2;
    __off64_t st_size;

    __blksize_t st_blksize;
    __blkcnt64_t st_blocks;







    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;
# 169 "/usr/include/bits/stat.h" 3 4
    __ino64_t st_ino;

  };
# 108 "/usr/include/sys/stat.h" 2 3 4
# 219 "/usr/include/sys/stat.h" 3 4
extern int stat (__const char *__restrict __file, struct stat *__restrict __buf) __asm__ ("" "stat64") __attribute__ ((__nothrow__))

     __attribute__ ((__nonnull__ (1, 2)));
extern int fstat (int __fd, struct stat *__buf) __asm__ ("" "fstat64") __attribute__ ((__nothrow__))
     __attribute__ ((__nonnull__ (2)));






extern int stat64 (__const char *__restrict __file,
     struct stat64 *__restrict __buf) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern int fstat64 (int __fd, struct stat64 *__buf) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));
# 245 "/usr/include/sys/stat.h" 3 4
extern int fstatat (int __fd, __const char *__restrict __file, struct stat *__restrict __buf, int __flag) __asm__ ("" "fstatat64") __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2, 3)));
# 255 "/usr/include/sys/stat.h" 3 4
extern int fstatat64 (int __fd, __const char *__restrict __file,
        struct stat64 *__restrict __buf, int __flag)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2, 3)));
# 269 "/usr/include/sys/stat.h" 3 4
extern int lstat (__const char *__restrict __file, struct stat *__restrict __buf) __asm__ ("" "lstat64") __attribute__ ((__nothrow__))


     __attribute__ ((__nonnull__ (1, 2)));





extern int lstat64 (__const char *__restrict __file,
      struct stat64 *__restrict __buf)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));





extern int chmod (__const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));





extern int lchmod (__const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int fchmod (int __fd, __mode_t __mode) __attribute__ ((__nothrow__));





extern int fchmodat (int __fd, __const char *__file, __mode_t __mode,
       int __flag)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2))) ;






extern __mode_t umask (__mode_t __mask) __attribute__ ((__nothrow__));




extern __mode_t getumask (void) __attribute__ ((__nothrow__));



extern int mkdir (__const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));





extern int mkdirat (int __fd, __const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));






extern int mknod (__const char *__path, __mode_t __mode, __dev_t __dev)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));





extern int mknodat (int __fd, __const char *__path, __mode_t __mode,
      __dev_t __dev) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));





extern int mkfifo (__const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));





extern int mkfifoat (int __fd, __const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));





extern int utimensat (int __fd, __const char *__path,
        __const struct timespec __times[2],
        int __flags)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2)));




extern int futimens (int __fd, __const struct timespec __times[2]) __attribute__ ((__nothrow__));
# 412 "/usr/include/sys/stat.h" 3 4
extern int __fxstat (int __ver, int __fildes, struct stat *__stat_buf) __asm__ ("" "__fxstat64") __attribute__ ((__nothrow__))

     __attribute__ ((__nonnull__ (3)));
extern int __xstat (int __ver, __const char *__filename, struct stat *__stat_buf) __asm__ ("" "__xstat64") __attribute__ ((__nothrow__))

     __attribute__ ((__nonnull__ (2, 3)));
extern int __lxstat (int __ver, __const char *__filename, struct stat *__stat_buf) __asm__ ("" "__lxstat64") __attribute__ ((__nothrow__))

     __attribute__ ((__nonnull__ (2, 3)));
extern int __fxstatat (int __ver, int __fildes, __const char *__filename, struct stat *__stat_buf, int __flag) __asm__ ("" "__fxstatat64") __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3, 4)));
# 434 "/usr/include/sys/stat.h" 3 4
extern int __fxstat64 (int __ver, int __fildes, struct stat64 *__stat_buf)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3)));
extern int __xstat64 (int __ver, __const char *__filename,
        struct stat64 *__stat_buf) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2, 3)));
extern int __lxstat64 (int __ver, __const char *__filename,
         struct stat64 *__stat_buf) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2, 3)));
extern int __fxstatat64 (int __ver, int __fildes, __const char *__filename,
    struct stat64 *__stat_buf, int __flag)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3, 4)));

extern int __xmknod (int __ver, __const char *__path, __mode_t __mode,
       __dev_t *__dev) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (2, 4)));

extern int __xmknodat (int __ver, int __fd, __const char *__path,
         __mode_t __mode, __dev_t *__dev)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (3, 5)));
# 536 "/usr/include/sys/stat.h" 3 4
# 378 "/usr/include/python2.7/pyport.h" 2
# 59 "/usr/include/python2.7/Python.h" 2
# 77 "/usr/include/python2.7/Python.h"

# 1 "/usr/include/python2.7/pymath.h" 1
# 72 "/usr/include/python2.7/pymath.h"
double _Py_force_double(double);







unsigned short _Py_get_387controlword(void);
void _Py_set_387controlword(unsigned short);
# 78 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/pymem.h" 1
# 52 "/usr/include/python2.7/pymem.h"
void * PyMem_Malloc(size_t);
void * PyMem_Realloc(void *, size_t);
void PyMem_Free(void *);
# 79 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/object.h" 1
# 106 "/usr/include/python2.7/object.h"
typedef struct _object {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
} PyObject;

typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type; Py_ssize_t ob_size;
} PyVarObject;
# 133 "/usr/include/python2.7/object.h"
typedef PyObject * (*unaryfunc)(PyObject *);
typedef PyObject * (*binaryfunc)(PyObject *, PyObject *);
typedef PyObject * (*ternaryfunc)(PyObject *, PyObject *, PyObject *);
typedef int (*inquiry)(PyObject *);
typedef Py_ssize_t (*lenfunc)(PyObject *);
typedef int (*coercion)(PyObject **, PyObject **);
typedef PyObject *(*intargfunc)(PyObject *, int) __attribute__((__deprecated__));
typedef PyObject *(*intintargfunc)(PyObject *, int, int) __attribute__((__deprecated__));
typedef PyObject *(*ssizeargfunc)(PyObject *, Py_ssize_t);
typedef PyObject *(*ssizessizeargfunc)(PyObject *, Py_ssize_t, Py_ssize_t);
typedef int(*intobjargproc)(PyObject *, int, PyObject *);
typedef int(*intintobjargproc)(PyObject *, int, int, PyObject *);
typedef int(*ssizeobjargproc)(PyObject *, Py_ssize_t, PyObject *);
typedef int(*ssizessizeobjargproc)(PyObject *, Py_ssize_t, Py_ssize_t, PyObject *);
typedef int(*objobjargproc)(PyObject *, PyObject *, PyObject *);




typedef int (*getreadbufferproc)(PyObject *, int, void **);
typedef int (*getwritebufferproc)(PyObject *, int, void **);
typedef int (*getsegcountproc)(PyObject *, int *);
typedef int (*getcharbufferproc)(PyObject *, int, char **);

typedef Py_ssize_t (*readbufferproc)(PyObject *, Py_ssize_t, void **);
typedef Py_ssize_t (*writebufferproc)(PyObject *, Py_ssize_t, void **);
typedef Py_ssize_t (*segcountproc)(PyObject *, Py_ssize_t *);
typedef Py_ssize_t (*charbufferproc)(PyObject *, Py_ssize_t, char **);



typedef struct bufferinfo {
    void *buf;
    PyObject *obj;
    Py_ssize_t len;
    Py_ssize_t itemsize;

    int readonly;
    int ndim;
    char *format;
    Py_ssize_t *shape;
    Py_ssize_t *strides;
    Py_ssize_t *suboffsets;
    Py_ssize_t smalltable[2];

    void *internal;
} Py_buffer;

typedef int (*getbufferproc)(PyObject *, Py_buffer *, int);
typedef void (*releasebufferproc)(PyObject *, Py_buffer *);
# 215 "/usr/include/python2.7/object.h"
typedef int (*objobjproc)(PyObject *, PyObject *);
typedef int (*visitproc)(PyObject *, void *);
typedef int (*traverseproc)(PyObject *, visitproc, void *);

typedef struct {
# 228 "/usr/include/python2.7/object.h"
    binaryfunc nb_add;
    binaryfunc nb_subtract;
    binaryfunc nb_multiply;
    binaryfunc nb_divide;
    binaryfunc nb_remainder;
    binaryfunc nb_divmod;
    ternaryfunc nb_power;
    unaryfunc nb_negative;
    unaryfunc nb_positive;
    unaryfunc nb_absolute;
    inquiry nb_nonzero;
    unaryfunc nb_invert;
    binaryfunc nb_lshift;
    binaryfunc nb_rshift;
    binaryfunc nb_and;
    binaryfunc nb_xor;
    binaryfunc nb_or;
    coercion nb_coerce;
    unaryfunc nb_int;
    unaryfunc nb_long;
    unaryfunc nb_float;
    unaryfunc nb_oct;
    unaryfunc nb_hex;

    binaryfunc nb_inplace_add;
    binaryfunc nb_inplace_subtract;
    binaryfunc nb_inplace_multiply;
    binaryfunc nb_inplace_divide;
    binaryfunc nb_inplace_remainder;
    ternaryfunc nb_inplace_power;
    binaryfunc nb_inplace_lshift;
    binaryfunc nb_inplace_rshift;
    binaryfunc nb_inplace_and;
    binaryfunc nb_inplace_xor;
    binaryfunc nb_inplace_or;



    binaryfunc nb_floor_divide;
    binaryfunc nb_true_divide;
    binaryfunc nb_inplace_floor_divide;
    binaryfunc nb_inplace_true_divide;


    unaryfunc nb_index;
} PyNumberMethods;

typedef struct {
    lenfunc sq_length;
    binaryfunc sq_concat;
    ssizeargfunc sq_repeat;
    ssizeargfunc sq_item;
    ssizessizeargfunc sq_slice;
    ssizeobjargproc sq_ass_item;
    ssizessizeobjargproc sq_ass_slice;
    objobjproc sq_contains;

    binaryfunc sq_inplace_concat;
    ssizeargfunc sq_inplace_repeat;
} PySequenceMethods;

typedef struct {
    lenfunc mp_length;
    binaryfunc mp_subscript;
    objobjargproc mp_ass_subscript;
} PyMappingMethods;

typedef struct {
    readbufferproc bf_getreadbuffer;
    writebufferproc bf_getwritebuffer;
    segcountproc bf_getsegcount;
    charbufferproc bf_getcharbuffer;
    getbufferproc bf_getbuffer;
    releasebufferproc bf_releasebuffer;
} PyBufferProcs;


typedef void (*freefunc)(void *);
typedef void (*destructor)(PyObject *);
typedef int (*printfunc)(PyObject *, FILE *, int);
typedef PyObject *(*getattrfunc)(PyObject *, char *);
typedef PyObject *(*getattrofunc)(PyObject *, PyObject *);
typedef int (*setattrfunc)(PyObject *, char *, PyObject *);
typedef int (*setattrofunc)(PyObject *, PyObject *, PyObject *);
typedef int (*cmpfunc)(PyObject *, PyObject *);
typedef PyObject *(*reprfunc)(PyObject *);
typedef long (*hashfunc)(PyObject *);
typedef PyObject *(*richcmpfunc) (PyObject *, PyObject *, int);
typedef PyObject *(*getiterfunc) (PyObject *);
typedef PyObject *(*iternextfunc) (PyObject *);
typedef PyObject *(*descrgetfunc) (PyObject *, PyObject *, PyObject *);
typedef int (*descrsetfunc) (PyObject *, PyObject *, PyObject *);
typedef int (*initproc)(PyObject *, PyObject *, PyObject *);
typedef PyObject *(*newfunc)(struct _typeobject *, PyObject *, PyObject *);
typedef PyObject *(*allocfunc)(struct _typeobject *, Py_ssize_t);

typedef struct _typeobject {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type; Py_ssize_t ob_size;
    const char *tp_name;
    Py_ssize_t tp_basicsize, tp_itemsize;



    destructor tp_dealloc;
    printfunc tp_print;
    getattrfunc tp_getattr;
    setattrfunc tp_setattr;
    cmpfunc tp_compare;
    reprfunc tp_repr;



    PyNumberMethods *tp_as_number;
    PySequenceMethods *tp_as_sequence;
    PyMappingMethods *tp_as_mapping;



    hashfunc tp_hash;
    ternaryfunc tp_call;
    reprfunc tp_str;
    getattrofunc tp_getattro;
    setattrofunc tp_setattro;


    PyBufferProcs *tp_as_buffer;


    long tp_flags;

    const char *tp_doc;



    traverseproc tp_traverse;


    inquiry tp_clear;



    richcmpfunc tp_richcompare;


    Py_ssize_t tp_weaklistoffset;



    getiterfunc tp_iter;
    iternextfunc tp_iternext;


    struct PyMethodDef *tp_methods;
    struct PyMemberDef *tp_members;
    struct PyGetSetDef *tp_getset;
    struct _typeobject *tp_base;
    PyObject *tp_dict;
    descrgetfunc tp_descr_get;
    descrsetfunc tp_descr_set;
    Py_ssize_t tp_dictoffset;
    initproc tp_init;
    allocfunc tp_alloc;
    newfunc tp_new;
    freefunc tp_free;
    inquiry tp_is_gc;
    PyObject *tp_bases;
    PyObject *tp_mro;
    PyObject *tp_cache;
    PyObject *tp_subclasses;
    PyObject *tp_weaklist;
    destructor tp_del;


    unsigned int tp_version_tag;
# 411 "/usr/include/python2.7/object.h"
} PyTypeObject;



typedef struct _heaptypeobject {


    PyTypeObject ht_type;
    PyNumberMethods as_number;
    PyMappingMethods as_mapping;
    PySequenceMethods as_sequence;




    PyBufferProcs as_buffer;
    PyObject *ht_name, *ht_slots;

} PyHeapTypeObject;







int PyType_IsSubtype(PyTypeObject *, PyTypeObject *);



extern PyTypeObject PyType_Type;
extern PyTypeObject PyBaseObject_Type;
extern PyTypeObject PySuper_Type;





int PyType_Ready(PyTypeObject *);
PyObject * PyType_GenericAlloc(PyTypeObject *, Py_ssize_t);
PyObject * PyType_GenericNew(PyTypeObject *,
                                               PyObject *, PyObject *);
PyObject * _PyType_Lookup(PyTypeObject *, PyObject *);
PyObject * _PyObject_LookupSpecial(PyObject *, char *, PyObject **);
unsigned int PyType_ClearCache(void);
void PyType_Modified(PyTypeObject *);


int PyObject_Print(PyObject *, FILE *, int);
void _PyObject_Dump(PyObject *);
PyObject * PyObject_Repr(PyObject *);
PyObject * _PyObject_Str(PyObject *);
PyObject * PyObject_Str(PyObject *);


PyObject * PyObject_Unicode(PyObject *);

int PyObject_Compare(PyObject *, PyObject *);
PyObject * PyObject_RichCompare(PyObject *, PyObject *, int);
int PyObject_RichCompareBool(PyObject *, PyObject *, int);
PyObject * PyObject_GetAttrString(PyObject *, const char *);
int PyObject_SetAttrString(PyObject *, const char *, PyObject *);
int PyObject_HasAttrString(PyObject *, const char *);
PyObject * PyObject_GetAttr(PyObject *, PyObject *);
int PyObject_SetAttr(PyObject *, PyObject *, PyObject *);
int PyObject_HasAttr(PyObject *, PyObject *);
PyObject ** _PyObject_GetDictPtr(PyObject *);
PyObject * PyObject_SelfIter(PyObject *);
PyObject * _PyObject_NextNotImplemented(PyObject *);
PyObject * PyObject_GenericGetAttr(PyObject *, PyObject *);
int PyObject_GenericSetAttr(PyObject *,
                                              PyObject *, PyObject *);
long PyObject_Hash(PyObject *);
long PyObject_HashNotImplemented(PyObject *);
int PyObject_IsTrue(PyObject *);
int PyObject_Not(PyObject *);
int PyCallable_Check(PyObject *);
int PyNumber_Coerce(PyObject **, PyObject **);
int PyNumber_CoerceEx(PyObject **, PyObject **);

void PyObject_ClearWeakRefs(PyObject *);


extern int _PyObject_SlotCompare(PyObject *, PyObject *);


PyObject *
_PyObject_GenericGetAttrWithDict(PyObject *, PyObject *, PyObject *);
int
_PyObject_GenericSetAttrWithDict(PyObject *, PyObject *,
                                 PyObject *, PyObject *);







PyObject * PyObject_Dir(PyObject *);



int Py_ReprEnter(PyObject *);
void Py_ReprLeave(PyObject *);


long _Py_HashDouble(double);
long _Py_HashPointer(void*);
# 819 "/usr/include/python2.7/object.h"
void Py_IncRef(PyObject *);
void Py_DecRef(PyObject *);







extern PyObject _Py_NoneStruct;
# 838 "/usr/include/python2.7/object.h"
extern PyObject _Py_NotImplementedStruct;
# 852 "/usr/include/python2.7/object.h"
extern int _Py_SwappedOp[];
# 964 "/usr/include/python2.7/object.h"
void _PyTrash_deposit_object(PyObject*);
void _PyTrash_destroy_chain(void);
extern int _PyTrash_delete_nesting;
extern PyObject * _PyTrash_delete_later;
# 81 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/objimpl.h" 1
# 97 "/usr/include/python2.7/objimpl.h"
void * PyObject_Malloc(size_t);
void * PyObject_Realloc(void *, size_t);
void PyObject_Free(void *);
# 150 "/usr/include/python2.7/objimpl.h"
PyObject * PyObject_Init(PyObject *, PyTypeObject *);
PyVarObject * PyObject_InitVar(PyVarObject *,
                                                 PyTypeObject *, Py_ssize_t);
PyObject * _PyObject_New(PyTypeObject *);
PyVarObject * _PyObject_NewVar(PyTypeObject *, Py_ssize_t);
# 235 "/usr/include/python2.7/objimpl.h"
Py_ssize_t PyGC_Collect(void);
# 244 "/usr/include/python2.7/objimpl.h"
PyVarObject * _PyObject_GC_Resize(PyVarObject *, Py_ssize_t);







typedef union _gc_head {
    struct {
        union _gc_head *gc_next;
        union _gc_head *gc_prev;
        Py_ssize_t gc_refs;
    } gc;
    long double dummy;
} PyGC_Head;

extern PyGC_Head *_PyGC_generation0;
# 306 "/usr/include/python2.7/objimpl.h"
PyObject * _PyObject_GC_Malloc(size_t);
PyObject * _PyObject_GC_New(PyTypeObject *);
PyVarObject * _PyObject_GC_NewVar(PyTypeObject *, Py_ssize_t);
void PyObject_GC_Track(void *);
void PyObject_GC_UnTrack(void *);
void PyObject_GC_Del(void *);
# 82 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/pydebug.h" 1







extern int Py_DebugFlag;
extern int Py_VerboseFlag;
extern int Py_InteractiveFlag;
extern int Py_InspectFlag;
extern int Py_OptimizeFlag;
extern int Py_NoSiteFlag;
extern int Py_BytesWarningFlag;
extern int Py_UseClassExceptionsFlag;
extern int Py_FrozenFlag;
extern int Py_TabcheckFlag;
extern int Py_UnicodeFlag;
extern int Py_IgnoreEnvironmentFlag;
extern int Py_DivisionWarningFlag;
extern int Py_DontWriteBytecodeFlag;
extern int Py_NoUserSiteDirectory;



extern int _Py_QnewFlag;

extern int Py_Py3kWarningFlag;






void Py_FatalError(const char *message);
# 84 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/unicodeobject.h" 1




# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stdarg.h" 1 3 4
# 5 "/usr/include/python2.7/unicodeobject.h" 2
# 57 "/usr/include/python2.7/unicodeobject.h"

# 1 "/usr/include/ctype.h" 1 3 4
# 30 "/usr/include/ctype.h" 3 4
# 48 "/usr/include/ctype.h" 3 4
enum
{
  _ISupper = ((0) < 8 ? ((1 << (0)) << 8) : ((1 << (0)) >> 8)),
  _ISlower = ((1) < 8 ? ((1 << (1)) << 8) : ((1 << (1)) >> 8)),
  _ISalpha = ((2) < 8 ? ((1 << (2)) << 8) : ((1 << (2)) >> 8)),
  _ISdigit = ((3) < 8 ? ((1 << (3)) << 8) : ((1 << (3)) >> 8)),
  _ISxdigit = ((4) < 8 ? ((1 << (4)) << 8) : ((1 << (4)) >> 8)),
  _ISspace = ((5) < 8 ? ((1 << (5)) << 8) : ((1 << (5)) >> 8)),
  _ISprint = ((6) < 8 ? ((1 << (6)) << 8) : ((1 << (6)) >> 8)),
  _ISgraph = ((7) < 8 ? ((1 << (7)) << 8) : ((1 << (7)) >> 8)),
  _ISblank = ((8) < 8 ? ((1 << (8)) << 8) : ((1 << (8)) >> 8)),
  _IScntrl = ((9) < 8 ? ((1 << (9)) << 8) : ((1 << (9)) >> 8)),
  _ISpunct = ((10) < 8 ? ((1 << (10)) << 8) : ((1 << (10)) >> 8)),
  _ISalnum = ((11) < 8 ? ((1 << (11)) << 8) : ((1 << (11)) >> 8))
};
# 81 "/usr/include/ctype.h" 3 4
extern __const unsigned short int **__ctype_b_loc (void)
     __attribute__ ((__nothrow__)) __attribute__ ((__const));
extern __const __int32_t **__ctype_tolower_loc (void)
     __attribute__ ((__nothrow__)) __attribute__ ((__const));
extern __const __int32_t **__ctype_toupper_loc (void)
     __attribute__ ((__nothrow__)) __attribute__ ((__const));
# 96 "/usr/include/ctype.h" 3 4






extern int isalnum (int) __attribute__ ((__nothrow__));
extern int isalpha (int) __attribute__ ((__nothrow__));
extern int iscntrl (int) __attribute__ ((__nothrow__));
extern int isdigit (int) __attribute__ ((__nothrow__));
extern int islower (int) __attribute__ ((__nothrow__));
extern int isgraph (int) __attribute__ ((__nothrow__));
extern int isprint (int) __attribute__ ((__nothrow__));
extern int ispunct (int) __attribute__ ((__nothrow__));
extern int isspace (int) __attribute__ ((__nothrow__));
extern int isupper (int) __attribute__ ((__nothrow__));
extern int isxdigit (int) __attribute__ ((__nothrow__));



extern int tolower (int __c) __attribute__ ((__nothrow__));


extern int toupper (int __c) __attribute__ ((__nothrow__));
# 128 "/usr/include/ctype.h" 3 4
extern int isblank (int) __attribute__ ((__nothrow__));






extern int isctype (int __c, int __mask) __attribute__ ((__nothrow__));






extern int isascii (int __c) __attribute__ ((__nothrow__));



extern int toascii (int __c) __attribute__ ((__nothrow__));



extern int _toupper (int) __attribute__ ((__nothrow__));
extern int _tolower (int) __attribute__ ((__nothrow__));
# 247 "/usr/include/ctype.h" 3 4
extern int isalnum_l (int, __locale_t) __attribute__ ((__nothrow__));
extern int isalpha_l (int, __locale_t) __attribute__ ((__nothrow__));
extern int iscntrl_l (int, __locale_t) __attribute__ ((__nothrow__));
extern int isdigit_l (int, __locale_t) __attribute__ ((__nothrow__));
extern int islower_l (int, __locale_t) __attribute__ ((__nothrow__));
extern int isgraph_l (int, __locale_t) __attribute__ ((__nothrow__));
extern int isprint_l (int, __locale_t) __attribute__ ((__nothrow__));
extern int ispunct_l (int, __locale_t) __attribute__ ((__nothrow__));
extern int isspace_l (int, __locale_t) __attribute__ ((__nothrow__));
extern int isupper_l (int, __locale_t) __attribute__ ((__nothrow__));
extern int isxdigit_l (int, __locale_t) __attribute__ ((__nothrow__));

extern int isblank_l (int, __locale_t) __attribute__ ((__nothrow__));



extern int __tolower_l (int __c, __locale_t __l) __attribute__ ((__nothrow__));
extern int tolower_l (int __c, __locale_t __l) __attribute__ ((__nothrow__));


extern int __toupper_l (int __c, __locale_t __l) __attribute__ ((__nothrow__));
extern int toupper_l (int __c, __locale_t __l) __attribute__ ((__nothrow__));
# 323 "/usr/include/ctype.h" 3 4
# 58 "/usr/include/python2.7/unicodeobject.h" 2
# 120 "/usr/include/python2.7/unicodeobject.h"

# 1 "/usr/include/wchar.h" 1 3 4
# 52 "/usr/include/wchar.h" 3 4

# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 1 3 4
# 352 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 3 4
typedef unsigned int wint_t;
# 53 "/usr/include/wchar.h" 2 3 4
# 104 "/usr/include/wchar.h" 3 4


typedef __mbstate_t mbstate_t;
# 129 "/usr/include/wchar.h" 3 4





struct tm;
# 144 "/usr/include/wchar.h" 3 4
extern wchar_t *wcscpy (wchar_t *__restrict __dest,
   __const wchar_t *__restrict __src) __attribute__ ((__nothrow__));

extern wchar_t *wcsncpy (wchar_t *__restrict __dest,
    __const wchar_t *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__));


extern wchar_t *wcscat (wchar_t *__restrict __dest,
   __const wchar_t *__restrict __src) __attribute__ ((__nothrow__));

extern wchar_t *wcsncat (wchar_t *__restrict __dest,
    __const wchar_t *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__));


extern int wcscmp (__const wchar_t *__s1, __const wchar_t *__s2)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));

extern int wcsncmp (__const wchar_t *__s1, __const wchar_t *__s2, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));




extern int wcscasecmp (__const wchar_t *__s1, __const wchar_t *__s2) __attribute__ ((__nothrow__));


extern int wcsncasecmp (__const wchar_t *__s1, __const wchar_t *__s2,
   size_t __n) __attribute__ ((__nothrow__));





extern int wcscasecmp_l (__const wchar_t *__s1, __const wchar_t *__s2,
    __locale_t __loc) __attribute__ ((__nothrow__));

extern int wcsncasecmp_l (__const wchar_t *__s1, __const wchar_t *__s2,
     size_t __n, __locale_t __loc) __attribute__ ((__nothrow__));





extern int wcscoll (__const wchar_t *__s1, __const wchar_t *__s2) __attribute__ ((__nothrow__));



extern size_t wcsxfrm (wchar_t *__restrict __s1,
         __const wchar_t *__restrict __s2, size_t __n) __attribute__ ((__nothrow__));
# 203 "/usr/include/wchar.h" 3 4
extern int wcscoll_l (__const wchar_t *__s1, __const wchar_t *__s2,
        __locale_t __loc) __attribute__ ((__nothrow__));




extern size_t wcsxfrm_l (wchar_t *__s1, __const wchar_t *__s2,
    size_t __n, __locale_t __loc) __attribute__ ((__nothrow__));


extern wchar_t *wcsdup (__const wchar_t *__s) __attribute__ ((__nothrow__)) __attribute__ ((__malloc__));
# 224 "/usr/include/wchar.h" 3 4
extern wchar_t *wcschr (__const wchar_t *__wcs, wchar_t __wc)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));
# 234 "/usr/include/wchar.h" 3 4
extern wchar_t *wcsrchr (__const wchar_t *__wcs, wchar_t __wc)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));






extern wchar_t *wcschrnul (__const wchar_t *__s, wchar_t __wc)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));





extern size_t wcscspn (__const wchar_t *__wcs, __const wchar_t *__reject)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));


extern size_t wcsspn (__const wchar_t *__wcs, __const wchar_t *__accept)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));
# 263 "/usr/include/wchar.h" 3 4
extern wchar_t *wcspbrk (__const wchar_t *__wcs, __const wchar_t *__accept)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));
# 274 "/usr/include/wchar.h" 3 4
extern wchar_t *wcsstr (__const wchar_t *__haystack, __const wchar_t *__needle)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));



extern wchar_t *wcstok (wchar_t *__restrict __s,
   __const wchar_t *__restrict __delim,
   wchar_t **__restrict __ptr) __attribute__ ((__nothrow__));


extern size_t wcslen (__const wchar_t *__s) __attribute__ ((__nothrow__)) __attribute__ ((__pure__));
# 296 "/usr/include/wchar.h" 3 4
extern wchar_t *wcswcs (__const wchar_t *__haystack, __const wchar_t *__needle)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));





extern size_t wcsnlen (__const wchar_t *__s, size_t __maxlen)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));
# 317 "/usr/include/wchar.h" 3 4
extern wchar_t *wmemchr (__const wchar_t *__s, wchar_t __c, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));



extern int wmemcmp (__const wchar_t *__restrict __s1,
      __const wchar_t *__restrict __s2, size_t __n)
     __attribute__ ((__nothrow__)) __attribute__ ((__pure__));


extern wchar_t *wmemcpy (wchar_t *__restrict __s1,
    __const wchar_t *__restrict __s2, size_t __n) __attribute__ ((__nothrow__));



extern wchar_t *wmemmove (wchar_t *__s1, __const wchar_t *__s2, size_t __n)
     __attribute__ ((__nothrow__));


extern wchar_t *wmemset (wchar_t *__s, wchar_t __c, size_t __n) __attribute__ ((__nothrow__));





extern wchar_t *wmempcpy (wchar_t *__restrict __s1,
     __const wchar_t *__restrict __s2, size_t __n)
     __attribute__ ((__nothrow__));






extern wint_t btowc (int __c) __attribute__ ((__nothrow__));



extern int wctob (wint_t __c) __attribute__ ((__nothrow__));



extern int mbsinit (__const mbstate_t *__ps) __attribute__ ((__nothrow__)) __attribute__ ((__pure__));



extern size_t mbrtowc (wchar_t *__restrict __pwc,
         __const char *__restrict __s, size_t __n,
         mbstate_t *__p) __attribute__ ((__nothrow__));


extern size_t wcrtomb (char *__restrict __s, wchar_t __wc,
         mbstate_t *__restrict __ps) __attribute__ ((__nothrow__));


extern size_t __mbrlen (__const char *__restrict __s, size_t __n,
   mbstate_t *__restrict __ps) __attribute__ ((__nothrow__));
extern size_t mbrlen (__const char *__restrict __s, size_t __n,
        mbstate_t *__restrict __ps) __attribute__ ((__nothrow__));
# 403 "/usr/include/wchar.h" 3 4



extern size_t mbsrtowcs (wchar_t *__restrict __dst,
    __const char **__restrict __src, size_t __len,
    mbstate_t *__restrict __ps) __attribute__ ((__nothrow__));



extern size_t wcsrtombs (char *__restrict __dst,
    __const wchar_t **__restrict __src, size_t __len,
    mbstate_t *__restrict __ps) __attribute__ ((__nothrow__));






extern size_t mbsnrtowcs (wchar_t *__restrict __dst,
     __const char **__restrict __src, size_t __nmc,
     size_t __len, mbstate_t *__restrict __ps) __attribute__ ((__nothrow__));



extern size_t wcsnrtombs (char *__restrict __dst,
     __const wchar_t **__restrict __src,
     size_t __nwc, size_t __len,
     mbstate_t *__restrict __ps) __attribute__ ((__nothrow__));






extern int wcwidth (wchar_t __c) __attribute__ ((__nothrow__));



extern int wcswidth (__const wchar_t *__s, size_t __n) __attribute__ ((__nothrow__));






extern double wcstod (__const wchar_t *__restrict __nptr,
        wchar_t **__restrict __endptr) __attribute__ ((__nothrow__));





extern float wcstof (__const wchar_t *__restrict __nptr,
       wchar_t **__restrict __endptr) __attribute__ ((__nothrow__));
extern long double wcstold (__const wchar_t *__restrict __nptr,
       wchar_t **__restrict __endptr) __attribute__ ((__nothrow__));







extern long int wcstol (__const wchar_t *__restrict __nptr,
   wchar_t **__restrict __endptr, int __base) __attribute__ ((__nothrow__));



extern unsigned long int wcstoul (__const wchar_t *__restrict __nptr,
      wchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__));






__extension__
extern long long int wcstoll (__const wchar_t *__restrict __nptr,
         wchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__));



__extension__
extern unsigned long long int wcstoull (__const wchar_t *__restrict __nptr,
     wchar_t **__restrict __endptr,
     int __base) __attribute__ ((__nothrow__));






__extension__
extern long long int wcstoq (__const wchar_t *__restrict __nptr,
        wchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__));



__extension__
extern unsigned long long int wcstouq (__const wchar_t *__restrict __nptr,
           wchar_t **__restrict __endptr,
           int __base) __attribute__ ((__nothrow__));
# 528 "/usr/include/wchar.h" 3 4
extern long int wcstol_l (__const wchar_t *__restrict __nptr,
     wchar_t **__restrict __endptr, int __base,
     __locale_t __loc) __attribute__ ((__nothrow__));

extern unsigned long int wcstoul_l (__const wchar_t *__restrict __nptr,
        wchar_t **__restrict __endptr,
        int __base, __locale_t __loc) __attribute__ ((__nothrow__));

__extension__
extern long long int wcstoll_l (__const wchar_t *__restrict __nptr,
    wchar_t **__restrict __endptr,
    int __base, __locale_t __loc) __attribute__ ((__nothrow__));

__extension__
extern unsigned long long int wcstoull_l (__const wchar_t *__restrict __nptr,
       wchar_t **__restrict __endptr,
       int __base, __locale_t __loc)
     __attribute__ ((__nothrow__));

extern double wcstod_l (__const wchar_t *__restrict __nptr,
   wchar_t **__restrict __endptr, __locale_t __loc)
     __attribute__ ((__nothrow__));

extern float wcstof_l (__const wchar_t *__restrict __nptr,
         wchar_t **__restrict __endptr, __locale_t __loc)
     __attribute__ ((__nothrow__));

extern long double wcstold_l (__const wchar_t *__restrict __nptr,
         wchar_t **__restrict __endptr,
         __locale_t __loc) __attribute__ ((__nothrow__));






extern wchar_t *wcpcpy (wchar_t *__dest, __const wchar_t *__src) __attribute__ ((__nothrow__));



extern wchar_t *wcpncpy (wchar_t *__dest, __const wchar_t *__src, size_t __n)
     __attribute__ ((__nothrow__));
# 578 "/usr/include/wchar.h" 3 4
extern __FILE *open_wmemstream (wchar_t **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__));






extern int fwide (__FILE *__fp, int __mode) __attribute__ ((__nothrow__));






extern int fwprintf (__FILE *__restrict __stream,
       __const wchar_t *__restrict __format, ...)
                                                           ;




extern int wprintf (__const wchar_t *__restrict __format, ...)
                                                           ;

extern int swprintf (wchar_t *__restrict __s, size_t __n,
       __const wchar_t *__restrict __format, ...)
     __attribute__ ((__nothrow__)) ;





extern int vfwprintf (__FILE *__restrict __s,
        __const wchar_t *__restrict __format,
        __gnuc_va_list __arg)
                                                           ;




extern int vwprintf (__const wchar_t *__restrict __format,
       __gnuc_va_list __arg)
                                                           ;


extern int vswprintf (wchar_t *__restrict __s, size_t __n,
        __const wchar_t *__restrict __format,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) ;






extern int fwscanf (__FILE *__restrict __stream,
      __const wchar_t *__restrict __format, ...)
                                                          ;




extern int wscanf (__const wchar_t *__restrict __format, ...)
                                                          ;

extern int swscanf (__const wchar_t *__restrict __s,
      __const wchar_t *__restrict __format, ...)
     __attribute__ ((__nothrow__)) ;
# 678 "/usr/include/wchar.h" 3 4
# 687 "/usr/include/wchar.h" 3 4
extern int vfwscanf (__FILE *__restrict __s,
       __const wchar_t *__restrict __format,
       __gnuc_va_list __arg)
                                                          ;




extern int vwscanf (__const wchar_t *__restrict __format,
      __gnuc_va_list __arg)
                                                          ;

extern int vswscanf (__const wchar_t *__restrict __s,
       __const wchar_t *__restrict __format,
       __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) ;
# 734 "/usr/include/wchar.h" 3 4
# 743 "/usr/include/wchar.h" 3 4
extern wint_t fgetwc (__FILE *__stream);
extern wint_t getwc (__FILE *__stream);





extern wint_t getwchar (void);






extern wint_t fputwc (wchar_t __wc, __FILE *__stream);
extern wint_t putwc (wchar_t __wc, __FILE *__stream);





extern wint_t putwchar (wchar_t __wc);







extern wchar_t *fgetws (wchar_t *__restrict __ws, int __n,
   __FILE *__restrict __stream);





extern int fputws (__const wchar_t *__restrict __ws,
     __FILE *__restrict __stream);






extern wint_t ungetwc (wint_t __wc, __FILE *__stream);
# 799 "/usr/include/wchar.h" 3 4
extern wint_t getwc_unlocked (__FILE *__stream);
extern wint_t getwchar_unlocked (void);







extern wint_t fgetwc_unlocked (__FILE *__stream);







extern wint_t fputwc_unlocked (wchar_t __wc, __FILE *__stream);
# 825 "/usr/include/wchar.h" 3 4
extern wint_t putwc_unlocked (wchar_t __wc, __FILE *__stream);
extern wint_t putwchar_unlocked (wchar_t __wc);
# 835 "/usr/include/wchar.h" 3 4
extern wchar_t *fgetws_unlocked (wchar_t *__restrict __ws, int __n,
     __FILE *__restrict __stream);







extern int fputws_unlocked (__const wchar_t *__restrict __ws,
       __FILE *__restrict __stream);







extern size_t wcsftime (wchar_t *__restrict __s, size_t __maxsize,
   __const wchar_t *__restrict __format,
   __const struct tm *__restrict __tp) __attribute__ ((__nothrow__));







extern size_t wcsftime_l (wchar_t *__restrict __s, size_t __maxsize,
     __const wchar_t *__restrict __format,
     __const struct tm *__restrict __tp,
     __locale_t __loc) __attribute__ ((__nothrow__));
# 889 "/usr/include/wchar.h" 3 4
# 121 "/usr/include/python2.7/unicodeobject.h" 2







typedef unsigned int Py_UCS4;
# 137 "/usr/include/python2.7/unicodeobject.h"
typedef unsigned long Py_UNICODE;
# 415 "/usr/include/python2.7/unicodeobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    Py_ssize_t length;
    Py_UNICODE *str;
    long hash;
    PyObject *defenc;


} PyUnicodeObject;

extern PyTypeObject PyUnicode_Type;
# 464 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_FromUnicode(
    const Py_UNICODE *u,
    Py_ssize_t size
    );


PyObject* PyUnicodeUCS4_FromStringAndSize(
    const char *u,
    Py_ssize_t size
    );



PyObject* PyUnicodeUCS4_FromString(
    const char *u
    );




Py_UNICODE * PyUnicodeUCS4_AsUnicode(
    PyObject *unicode
    );



Py_ssize_t PyUnicodeUCS4_GetSize(
    PyObject *unicode
    );


Py_UNICODE PyUnicodeUCS4_GetMax(void);
# 511 "/usr/include/python2.7/unicodeobject.h"
int PyUnicodeUCS4_Resize(
    PyObject **unicode,
    Py_ssize_t length
    );
# 533 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_FromEncodedObject(
    register PyObject *obj,
    const char *encoding,
    const char *errors
    );
# 552 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_FromObject(
    register PyObject *obj
    );

PyObject * PyUnicodeUCS4_FromFormatV(const char*, va_list);
PyObject * PyUnicodeUCS4_FromFormat(const char*, ...);



PyObject * _PyUnicode_FormatAdvanced(PyObject *obj,
                                                 Py_UNICODE *format_spec,
                                                 Py_ssize_t format_spec_len);
# 574 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_FromWideChar(
    register const wchar_t *w,
    Py_ssize_t size
    );
# 591 "/usr/include/python2.7/unicodeobject.h"
Py_ssize_t PyUnicodeUCS4_AsWideChar(
    PyUnicodeObject *unicode,
    register wchar_t *w,
    Py_ssize_t size
    );
# 609 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_FromOrdinal(int ordinal);
# 620 "/usr/include/python2.7/unicodeobject.h"
int PyUnicodeUCS4_ClearFreelist(void);
# 656 "/usr/include/python2.7/unicodeobject.h"
PyObject * _PyUnicodeUCS4_AsDefaultEncodedString(
    PyObject *, const char *);
# 668 "/usr/include/python2.7/unicodeobject.h"
const char* PyUnicodeUCS4_GetDefaultEncoding(void);







int PyUnicodeUCS4_SetDefaultEncoding(
    const char *encoding
    );






PyObject* PyUnicodeUCS4_Decode(
    const char *s,
    Py_ssize_t size,
    const char *encoding,
    const char *errors
    );




PyObject* PyUnicodeUCS4_Encode(
    const Py_UNICODE *s,
    Py_ssize_t size,
    const char *encoding,
    const char *errors
    );




PyObject* PyUnicodeUCS4_AsEncodedObject(
    PyObject *unicode,
    const char *encoding,
    const char *errors
    );




PyObject* PyUnicodeUCS4_AsEncodedString(
    PyObject *unicode,
    const char *encoding,
    const char *errors
    );

PyObject* PyUnicode_BuildEncodingMap(
    PyObject* string
   );




PyObject* PyUnicode_DecodeUTF7(
    const char *string,
    Py_ssize_t length,
    const char *errors
    );

PyObject* PyUnicode_DecodeUTF7Stateful(
    const char *string,
    Py_ssize_t length,
    const char *errors,
    Py_ssize_t *consumed
    );

PyObject* PyUnicode_EncodeUTF7(
    const Py_UNICODE *data,
    Py_ssize_t length,
    int base64SetO,
    int base64WhiteSpace,
    const char *errors
    );



PyObject* PyUnicodeUCS4_DecodeUTF8(
    const char *string,
    Py_ssize_t length,
    const char *errors
    );

PyObject* PyUnicodeUCS4_DecodeUTF8Stateful(
    const char *string,
    Py_ssize_t length,
    const char *errors,
    Py_ssize_t *consumed
    );

PyObject* PyUnicodeUCS4_AsUTF8String(
    PyObject *unicode
    );

PyObject* PyUnicodeUCS4_EncodeUTF8(
    const Py_UNICODE *data,
    Py_ssize_t length,
    const char *errors
    );
# 798 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_DecodeUTF32(
    const char *string,
    Py_ssize_t length,
    const char *errors,
    int *byteorder


    );

PyObject* PyUnicodeUCS4_DecodeUTF32Stateful(
    const char *string,
    Py_ssize_t length,
    const char *errors,
    int *byteorder,


    Py_ssize_t *consumed
    );




PyObject* PyUnicodeUCS4_AsUTF32String(
    PyObject *unicode
    );
# 840 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_EncodeUTF32(
    const Py_UNICODE *data,
    Py_ssize_t length,
    const char *errors,
    int byteorder
    );
# 872 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_DecodeUTF16(
    const char *string,
    Py_ssize_t length,
    const char *errors,
    int *byteorder


    );

PyObject* PyUnicodeUCS4_DecodeUTF16Stateful(
    const char *string,
    Py_ssize_t length,
    const char *errors,
    int *byteorder,


    Py_ssize_t *consumed
    );




PyObject* PyUnicodeUCS4_AsUTF16String(
    PyObject *unicode
    );
# 918 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_EncodeUTF16(
    const Py_UNICODE *data,
    Py_ssize_t length,
    const char *errors,
    int byteorder
    );



PyObject* PyUnicodeUCS4_DecodeUnicodeEscape(
    const char *string,
    Py_ssize_t length,
    const char *errors
    );

PyObject* PyUnicodeUCS4_AsUnicodeEscapeString(
    PyObject *unicode
    );

PyObject* PyUnicodeUCS4_EncodeUnicodeEscape(
    const Py_UNICODE *data,
    Py_ssize_t length
    );



PyObject* PyUnicodeUCS4_DecodeRawUnicodeEscape(
    const char *string,
    Py_ssize_t length,
    const char *errors
    );

PyObject* PyUnicodeUCS4_AsRawUnicodeEscapeString(
    PyObject *unicode
    );

PyObject* PyUnicodeUCS4_EncodeRawUnicodeEscape(
    const Py_UNICODE *data,
    Py_ssize_t length
    );





PyObject *_PyUnicode_DecodeUnicodeInternal(
    const char *string,
    Py_ssize_t length,
    const char *errors
    );







PyObject* PyUnicodeUCS4_DecodeLatin1(
    const char *string,
    Py_ssize_t length,
    const char *errors
    );

PyObject* PyUnicodeUCS4_AsLatin1String(
    PyObject *unicode
    );

PyObject* PyUnicodeUCS4_EncodeLatin1(
    const Py_UNICODE *data,
    Py_ssize_t length,
    const char *errors
    );







PyObject* PyUnicodeUCS4_DecodeASCII(
    const char *string,
    Py_ssize_t length,
    const char *errors
    );

PyObject* PyUnicodeUCS4_AsASCIIString(
    PyObject *unicode
    );

PyObject* PyUnicodeUCS4_EncodeASCII(
    const Py_UNICODE *data,
    Py_ssize_t length,
    const char *errors
    );
# 1035 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_DecodeCharmap(
    const char *string,
    Py_ssize_t length,
    PyObject *mapping,

    const char *errors
    );

PyObject* PyUnicodeUCS4_AsCharmapString(
    PyObject *unicode,
    PyObject *mapping

    );

PyObject* PyUnicodeUCS4_EncodeCharmap(
    const Py_UNICODE *data,
    Py_ssize_t length,
    PyObject *mapping,

    const char *errors
    );
# 1070 "/usr/include/python2.7/unicodeobject.h"
PyObject * PyUnicodeUCS4_TranslateCharmap(
    const Py_UNICODE *data,
    Py_ssize_t length,
    PyObject *table,
    const char *errors
    );
# 1130 "/usr/include/python2.7/unicodeobject.h"
int PyUnicodeUCS4_EncodeDecimal(
    Py_UNICODE *s,
    Py_ssize_t length,
    char *output,
    const char *errors
    );
# 1145 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_Concat(
    PyObject *left,
    PyObject *right
    );
# 1161 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_Split(
    PyObject *s,
    PyObject *sep,
    Py_ssize_t maxsplit
    );






PyObject* PyUnicodeUCS4_Splitlines(
    PyObject *s,
    int keepends
    );



PyObject* PyUnicodeUCS4_Partition(
    PyObject *s,
    PyObject *sep
    );




PyObject* PyUnicodeUCS4_RPartition(
    PyObject *s,
    PyObject *sep
    );
# 1205 "/usr/include/python2.7/unicodeobject.h"
PyObject* PyUnicodeUCS4_RSplit(
    PyObject *s,
    PyObject *sep,
    Py_ssize_t maxsplit
    );
# 1223 "/usr/include/python2.7/unicodeobject.h"
PyObject * PyUnicodeUCS4_Translate(
    PyObject *str,
    PyObject *table,
    const char *errors
    );




PyObject* PyUnicodeUCS4_Join(
    PyObject *separator,
    PyObject *seq
    );




Py_ssize_t PyUnicodeUCS4_Tailmatch(
    PyObject *str,
    PyObject *substr,
    Py_ssize_t start,
    Py_ssize_t end,
    int direction
    );





Py_ssize_t PyUnicodeUCS4_Find(
    PyObject *str,
    PyObject *substr,
    Py_ssize_t start,
    Py_ssize_t end,
    int direction
    );



Py_ssize_t PyUnicodeUCS4_Count(
    PyObject *str,
    PyObject *substr,
    Py_ssize_t start,
    Py_ssize_t end
    );




PyObject * PyUnicodeUCS4_Replace(
    PyObject *str,
    PyObject *substr,
    PyObject *replstr,
    Py_ssize_t maxcount

    );




int PyUnicodeUCS4_Compare(
    PyObject *left,
    PyObject *right
    );
# 1304 "/usr/include/python2.7/unicodeobject.h"
PyObject * PyUnicodeUCS4_RichCompare(
    PyObject *left,
    PyObject *right,
    int op
    );




PyObject * PyUnicodeUCS4_Format(
    PyObject *format,
    PyObject *args
    );







int PyUnicodeUCS4_Contains(
    PyObject *container,
    PyObject *element
    );


PyObject * _PyUnicode_XStrip(
    PyUnicodeObject *self,
    int striptype,
    PyObject *sepobj
    );





extern const unsigned char _Py_ascii_whitespace[];
# 1349 "/usr/include/python2.7/unicodeobject.h"
int _PyUnicodeUCS4_IsLowercase(
    Py_UNICODE ch
    );

int _PyUnicodeUCS4_IsUppercase(
    Py_UNICODE ch
    );

int _PyUnicodeUCS4_IsTitlecase(
    Py_UNICODE ch
    );

int _PyUnicodeUCS4_IsWhitespace(
    const Py_UNICODE ch
    );

int _PyUnicodeUCS4_IsLinebreak(
    const Py_UNICODE ch
    );

Py_UNICODE _PyUnicodeUCS4_ToLowercase(
    Py_UNICODE ch
    );

Py_UNICODE _PyUnicodeUCS4_ToUppercase(
    Py_UNICODE ch
    );

Py_UNICODE _PyUnicodeUCS4_ToTitlecase(
    Py_UNICODE ch
    );

int _PyUnicodeUCS4_ToDecimalDigit(
    Py_UNICODE ch
    );

int _PyUnicodeUCS4_ToDigit(
    Py_UNICODE ch
    );

double _PyUnicodeUCS4_ToNumeric(
    Py_UNICODE ch
    );

int _PyUnicodeUCS4_IsDecimalDigit(
    Py_UNICODE ch
    );

int _PyUnicodeUCS4_IsDigit(
    Py_UNICODE ch
    );

int _PyUnicodeUCS4_IsNumeric(
    Py_UNICODE ch
    );

int _PyUnicodeUCS4_IsAlpha(
    Py_UNICODE ch
    );
# 86 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/intobject.h" 1
# 23 "/usr/include/python2.7/intobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    long ob_ival;
} PyIntObject;

extern PyTypeObject PyInt_Type;





PyObject * PyInt_FromString(char*, char**, int);

PyObject * PyInt_FromUnicode(Py_UNICODE*, Py_ssize_t, int);

PyObject * PyInt_FromLong(long);
PyObject * PyInt_FromSize_t(size_t);
PyObject * PyInt_FromSsize_t(Py_ssize_t);
long PyInt_AsLong(PyObject *);
Py_ssize_t PyInt_AsSsize_t(PyObject *);
unsigned long PyInt_AsUnsignedLongMask(PyObject *);

unsigned long long PyInt_AsUnsignedLongLongMask(PyObject *);


long PyInt_GetMax(void);
# 59 "/usr/include/python2.7/intobject.h"
unsigned long PyOS_strtoul(char *, char **, int);
long PyOS_strtol(char *, char **, int);


int PyInt_ClearFreeList(void);





PyObject* _PyInt_Format(PyIntObject* v, int base, int newstyle);



PyObject * _PyInt_FormatAdvanced(PyObject *obj,
          char *format_spec,
          Py_ssize_t format_spec_len);
# 87 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/boolobject.h" 1
# 10 "/usr/include/python2.7/boolobject.h"
typedef PyIntObject PyBoolObject;

extern PyTypeObject PyBool_Type;







extern PyIntObject _Py_ZeroStruct, _Py_TrueStruct;
# 31 "/usr/include/python2.7/boolobject.h"
PyObject * PyBool_FromLong(long);
# 88 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/longobject.h" 1
# 10 "/usr/include/python2.7/longobject.h"
typedef struct _longobject PyLongObject;

extern PyTypeObject PyLong_Type;





PyObject * PyLong_FromLong(long);
PyObject * PyLong_FromUnsignedLong(unsigned long);
PyObject * PyLong_FromDouble(double);
PyObject * PyLong_FromSize_t(size_t);
PyObject * PyLong_FromSsize_t(Py_ssize_t);
long PyLong_AsLong(PyObject *);
long PyLong_AsLongAndOverflow(PyObject *, int *);
unsigned long PyLong_AsUnsignedLong(PyObject *);
unsigned long PyLong_AsUnsignedLongMask(PyObject *);
Py_ssize_t PyLong_AsSsize_t(PyObject *);
PyObject * PyLong_GetInfo(void);





extern int _PyLong_DigitValue[256];







double _PyLong_Frexp(PyLongObject *a, Py_ssize_t *e);

double PyLong_AsDouble(PyObject *);
PyObject * PyLong_FromVoidPtr(void *);
void * PyLong_AsVoidPtr(PyObject *);


PyObject * PyLong_FromLongLong(long long);
PyObject * PyLong_FromUnsignedLongLong(unsigned long long);
long long PyLong_AsLongLong(PyObject *);
unsigned long long PyLong_AsUnsignedLongLong(PyObject *);
unsigned long long PyLong_AsUnsignedLongLongMask(PyObject *);
long long PyLong_AsLongLongAndOverflow(PyObject *, int *);


PyObject * PyLong_FromString(char *, char **, int);

PyObject * PyLong_FromUnicode(Py_UNICODE*, Py_ssize_t, int);






int _PyLong_Sign(PyObject *v);
# 76 "/usr/include/python2.7/longobject.h"
size_t _PyLong_NumBits(PyObject *v);
# 91 "/usr/include/python2.7/longobject.h"
PyObject * _PyLong_FromByteArray(
 const unsigned char* bytes, size_t n,
 int little_endian, int is_signed);
# 114 "/usr/include/python2.7/longobject.h"
int _PyLong_AsByteArray(PyLongObject* v,
 unsigned char* bytes, size_t n,
 int little_endian, int is_signed);






PyObject * _PyLong_Format(PyObject *aa, int base, int addL, int newstyle);



PyObject * _PyLong_FormatAdvanced(PyObject *obj,
           char *format_spec,
           Py_ssize_t format_spec_len);
# 89 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/floatobject.h" 1
# 14 "/usr/include/python2.7/floatobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    double ob_fval;
} PyFloatObject;

extern PyTypeObject PyFloat_Type;
# 41 "/usr/include/python2.7/floatobject.h"
double PyFloat_GetMax(void);
double PyFloat_GetMin(void);
PyObject * PyFloat_GetInfo(void);




PyObject * PyFloat_FromString(PyObject*, char** junk);


PyObject * PyFloat_FromDouble(double);



double PyFloat_AsDouble(PyObject *);






void PyFloat_AsReprString(char*, PyFloatObject *v);






void PyFloat_AsString(char*, PyFloatObject *v);
# 103 "/usr/include/python2.7/floatobject.h"
int _PyFloat_Pack4(double x, unsigned char *p, int le);
int _PyFloat_Pack8(double x, unsigned char *p, int le);


int _PyFloat_Digits(char *buf, double v, int *signum);
void _PyFloat_DigitsInit(void);
# 118 "/usr/include/python2.7/floatobject.h"
double _PyFloat_Unpack4(const unsigned char *p, int le);
double _PyFloat_Unpack8(const unsigned char *p, int le);


int PyFloat_ClearFreeList(void);



PyObject * _PyFloat_FormatAdvanced(PyObject *obj,
            char *format_spec,
            Py_ssize_t format_spec_len);




PyObject * _Py_double_round(double x, int ndigits);
# 90 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/complexobject.h" 1
# 9 "/usr/include/python2.7/complexobject.h"
typedef struct {
    double real;
    double imag;
} Py_complex;
# 24 "/usr/include/python2.7/complexobject.h"
Py_complex _Py_c_sum(Py_complex, Py_complex);
Py_complex _Py_c_diff(Py_complex, Py_complex);
Py_complex _Py_c_neg(Py_complex);
Py_complex _Py_c_prod(Py_complex, Py_complex);
Py_complex _Py_c_quot(Py_complex, Py_complex);
Py_complex _Py_c_pow(Py_complex, Py_complex);
double _Py_c_abs(Py_complex);
# 40 "/usr/include/python2.7/complexobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    Py_complex cval;
} PyComplexObject;

extern PyTypeObject PyComplex_Type;




PyObject * PyComplex_FromCComplex(Py_complex);
PyObject * PyComplex_FromDoubles(double real, double imag);

double PyComplex_RealAsDouble(PyObject *op);
double PyComplex_ImagAsDouble(PyObject *op);
Py_complex PyComplex_AsCComplex(PyObject *op);



PyObject * _PyComplex_FormatAdvanced(PyObject *obj,
                                                 char *format_spec,
                                                 Py_ssize_t format_spec_len);
# 92 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/rangeobject.h" 1
# 21 "/usr/include/python2.7/rangeobject.h"
extern PyTypeObject PyRange_Type;
# 94 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/stringobject.h" 1
# 35 "/usr/include/python2.7/stringobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type; Py_ssize_t ob_size;
    long ob_shash;
    int ob_sstate;
    char ob_sval[1];
# 49 "/usr/include/python2.7/stringobject.h"
} PyStringObject;





extern PyTypeObject PyBaseString_Type;
extern PyTypeObject PyString_Type;





PyObject * PyString_FromStringAndSize(const char *, Py_ssize_t);
PyObject * PyString_FromString(const char *);
PyObject * PyString_FromFormatV(const char*, va_list)
    __attribute__((format(printf, 1, 0)));
PyObject * PyString_FromFormat(const char*, ...)
    __attribute__((format(printf, 1, 2)));
Py_ssize_t PyString_Size(PyObject *);
char * PyString_AsString(PyObject *);
PyObject * PyString_Repr(PyObject *, int);
void PyString_Concat(PyObject **, PyObject *);
void PyString_ConcatAndDel(PyObject **, PyObject *);
int _PyString_Resize(PyObject **, Py_ssize_t);
int _PyString_Eq(PyObject *, PyObject*);
PyObject * PyString_Format(PyObject *, PyObject *);
PyObject * _PyString_FormatLong(PyObject*, int, int,
        int, char**, int*);
PyObject * PyString_DecodeEscape(const char *, Py_ssize_t,
         const char *, Py_ssize_t,
         const char *);

void PyString_InternInPlace(PyObject **);
void PyString_InternImmortal(PyObject **);
PyObject * PyString_InternFromString(const char *);
void _Py_ReleaseInternedStrings(void);
# 96 "/usr/include/python2.7/stringobject.h"
PyObject * _PyString_Join(PyObject *sep, PyObject *x);






PyObject* PyString_Decode(
    const char *s,
    Py_ssize_t size,
    const char *encoding,
    const char *errors
    );




PyObject* PyString_Encode(
    const char *s,
    Py_ssize_t size,
    const char *encoding,
    const char *errors
    );




PyObject* PyString_AsEncodedObject(
    PyObject *str,
    const char *encoding,
    const char *errors
    );
# 137 "/usr/include/python2.7/stringobject.h"
PyObject* PyString_AsEncodedString(
    PyObject *str,
    const char *encoding,
    const char *errors
    );




PyObject* PyString_AsDecodedObject(
    PyObject *str,
    const char *encoding,
    const char *errors
    );
# 160 "/usr/include/python2.7/stringobject.h"
PyObject* PyString_AsDecodedString(
    PyObject *str,
    const char *encoding,
    const char *errors
    );







int PyString_AsStringAndSize(
    register PyObject *obj,
    register char **s,
    register Py_ssize_t *len


    );





Py_ssize_t _PyString_InsertThousandsGroupingLocale(char *buffer,
                                  Py_ssize_t n_buffer,
                                  char *digits,
                                  Py_ssize_t n_digits,
                                  Py_ssize_t min_width);




Py_ssize_t _PyString_InsertThousandsGrouping(char *buffer,
                                  Py_ssize_t n_buffer,
                                  char *digits,
                                  Py_ssize_t n_digits,
                                  Py_ssize_t min_width,
                                  const char *grouping,
                                  const char *thousands_sep);



PyObject * _PyBytes_FormatAdvanced(PyObject *obj,
            char *format_spec,
            Py_ssize_t format_spec_len);
# 95 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/memoryobject.h" 1
# 9 "/usr/include/python2.7/memoryobject.h"
extern PyTypeObject PyMemoryView_Type;
# 19 "/usr/include/python2.7/memoryobject.h"
PyObject * PyMemoryView_GetContiguous(PyObject *base,
        int buffertype,
        char fort);
# 54 "/usr/include/python2.7/memoryobject.h"
PyObject * PyMemoryView_FromObject(PyObject *base);

PyObject * PyMemoryView_FromBuffer(Py_buffer *info);







typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyObject *base;
    Py_buffer view;
} PyMemoryViewObject;
# 96 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/bufferobject.h" 1
# 13 "/usr/include/python2.7/bufferobject.h"
extern PyTypeObject PyBuffer_Type;





PyObject * PyBuffer_FromObject(PyObject *base,
                                           Py_ssize_t offset, Py_ssize_t size);
PyObject * PyBuffer_FromReadWriteObject(PyObject *base,
                                                    Py_ssize_t offset,
                                                    Py_ssize_t size);

PyObject * PyBuffer_FromMemory(void *ptr, Py_ssize_t size);
PyObject * PyBuffer_FromReadWriteMemory(void *ptr, Py_ssize_t size);

PyObject * PyBuffer_New(Py_ssize_t size);
# 97 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/bytesobject.h" 1
# 98 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/bytearrayobject.h" 1
# 22 "/usr/include/python2.7/bytearrayobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type; Py_ssize_t ob_size;

    int ob_exports;
    Py_ssize_t ob_alloc;
    char *ob_bytes;
} PyByteArrayObject;


extern PyTypeObject PyByteArray_Type;
extern PyTypeObject PyByteArrayIter_Type;






PyObject * PyByteArray_FromObject(PyObject *);
PyObject * PyByteArray_Concat(PyObject *, PyObject *);
PyObject * PyByteArray_FromStringAndSize(const char *, Py_ssize_t);
Py_ssize_t PyByteArray_Size(PyObject *);
char * PyByteArray_AsString(PyObject *);
int PyByteArray_Resize(PyObject *, Py_ssize_t);







extern char _PyByteArray_empty_string[];
# 99 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/tupleobject.h" 1
# 24 "/usr/include/python2.7/tupleobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type; Py_ssize_t ob_size;
    PyObject *ob_item[1];





} PyTupleObject;

extern PyTypeObject PyTuple_Type;





PyObject * PyTuple_New(Py_ssize_t size);
Py_ssize_t PyTuple_Size(PyObject *);
PyObject * PyTuple_GetItem(PyObject *, Py_ssize_t);
int PyTuple_SetItem(PyObject *, Py_ssize_t, PyObject *);
PyObject * PyTuple_GetSlice(PyObject *, Py_ssize_t, Py_ssize_t);
int _PyTuple_Resize(PyObject **, Py_ssize_t);
PyObject * PyTuple_Pack(Py_ssize_t, ...);
void _PyTuple_MaybeUntrack(PyObject *);
# 56 "/usr/include/python2.7/tupleobject.h"
int PyTuple_ClearFreeList(void);
# 100 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/listobject.h" 1
# 22 "/usr/include/python2.7/listobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type; Py_ssize_t ob_size;

    PyObject **ob_item;
# 38 "/usr/include/python2.7/listobject.h"
    Py_ssize_t allocated;
} PyListObject;

extern PyTypeObject PyList_Type;





PyObject * PyList_New(Py_ssize_t size);
Py_ssize_t PyList_Size(PyObject *);
PyObject * PyList_GetItem(PyObject *, Py_ssize_t);
int PyList_SetItem(PyObject *, Py_ssize_t, PyObject *);
int PyList_Insert(PyObject *, Py_ssize_t, PyObject *);
int PyList_Append(PyObject *, PyObject *);
PyObject * PyList_GetSlice(PyObject *, Py_ssize_t, Py_ssize_t);
int PyList_SetSlice(PyObject *, Py_ssize_t, Py_ssize_t, PyObject *);
int PyList_Sort(PyObject *);
int PyList_Reverse(PyObject *);
PyObject * PyList_AsTuple(PyObject *);
PyObject * _PyList_Extend(PyListObject *, PyObject *);
# 101 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/dictobject.h" 1
# 50 "/usr/include/python2.7/dictobject.h"
typedef struct {




    Py_ssize_t me_hash;
    PyObject *me_key;
    PyObject *me_value;
} PyDictEntry;
# 69 "/usr/include/python2.7/dictobject.h"
typedef struct _dictobject PyDictObject;
struct _dictobject {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    Py_ssize_t ma_fill;
    Py_ssize_t ma_used;





    Py_ssize_t ma_mask;






    PyDictEntry *ma_table;
    PyDictEntry *(*ma_lookup)(PyDictObject *mp, PyObject *key, long hash);
    PyDictEntry ma_smalltable[8];
};

extern PyTypeObject PyDict_Type;
extern PyTypeObject PyDictIterKey_Type;
extern PyTypeObject PyDictIterValue_Type;
extern PyTypeObject PyDictIterItem_Type;
extern PyTypeObject PyDictKeys_Type;
extern PyTypeObject PyDictItems_Type;
extern PyTypeObject PyDictValues_Type;
# 109 "/usr/include/python2.7/dictobject.h"
PyObject * PyDict_New(void);
PyObject * PyDict_GetItem(PyObject *mp, PyObject *key);
int PyDict_SetItem(PyObject *mp, PyObject *key, PyObject *item);
int PyDict_DelItem(PyObject *mp, PyObject *key);
void PyDict_Clear(PyObject *mp);
int PyDict_Next(
    PyObject *mp, Py_ssize_t *pos, PyObject **key, PyObject **value);
int _PyDict_Next(
    PyObject *mp, Py_ssize_t *pos, PyObject **key, PyObject **value, long *hash);
PyObject * PyDict_Keys(PyObject *mp);
PyObject * PyDict_Values(PyObject *mp);
PyObject * PyDict_Items(PyObject *mp);
Py_ssize_t PyDict_Size(PyObject *mp);
PyObject * PyDict_Copy(PyObject *mp);
int PyDict_Contains(PyObject *mp, PyObject *key);
int _PyDict_Contains(PyObject *mp, PyObject *key, long hash);
PyObject * _PyDict_NewPresized(Py_ssize_t minused);
void _PyDict_MaybeUntrack(PyObject *mp);


int PyDict_Update(PyObject *mp, PyObject *other);






int PyDict_Merge(PyObject *mp,
                                   PyObject *other,
                                   int override);






int PyDict_MergeFromSeq2(PyObject *d,
                                           PyObject *seq2,
                                           int override);

PyObject * PyDict_GetItemString(PyObject *dp, const char *key);
int PyDict_SetItemString(PyObject *dp, const char *key, PyObject *item);
int PyDict_DelItemString(PyObject *dp, const char *key);
# 102 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/enumobject.h" 1
# 10 "/usr/include/python2.7/enumobject.h"
extern PyTypeObject PyEnum_Type;
extern PyTypeObject PyReversed_Type;
# 103 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/setobject.h" 1
# 24 "/usr/include/python2.7/setobject.h"
typedef struct {
    long hash;
    PyObject *key;
} setentry;






typedef struct _setobject PySetObject;
struct _setobject {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;

    Py_ssize_t fill;
    Py_ssize_t used;





    Py_ssize_t mask;





    setentry *table;
    setentry *(*lookup)(PySetObject *so, PyObject *key, long hash);
    setentry smalltable[8];

    long hash;
    PyObject *weakreflist;
};

extern PyTypeObject PySet_Type;
extern PyTypeObject PyFrozenSet_Type;
# 83 "/usr/include/python2.7/setobject.h"
PyObject * PySet_New(PyObject *);
PyObject * PyFrozenSet_New(PyObject *);
Py_ssize_t PySet_Size(PyObject *anyset);

int PySet_Clear(PyObject *set);
int PySet_Contains(PyObject *anyset, PyObject *key);
int PySet_Discard(PyObject *set, PyObject *key);
int PySet_Add(PyObject *set, PyObject *key);
int _PySet_Next(PyObject *set, Py_ssize_t *pos, PyObject **key);
int _PySet_NextEntry(PyObject *set, Py_ssize_t *pos, PyObject **key, long *hash);
PyObject * PySet_Pop(PyObject *set);
int _PySet_Update(PyObject *set, PyObject *iterable);
# 104 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/methodobject.h" 1
# 14 "/usr/include/python2.7/methodobject.h"
extern PyTypeObject PyCFunction_Type;



typedef PyObject *(*PyCFunction)(PyObject *, PyObject *);
typedef PyObject *(*PyCFunctionWithKeywords)(PyObject *, PyObject *,
          PyObject *);
typedef PyObject *(*PyNoArgsFunction)(PyObject *);

PyCFunction PyCFunction_GetFunction(PyObject *);
PyObject * PyCFunction_GetSelf(PyObject *);
int PyCFunction_GetFlags(PyObject *);
# 35 "/usr/include/python2.7/methodobject.h"
PyObject * PyCFunction_Call(PyObject *, PyObject *, PyObject *);

struct PyMethodDef {
    const char *ml_name;
    PyCFunction ml_meth;
    int ml_flags;

    const char *ml_doc;
};
typedef struct PyMethodDef PyMethodDef;

PyObject * Py_FindMethod(PyMethodDef[], PyObject *, const char *);


PyObject * PyCFunction_NewEx(PyMethodDef *, PyObject *,
      PyObject *);
# 73 "/usr/include/python2.7/methodobject.h"
typedef struct PyMethodChain {
    PyMethodDef *methods;
    struct PyMethodChain *link;
} PyMethodChain;

PyObject * Py_FindMethodInChain(PyMethodChain *, PyObject *,
                                            const char *);

typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyMethodDef *m_ml;
    PyObject *m_self;
    PyObject *m_module;
} PyCFunctionObject;

int PyCFunction_ClearFreeList(void);
# 105 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/moduleobject.h" 1
# 10 "/usr/include/python2.7/moduleobject.h"
extern PyTypeObject PyModule_Type;




PyObject * PyModule_New(const char *);
PyObject * PyModule_GetDict(PyObject *);
char * PyModule_GetName(PyObject *);
char * PyModule_GetFilename(PyObject *);
void _PyModule_Clear(PyObject *);
# 106 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/funcobject.h" 1
# 21 "/usr/include/python2.7/funcobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyObject *func_code;
    PyObject *func_globals;
    PyObject *func_defaults;
    PyObject *func_closure;
    PyObject *func_doc;
    PyObject *func_name;
    PyObject *func_dict;
    PyObject *func_weakreflist;
    PyObject *func_module;






} PyFunctionObject;

extern PyTypeObject PyFunction_Type;



PyObject * PyFunction_New(PyObject *, PyObject *);
PyObject * PyFunction_GetCode(PyObject *);
PyObject * PyFunction_GetGlobals(PyObject *);
PyObject * PyFunction_GetModule(PyObject *);
PyObject * PyFunction_GetDefaults(PyObject *);
int PyFunction_SetDefaults(PyObject *, PyObject *);
PyObject * PyFunction_GetClosure(PyObject *);
int PyFunction_SetClosure(PyObject *, PyObject *);
# 67 "/usr/include/python2.7/funcobject.h"
extern PyTypeObject PyClassMethod_Type;
extern PyTypeObject PyStaticMethod_Type;

PyObject * PyClassMethod_New(PyObject *);
PyObject * PyStaticMethod_New(PyObject *);
# 107 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/classobject.h" 1
# 12 "/usr/include/python2.7/classobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyObject *cl_bases;
    PyObject *cl_dict;
    PyObject *cl_name;

    PyObject *cl_getattr;
    PyObject *cl_setattr;
    PyObject *cl_delattr;
    PyObject *cl_weakreflist;
} PyClassObject;

typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyClassObject *in_class;
    PyObject *in_dict;
    PyObject *in_weakreflist;
} PyInstanceObject;

typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyObject *im_func;
    PyObject *im_self;
    PyObject *im_class;
    PyObject *im_weakreflist;
} PyMethodObject;

extern PyTypeObject PyClass_Type, PyInstance_Type, PyMethod_Type;





PyObject * PyClass_New(PyObject *, PyObject *, PyObject *);
PyObject * PyInstance_New(PyObject *, PyObject *,
                                            PyObject *);
PyObject * PyInstance_NewRaw(PyObject *, PyObject *);
PyObject * PyMethod_New(PyObject *, PyObject *, PyObject *);

PyObject * PyMethod_Function(PyObject *);
PyObject * PyMethod_Self(PyObject *);
PyObject * PyMethod_Class(PyObject *);
# 65 "/usr/include/python2.7/classobject.h"
PyObject * _PyInstance_Lookup(PyObject *pinst, PyObject *name);
# 76 "/usr/include/python2.7/classobject.h"
int PyClass_IsSubclass(PyObject *, PyObject *);

int PyMethod_ClearFreeList(void);
# 108 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/fileobject.h" 1
# 10 "/usr/include/python2.7/fileobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    FILE *f_fp;
    PyObject *f_name;
    PyObject *f_mode;
    int (*f_close)(FILE *);
    int f_softspace;
    int f_binary;

    char* f_buf;
    char* f_bufend;
    char* f_bufptr;
    char *f_setbuf;
    int f_univ_newline;
    int f_newlinetypes;
    int f_skipnextlf;
    PyObject *f_encoding;
    PyObject *f_errors;
    PyObject *weakreflist;
    int unlocked_count;

    int readable;
    int writable;
} PyFileObject;

extern PyTypeObject PyFile_Type;




PyObject * PyFile_FromString(char *, char *);
void PyFile_SetBufSize(PyObject *, int);
int PyFile_SetEncoding(PyObject *, const char *);
int PyFile_SetEncodingAndErrors(PyObject *, const char *, char *errors);
PyObject * PyFile_FromFile(FILE *, char *, char *,
                                             int (*)(FILE *));
FILE * PyFile_AsFile(PyObject *);
void PyFile_IncUseCount(PyFileObject *);
void PyFile_DecUseCount(PyFileObject *);
PyObject * PyFile_Name(PyObject *);
PyObject * PyFile_GetLine(PyObject *, int);
int PyFile_WriteObject(PyObject *, PyObject *, int);
int PyFile_SoftSpace(PyObject *, int);
int PyFile_WriteString(const char *, PyObject *);
int PyObject_AsFileDescriptor(PyObject *);




extern const char * Py_FileSystemDefaultEncoding;





char *Py_UniversalNewlineFgets(char *, int, FILE*, PyObject *);
size_t Py_UniversalNewlineFread(char *, size_t, FILE *, PyObject *);




int _PyFile_SanitizeMode(char *mode);
# 109 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/cobject.h" 1
# 43 "/usr/include/python2.7/cobject.h"
extern PyTypeObject PyCObject_Type;
# 53 "/usr/include/python2.7/cobject.h"
PyObject * PyCObject_FromVoidPtr(
 void *cobj, void (*destruct)(void*));







PyObject * PyCObject_FromVoidPtrAndDesc(
 void *cobj, void *desc, void (*destruct)(void*,void*));


void * PyCObject_AsVoidPtr(PyObject *);


void * PyCObject_GetDesc(PyObject *);


void * PyCObject_Import(char *module_name, char *cobject_name);


int PyCObject_SetVoidPtr(PyObject *self, void *cobj);


typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    void *cobject;
    void *desc;
    void (*destructor)(void *);
} PyCObject;
# 110 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/pycapsule.h" 1
# 21 "/usr/include/python2.7/pycapsule.h"
extern PyTypeObject PyCapsule_Type;

typedef void (*PyCapsule_Destructor)(PyObject *);




PyObject * PyCapsule_New(
    void *pointer,
    const char *name,
    PyCapsule_Destructor destructor);

void * PyCapsule_GetPointer(PyObject *capsule, const char *name);

PyCapsule_Destructor PyCapsule_GetDestructor(PyObject *capsule);

const char * PyCapsule_GetName(PyObject *capsule);

void * PyCapsule_GetContext(PyObject *capsule);

int PyCapsule_IsValid(PyObject *capsule, const char *name);

int PyCapsule_SetPointer(PyObject *capsule, void *pointer);

int PyCapsule_SetDestructor(PyObject *capsule, PyCapsule_Destructor destructor);

int PyCapsule_SetName(PyObject *capsule, const char *name);

int PyCapsule_SetContext(PyObject *capsule, void *context);

void * PyCapsule_Import(const char *name, int no_block);
# 111 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/traceback.h" 1







struct _frame;



typedef struct _traceback {
 Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
 struct _traceback *tb_next;
 struct _frame *tb_frame;
 int tb_lasti;
 int tb_lineno;
} PyTracebackObject;

int PyTraceBack_Here(struct _frame *);
int PyTraceBack_Print(PyObject *, PyObject *);
int _Py_DisplaySourceLine(PyObject *, const char *, int, int);


extern PyTypeObject PyTraceBack_Type;
# 112 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/sliceobject.h" 1
# 9 "/usr/include/python2.7/sliceobject.h"
extern PyObject _Py_EllipsisObject;
# 22 "/usr/include/python2.7/sliceobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyObject *start, *stop, *step;
} PySliceObject;

extern PyTypeObject PySlice_Type;
extern PyTypeObject PyEllipsis_Type;



PyObject * PySlice_New(PyObject* start, PyObject* stop,
                                  PyObject* step);
PyObject * _PySlice_FromIndices(Py_ssize_t start, Py_ssize_t stop);
int PySlice_GetIndices(PySliceObject *r, Py_ssize_t length,
                                  Py_ssize_t *start, Py_ssize_t *stop, Py_ssize_t *step);
int PySlice_GetIndicesEx(PySliceObject *r, Py_ssize_t length,
        Py_ssize_t *start, Py_ssize_t *stop,
        Py_ssize_t *step, Py_ssize_t *slicelength);
# 113 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/cellobject.h" 1
# 9 "/usr/include/python2.7/cellobject.h"
typedef struct {
 Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
 PyObject *ob_ref;
} PyCellObject;

extern PyTypeObject PyCell_Type;



PyObject * PyCell_New(PyObject *);
PyObject * PyCell_Get(PyObject *);
int PyCell_Set(PyObject *, PyObject *);
# 114 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/iterobject.h" 1







extern PyTypeObject PySeqIter_Type;



PyObject * PySeqIter_New(PyObject *);

extern PyTypeObject PyCallIter_Type;



PyObject * PyCallIter_New(PyObject *, PyObject *);
# 115 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/genobject.h" 1
# 10 "/usr/include/python2.7/genobject.h"
struct _frame;

typedef struct {
 Py_ssize_t ob_refcnt; struct _typeobject *ob_type;



 struct _frame *gi_frame;


 int gi_running;


 PyObject *gi_code;


 PyObject *gi_weakreflist;
} PyGenObject;

extern PyTypeObject PyGen_Type;




PyObject * PyGen_New(struct _frame *);
int PyGen_NeedsFinalizing(PyGenObject *);
# 116 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/descrobject.h" 1







typedef PyObject *(*getter)(PyObject *, void *);
typedef int (*setter)(PyObject *, PyObject *, void *);

typedef struct PyGetSetDef {
    char *name;
    getter get;
    setter set;
    char *doc;
    void *closure;
} PyGetSetDef;

typedef PyObject *(*wrapperfunc)(PyObject *self, PyObject *args,
                                 void *wrapped);

typedef PyObject *(*wrapperfunc_kwds)(PyObject *self, PyObject *args,
                                      void *wrapped, PyObject *kwds);

struct wrapperbase {
    char *name;
    int offset;
    void *function;
    wrapperfunc wrapper;
    char *doc;
    int flags;
    PyObject *name_strobj;
};
# 45 "/usr/include/python2.7/descrobject.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type; PyTypeObject *d_type; PyObject *d_name;
} PyDescrObject;

typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type; PyTypeObject *d_type; PyObject *d_name;
    PyMethodDef *d_method;
} PyMethodDescrObject;

typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type; PyTypeObject *d_type; PyObject *d_name;
    struct PyMemberDef *d_member;
} PyMemberDescrObject;

typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type; PyTypeObject *d_type; PyObject *d_name;
    PyGetSetDef *d_getset;
} PyGetSetDescrObject;

typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type; PyTypeObject *d_type; PyObject *d_name;
    struct wrapperbase *d_base;
    void *d_wrapped;
} PyWrapperDescrObject;

extern PyTypeObject PyWrapperDescr_Type;
extern PyTypeObject PyDictProxy_Type;
extern PyTypeObject PyGetSetDescr_Type;
extern PyTypeObject PyMemberDescr_Type;

PyObject * PyDescr_NewMethod(PyTypeObject *, PyMethodDef *);
PyObject * PyDescr_NewClassMethod(PyTypeObject *, PyMethodDef *);
PyObject * PyDescr_NewMember(PyTypeObject *,
                                               struct PyMemberDef *);
PyObject * PyDescr_NewGetSet(PyTypeObject *,
                                               struct PyGetSetDef *);
PyObject * PyDescr_NewWrapper(PyTypeObject *,
                                                struct wrapperbase *, void *);


PyObject * PyDictProxy_New(PyObject *);
PyObject * PyWrapper_New(PyObject *, PyObject *);


extern PyTypeObject PyProperty_Type;
# 117 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/warnings.h" 1






void _PyWarnings_Init(void);

int PyErr_WarnEx(PyObject *, const char *, Py_ssize_t);
int PyErr_WarnExplicit(PyObject *, const char *, const char *, int,
                                    const char *, PyObject *);
# 118 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/weakrefobject.h" 1
# 10 "/usr/include/python2.7/weakrefobject.h"
typedef struct _PyWeakReference PyWeakReference;




struct _PyWeakReference {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;





    PyObject *wr_object;


    PyObject *wr_callback;




    long hash;






    PyWeakReference *wr_prev;
    PyWeakReference *wr_next;
};

extern PyTypeObject _PyWeakref_RefType;
extern PyTypeObject _PyWeakref_ProxyType;
extern PyTypeObject _PyWeakref_CallableProxyType;
# 59 "/usr/include/python2.7/weakrefobject.h"
PyObject * PyWeakref_NewRef(PyObject *ob,
                                              PyObject *callback);
PyObject * PyWeakref_NewProxy(PyObject *ob,
                                                PyObject *callback);
PyObject * PyWeakref_GetObject(PyObject *ref);

Py_ssize_t _PyWeakref_GetWeakrefCount(PyWeakReference *head);

void _PyWeakref_ClearRef(PyWeakReference *self);
# 119 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/codecs.h" 1
# 26 "/usr/include/python2.7/codecs.h"
int PyCodec_Register(
       PyObject *search_function
       );
# 48 "/usr/include/python2.7/codecs.h"
PyObject * _PyCodec_Lookup(
       const char *encoding
       );
# 62 "/usr/include/python2.7/codecs.h"
PyObject * PyCodec_Encode(
       PyObject *object,
       const char *encoding,
       const char *errors
       );
# 78 "/usr/include/python2.7/codecs.h"
PyObject * PyCodec_Decode(
       PyObject *object,
       const char *encoding,
       const char *errors
       );
# 94 "/usr/include/python2.7/codecs.h"
PyObject * PyCodec_Encoder(
       const char *encoding
       );



PyObject * PyCodec_Decoder(
       const char *encoding
       );



PyObject * PyCodec_IncrementalEncoder(
       const char *encoding,
       const char *errors
       );



PyObject * PyCodec_IncrementalDecoder(
       const char *encoding,
       const char *errors
       );



PyObject * PyCodec_StreamReader(
       const char *encoding,
       PyObject *stream,
       const char *errors
       );



PyObject * PyCodec_StreamWriter(
       const char *encoding,
       PyObject *stream,
       const char *errors
       );
# 142 "/usr/include/python2.7/codecs.h"
int PyCodec_RegisterError(const char *name, PyObject *error);




PyObject * PyCodec_LookupError(const char *name);


PyObject * PyCodec_StrictErrors(PyObject *exc);


PyObject * PyCodec_IgnoreErrors(PyObject *exc);


PyObject * PyCodec_ReplaceErrors(PyObject *exc);


PyObject * PyCodec_XMLCharRefReplaceErrors(PyObject *exc);


PyObject * PyCodec_BackslashReplaceErrors(PyObject *exc);
# 121 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/pyerrors.h" 1
# 9 "/usr/include/python2.7/pyerrors.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyObject *dict;
    PyObject *args;
    PyObject *message;
} PyBaseExceptionObject;

typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyObject *dict;
    PyObject *args;
    PyObject *message;
    PyObject *msg;
    PyObject *filename;
    PyObject *lineno;
    PyObject *offset;
    PyObject *text;
    PyObject *print_file_and_line;
} PySyntaxErrorObject;


typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyObject *dict;
    PyObject *args;
    PyObject *message;
    PyObject *encoding;
    PyObject *object;
    Py_ssize_t start;
    Py_ssize_t end;
    PyObject *reason;
} PyUnicodeErrorObject;


typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyObject *dict;
    PyObject *args;
    PyObject *message;
    PyObject *code;
} PySystemExitObject;

typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    PyObject *dict;
    PyObject *args;
    PyObject *message;
    PyObject *myerrno;
    PyObject *strerror;
    PyObject *filename;
} PyEnvironmentErrorObject;
# 76 "/usr/include/python2.7/pyerrors.h"
void PyErr_SetNone(PyObject *);
void PyErr_SetObject(PyObject *, PyObject *);
void PyErr_SetString(PyObject *, const char *);
PyObject * PyErr_Occurred(void);
void PyErr_Clear(void);
void PyErr_Fetch(PyObject **, PyObject **, PyObject **);
void PyErr_Restore(PyObject *, PyObject *, PyObject *);
# 91 "/usr/include/python2.7/pyerrors.h"
int PyErr_GivenExceptionMatches(PyObject *, PyObject *);
int PyErr_ExceptionMatches(PyObject *);
void PyErr_NormalizeException(PyObject**, PyObject**, PyObject**);
# 118 "/usr/include/python2.7/pyerrors.h"
extern PyObject * PyExc_BaseException;
extern PyObject * PyExc_Exception;
extern PyObject * PyExc_StopIteration;
extern PyObject * PyExc_GeneratorExit;
extern PyObject * PyExc_StandardError;
extern PyObject * PyExc_ArithmeticError;
extern PyObject * PyExc_LookupError;

extern PyObject * PyExc_AssertionError;
extern PyObject * PyExc_AttributeError;
extern PyObject * PyExc_EOFError;
extern PyObject * PyExc_FloatingPointError;
extern PyObject * PyExc_EnvironmentError;
extern PyObject * PyExc_IOError;
extern PyObject * PyExc_OSError;
extern PyObject * PyExc_ImportError;
extern PyObject * PyExc_IndexError;
extern PyObject * PyExc_KeyError;
extern PyObject * PyExc_KeyboardInterrupt;
extern PyObject * PyExc_MemoryError;
extern PyObject * PyExc_NameError;
extern PyObject * PyExc_OverflowError;
extern PyObject * PyExc_RuntimeError;
extern PyObject * PyExc_NotImplementedError;
extern PyObject * PyExc_SyntaxError;
extern PyObject * PyExc_IndentationError;
extern PyObject * PyExc_TabError;
extern PyObject * PyExc_ReferenceError;
extern PyObject * PyExc_SystemError;
extern PyObject * PyExc_SystemExit;
extern PyObject * PyExc_TypeError;
extern PyObject * PyExc_UnboundLocalError;
extern PyObject * PyExc_UnicodeError;
extern PyObject * PyExc_UnicodeEncodeError;
extern PyObject * PyExc_UnicodeDecodeError;
extern PyObject * PyExc_UnicodeTranslateError;
extern PyObject * PyExc_ValueError;
extern PyObject * PyExc_ZeroDivisionError;







extern PyObject * PyExc_BufferError;

extern PyObject * PyExc_MemoryErrorInst;
extern PyObject * PyExc_RecursionErrorInst;


extern PyObject * PyExc_Warning;
extern PyObject * PyExc_UserWarning;
extern PyObject * PyExc_DeprecationWarning;
extern PyObject * PyExc_PendingDeprecationWarning;
extern PyObject * PyExc_SyntaxWarning;
extern PyObject * PyExc_RuntimeWarning;
extern PyObject * PyExc_FutureWarning;
extern PyObject * PyExc_ImportWarning;
extern PyObject * PyExc_UnicodeWarning;
extern PyObject * PyExc_BytesWarning;




int PyErr_BadArgument(void);
PyObject * PyErr_NoMemory(void);
PyObject * PyErr_SetFromErrno(PyObject *);
PyObject * PyErr_SetFromErrnoWithFilenameObject(
    PyObject *, PyObject *);
PyObject * PyErr_SetFromErrnoWithFilename(
    PyObject *, const char *);





PyObject * PyErr_Format(PyObject *, const char *, ...)
                        __attribute__((format(printf, 2, 3)));
# 216 "/usr/include/python2.7/pyerrors.h"
void PyErr_BadInternalCall(void);
void _PyErr_BadInternalCall(char *filename, int lineno);





PyObject * PyErr_NewException(
    char *name, PyObject *base, PyObject *dict);
PyObject * PyErr_NewExceptionWithDoc(
    char *name, char *doc, PyObject *base, PyObject *dict);
void PyErr_WriteUnraisable(PyObject *);


int PyErr_CheckSignals(void);
void PyErr_SetInterrupt(void);


int PySignal_SetWakeupFd(int fd);


void PyErr_SyntaxLocation(const char *, int);
PyObject * PyErr_ProgramText(const char *, int);






PyObject * PyUnicodeDecodeError_Create(
    const char *, const char *, Py_ssize_t, Py_ssize_t, Py_ssize_t, const char *);


PyObject * PyUnicodeEncodeError_Create(
    const char *, const Py_UNICODE *, Py_ssize_t, Py_ssize_t, Py_ssize_t, const char *);


PyObject * PyUnicodeTranslateError_Create(
    const Py_UNICODE *, Py_ssize_t, Py_ssize_t, Py_ssize_t, const char *);


PyObject * PyUnicodeEncodeError_GetEncoding(PyObject *);
PyObject * PyUnicodeDecodeError_GetEncoding(PyObject *);


PyObject * PyUnicodeEncodeError_GetObject(PyObject *);
PyObject * PyUnicodeDecodeError_GetObject(PyObject *);
PyObject * PyUnicodeTranslateError_GetObject(PyObject *);



int PyUnicodeEncodeError_GetStart(PyObject *, Py_ssize_t *);
int PyUnicodeDecodeError_GetStart(PyObject *, Py_ssize_t *);
int PyUnicodeTranslateError_GetStart(PyObject *, Py_ssize_t *);



int PyUnicodeEncodeError_SetStart(PyObject *, Py_ssize_t);
int PyUnicodeDecodeError_SetStart(PyObject *, Py_ssize_t);
int PyUnicodeTranslateError_SetStart(PyObject *, Py_ssize_t);



int PyUnicodeEncodeError_GetEnd(PyObject *, Py_ssize_t *);
int PyUnicodeDecodeError_GetEnd(PyObject *, Py_ssize_t *);
int PyUnicodeTranslateError_GetEnd(PyObject *, Py_ssize_t *);



int PyUnicodeEncodeError_SetEnd(PyObject *, Py_ssize_t);
int PyUnicodeDecodeError_SetEnd(PyObject *, Py_ssize_t);
int PyUnicodeTranslateError_SetEnd(PyObject *, Py_ssize_t);


PyObject * PyUnicodeEncodeError_GetReason(PyObject *);
PyObject * PyUnicodeDecodeError_GetReason(PyObject *);
PyObject * PyUnicodeTranslateError_GetReason(PyObject *);



int PyUnicodeEncodeError_SetReason(
    PyObject *, const char *);
int PyUnicodeDecodeError_SetReason(
    PyObject *, const char *);
int PyUnicodeTranslateError_SetReason(
    PyObject *, const char *);
# 320 "/usr/include/python2.7/pyerrors.h"
int PyOS_snprintf(char *str, size_t size, const char *format, ...)
                        __attribute__((format(printf, 3, 4)));
int PyOS_vsnprintf(char *str, size_t size, const char *format, va_list va)
                        __attribute__((format(printf, 3, 0)));
# 122 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/pystate.h" 1
# 13 "/usr/include/python2.7/pystate.h"
struct _ts;
struct _is;

typedef struct _is {

    struct _is *next;
    struct _ts *tstate_head;

    PyObject *modules;
    PyObject *sysdict;
    PyObject *builtins;
    PyObject *modules_reloading;

    PyObject *codec_search_path;
    PyObject *codec_search_cache;
    PyObject *codec_error_registry;


    int dlopenflags;





} PyInterpreterState;




struct _frame;


typedef int (*Py_tracefunc)(PyObject *, struct _frame *, int, PyObject *);
# 56 "/usr/include/python2.7/pystate.h"
typedef struct _ts {


    struct _ts *next;
    PyInterpreterState *interp;

    struct _frame *frame;
    int recursion_depth;



    int tracing;
    int use_tracing;

    Py_tracefunc c_profilefunc;
    Py_tracefunc c_tracefunc;
    PyObject *c_profileobj;
    PyObject *c_traceobj;

    PyObject *curexc_type;
    PyObject *curexc_value;
    PyObject *curexc_traceback;

    PyObject *exc_type;
    PyObject *exc_value;
    PyObject *exc_traceback;

    PyObject *dict;







    int tick_counter;

    int gilstate_counter;

    PyObject *async_exc;
    long thread_id;



} PyThreadState;


PyInterpreterState * PyInterpreterState_New(void);
void PyInterpreterState_Clear(PyInterpreterState *);
void PyInterpreterState_Delete(PyInterpreterState *);

PyThreadState * PyThreadState_New(PyInterpreterState *);
PyThreadState * _PyThreadState_Prealloc(PyInterpreterState *);
void _PyThreadState_Init(PyThreadState *);
void PyThreadState_Clear(PyThreadState *);
void PyThreadState_Delete(PyThreadState *);

void PyThreadState_DeleteCurrent(void);


PyThreadState * PyThreadState_Get(void);
PyThreadState * PyThreadState_Swap(PyThreadState *);
PyObject * PyThreadState_GetDict(void);
int PyThreadState_SetAsyncExc(long, PyObject *);




extern PyThreadState * _PyThreadState_Current;







typedef
    enum {PyGILState_LOCKED, PyGILState_UNLOCKED}
        PyGILState_STATE;
# 157 "/usr/include/python2.7/pystate.h"
PyGILState_STATE PyGILState_Ensure(void);
# 167 "/usr/include/python2.7/pystate.h"
void PyGILState_Release(PyGILState_STATE);







PyThreadState * PyGILState_GetThisThreadState(void);




PyObject * _PyThread_CurrentFrames(void);



PyInterpreterState * PyInterpreterState_Head(void);
PyInterpreterState * PyInterpreterState_Next(PyInterpreterState *);
PyThreadState * PyInterpreterState_ThreadHead(PyInterpreterState *);
PyThreadState * PyThreadState_Next(PyThreadState *);

typedef struct _frame *(*PyThreadFrameGetter)(PyThreadState *self_);


extern PyThreadFrameGetter _PyThreadState_GetFrame;
# 124 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/pyarena.h" 1
# 11 "/usr/include/python2.7/pyarena.h"
  typedef struct _arena PyArena;
# 35 "/usr/include/python2.7/pyarena.h"
  PyArena * PyArena_New(void);
  void PyArena_Free(PyArena *);
# 50 "/usr/include/python2.7/pyarena.h"
  void * PyArena_Malloc(PyArena *, size_t size);





  int PyArena_AddPyObject(PyArena *, PyObject *);
# 126 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/modsupport.h" 1
# 23 "/usr/include/python2.7/modsupport.h"
PyObject * _Py_VaBuildValue_SizeT(const char *, va_list);


int PyArg_Parse(PyObject *, const char *, ...);
int PyArg_ParseTuple(PyObject *, const char *, ...) ;
int PyArg_ParseTupleAndKeywords(PyObject *, PyObject *,
                                                  const char *, char **, ...);
int PyArg_UnpackTuple(PyObject *, const char *, Py_ssize_t, Py_ssize_t, ...);
PyObject * Py_BuildValue(const char *, ...);
PyObject * _Py_BuildValue_SizeT(const char *, ...);
int _PyArg_NoKeywords(const char *funcname, PyObject *kw);

int PyArg_VaParse(PyObject *, const char *, va_list);
int PyArg_VaParseTupleAndKeywords(PyObject *, PyObject *,
                                                  const char *, char **, va_list);
PyObject * Py_VaBuildValue(const char *, va_list);

int PyModule_AddObject(PyObject *, const char *, PyObject *);
int PyModule_AddIntConstant(PyObject *, const char *, long);
int PyModule_AddStringConstant(PyObject *, const char *, const char *);
# 117 "/usr/include/python2.7/modsupport.h"
PyObject * Py_InitModule4(const char *name, PyMethodDef *methods,
                                      const char *doc, PyObject *self,
                                      int apiver);
# 129 "/usr/include/python2.7/modsupport.h"
extern char * _Py_PackageContext;
# 127 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/pythonrun.h" 1
# 18 "/usr/include/python2.7/pythonrun.h"
typedef struct {
    int cf_flags;
} PyCompilerFlags;

void Py_SetProgramName(char *);
char * Py_GetProgramName(void);

void Py_SetPythonHome(char *);
char * Py_GetPythonHome(void);

void Py_Initialize(void);
void Py_InitializeEx(int);
void Py_Finalize(void);
int Py_IsInitialized(void);
PyThreadState * Py_NewInterpreter(void);
void Py_EndInterpreter(PyThreadState *);

int PyRun_AnyFileFlags(FILE *, const char *, PyCompilerFlags *);
int PyRun_AnyFileExFlags(FILE *, const char *, int, PyCompilerFlags *);
int PyRun_SimpleStringFlags(const char *, PyCompilerFlags *);
int PyRun_SimpleFileExFlags(FILE *, const char *, int, PyCompilerFlags *);
int PyRun_InteractiveOneFlags(FILE *, const char *, PyCompilerFlags *);
int PyRun_InteractiveLoopFlags(FILE *, const char *, PyCompilerFlags *);

struct _mod * PyParser_ASTFromString(const char *, const char *,
                                                 int, PyCompilerFlags *flags,
                                                 PyArena *);
struct _mod * PyParser_ASTFromFile(FILE *, const char *, int,
                                               char *, char *,
                                               PyCompilerFlags *, int *,
                                               PyArena *);




struct _node * PyParser_SimpleParseStringFlags(const char *, int,
                                                          int);
struct _node * PyParser_SimpleParseFileFlags(FILE *, const char *,
                                                        int, int);

PyObject * PyRun_StringFlags(const char *, int, PyObject *,
                                         PyObject *, PyCompilerFlags *);

PyObject * PyRun_FileExFlags(FILE *, const char *, int,
                                         PyObject *, PyObject *, int,
                                         PyCompilerFlags *);


PyObject * Py_CompileStringFlags(const char *, const char *, int,
                                             PyCompilerFlags *);
struct symtable * Py_SymtableString(const char *, const char *, int);

void PyErr_Print(void);
void PyErr_PrintEx(int);
void PyErr_Display(PyObject *, PyObject *, PyObject *);

int Py_AtExit(void (*func)(void));

void Py_Exit(int);

int Py_FdIsInteractive(FILE *, const char *);


int Py_Main(int argc, char **argv);
# 103 "/usr/include/python2.7/pythonrun.h"
char * Py_GetProgramFullPath(void);
char * Py_GetPrefix(void);
char * Py_GetExecPrefix(void);
char * Py_GetPath(void);


const char * Py_GetVersion(void);
const char * Py_GetPlatform(void);
const char * Py_GetCopyright(void);
const char * Py_GetCompiler(void);
const char * Py_GetBuildInfo(void);
const char * _Py_svnversion(void);
const char * Py_SubversionRevision(void);
const char * Py_SubversionShortBranch(void);


PyObject * _PyBuiltin_Init(void);
PyObject * _PySys_Init(void);
void _PyImport_Init(void);
void _PyExc_Init(void);
void _PyImportHooks_Init(void);
int _PyFrame_Init(void);
int _PyInt_Init(void);
int _PyLong_Init(void);
void _PyFloat_Init(void);
int PyByteArray_Init(void);


void _PyExc_Fini(void);
void _PyImport_Fini(void);
void PyMethod_Fini(void);
void PyFrame_Fini(void);
void PyCFunction_Fini(void);
void PyDict_Fini(void);
void PyTuple_Fini(void);
void PyList_Fini(void);
void PySet_Fini(void);
void PyString_Fini(void);
void PyInt_Fini(void);
void PyFloat_Fini(void);
void PyOS_FiniInterrupts(void);
void PyByteArray_Fini(void);


char * PyOS_Readline(FILE *, FILE *, char *);
extern int (*PyOS_InputHook)(void);
extern char *(*PyOS_ReadlineFunctionPointer)(FILE *, FILE *, char *);
extern PyThreadState* _PyOS_ReadlineTState;
# 168 "/usr/include/python2.7/pythonrun.h"
typedef void (*PyOS_sighandler_t)(int);
PyOS_sighandler_t PyOS_getsig(int);
PyOS_sighandler_t PyOS_setsig(int, PyOS_sighandler_t);
# 128 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/ceval.h" 1
# 10 "/usr/include/python2.7/ceval.h"
PyObject * PyEval_CallObjectWithKeywords(
    PyObject *, PyObject *, PyObject *);





PyObject * PyEval_CallFunction(PyObject *obj,
                                           const char *format, ...);
PyObject * PyEval_CallMethod(PyObject *obj,
                                         const char *methodname,
                                         const char *format, ...);

void PyEval_SetProfile(Py_tracefunc, PyObject *);
void PyEval_SetTrace(Py_tracefunc, PyObject *);

struct _frame;

PyObject * PyEval_GetBuiltins(void);
PyObject * PyEval_GetGlobals(void);
PyObject * PyEval_GetLocals(void);
struct _frame * PyEval_GetFrame(void);
int PyEval_GetRestricted(void);




int PyEval_MergeCompilerFlags(PyCompilerFlags *cf);

int Py_FlushLine(void);

int Py_AddPendingCall(int (*func)(void *), void *arg);
int Py_MakePendingCalls(void);


void Py_SetRecursionLimit(int);
int Py_GetRecursionLimit(void);






int _Py_CheckRecursiveCall(char *where);
extern int _Py_CheckRecursionLimit;






const char * PyEval_GetFuncName(PyObject *);
const char * PyEval_GetFuncDesc(PyObject *);

PyObject * PyEval_GetCallStats(PyObject *);
PyObject * PyEval_EvalFrame(struct _frame *);
PyObject * PyEval_EvalFrameEx(struct _frame *f, int exc);


extern volatile int _Py_Ticker;
extern int _Py_CheckInterval;
# 117 "/usr/include/python2.7/ceval.h"
PyThreadState * PyEval_SaveThread(void);
void PyEval_RestoreThread(PyThreadState *);



int PyEval_ThreadsInitialized(void);
void PyEval_InitThreads(void);
void PyEval_AcquireLock(void);
void PyEval_ReleaseLock(void);
void PyEval_AcquireThread(PyThreadState *tstate);
void PyEval_ReleaseThread(PyThreadState *tstate);
void PyEval_ReInitThreads(void);
# 147 "/usr/include/python2.7/ceval.h"
int _PyEval_SliceIndex(PyObject *, Py_ssize_t *);
# 129 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/sysmodule.h" 1
# 10 "/usr/include/python2.7/sysmodule.h"
PyObject * PySys_GetObject(char *);
int PySys_SetObject(char *, PyObject *);
FILE * PySys_GetFile(char *, FILE *);
void PySys_SetArgv(int, char **);
void PySys_SetArgvEx(int, char **, int);
void PySys_SetPath(char *);

void PySys_WriteStdout(const char *format, ...)
   __attribute__((format(printf, 1, 2)));
void PySys_WriteStderr(const char *format, ...)
   __attribute__((format(printf, 1, 2)));

extern PyObject * _PySys_TraceFunc, *_PySys_ProfileFunc;
extern int _PySys_CheckInterval;

void PySys_ResetWarnOptions(void);
void PySys_AddWarnOption(char *);
int PySys_HasWarnOptions(void);
# 130 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/intrcheck.h" 1







int PyOS_InterruptOccurred(void);
void PyOS_InitInterrupts(void);
void PyOS_AfterFork(void);
# 131 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/import.h" 1
# 10 "/usr/include/python2.7/import.h"
long PyImport_GetMagicNumber(void);
PyObject * PyImport_ExecCodeModule(char *name, PyObject *co);
PyObject * PyImport_ExecCodeModuleEx(
 char *name, PyObject *co, char *pathname);
PyObject * PyImport_GetModuleDict(void);
PyObject * PyImport_AddModule(const char *name);
PyObject * PyImport_ImportModule(const char *name);
PyObject * PyImport_ImportModuleNoBlock(const char *);
PyObject * PyImport_ImportModuleLevel(char *name,
 PyObject *globals, PyObject *locals, PyObject *fromlist, int level);




PyObject * PyImport_GetImporter(PyObject *path);
PyObject * PyImport_Import(PyObject *name);
PyObject * PyImport_ReloadModule(PyObject *m);
void PyImport_Cleanup(void);
int PyImport_ImportFrozenModule(char *);


void _PyImport_AcquireLock(void);
int _PyImport_ReleaseLock(void);





struct filedescr * _PyImport_FindModule(
 const char *, PyObject *, char *, size_t, FILE **, PyObject **);
int _PyImport_IsScript(struct filedescr *);
void _PyImport_ReInitLock(void);

PyObject *_PyImport_FindExtension(char *, char *);
PyObject *_PyImport_FixupExtension(char *, char *);

struct _inittab {
    char *name;
    void (*initfunc)(void);
};

extern PyTypeObject PyNullImporter_Type;
extern struct _inittab * PyImport_Inittab;

int PyImport_AppendInittab(const char *name, void (*initfunc)(void));
int PyImport_ExtendInittab(struct _inittab *newtab);

struct _frozen {
    char *name;
    unsigned char *code;
    int size;
};




extern struct _frozen * PyImport_FrozenModules;
# 132 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/abstract.h" 1
# 231 "/usr/include/python2.7/abstract.h"
     int PyObject_Cmp(PyObject *o1, PyObject *o2, int *result);
# 304 "/usr/include/python2.7/abstract.h"
     PyObject * PyObject_Call(PyObject *callable_object,
                                         PyObject *args, PyObject *kw);
# 314 "/usr/include/python2.7/abstract.h"
     PyObject * PyObject_CallObject(PyObject *callable_object,
                                               PyObject *args);
# 326 "/usr/include/python2.7/abstract.h"
     PyObject * PyObject_CallFunction(PyObject *callable_object,
                                                 char *format, ...);
# 340 "/usr/include/python2.7/abstract.h"
     PyObject * PyObject_CallMethod(PyObject *o, char *m,
                                               char *format, ...);
# 352 "/usr/include/python2.7/abstract.h"
     PyObject * _PyObject_CallFunction_SizeT(PyObject *callable,
                                                         char *format, ...);
     PyObject * _PyObject_CallMethod_SizeT(PyObject *o,
                                                       char *name,
                                                       char *format, ...);

     PyObject * PyObject_CallFunctionObjArgs(PyObject *callable,
                                                        ...);
# 370 "/usr/include/python2.7/abstract.h"
     PyObject * PyObject_CallMethodObjArgs(PyObject *o,
                                                      PyObject *m, ...);
# 413 "/usr/include/python2.7/abstract.h"
     PyObject * PyObject_Type(PyObject *o);







     Py_ssize_t PyObject_Size(PyObject *o);
# 433 "/usr/include/python2.7/abstract.h"
     Py_ssize_t PyObject_Length(PyObject *o);


     Py_ssize_t _PyObject_LengthHint(PyObject *o, Py_ssize_t);







     PyObject * PyObject_GetItem(PyObject *o, PyObject *key);
# 453 "/usr/include/python2.7/abstract.h"
     int PyObject_SetItem(PyObject *o, PyObject *key, PyObject *v);







     int PyObject_DelItemString(PyObject *o, char *key);







     int PyObject_DelItem(PyObject *o, PyObject *key);






     int PyObject_AsCharBuffer(PyObject *obj,
                                          const char **buffer,
                                          Py_ssize_t *buffer_len);
# 492 "/usr/include/python2.7/abstract.h"
     int PyObject_CheckReadBuffer(PyObject *obj);
# 501 "/usr/include/python2.7/abstract.h"
     int PyObject_AsReadBuffer(PyObject *obj,
                                          const void **buffer,
                                          Py_ssize_t *buffer_len);
# 517 "/usr/include/python2.7/abstract.h"
     int PyObject_AsWriteBuffer(PyObject *obj,
                                           void **buffer,
                                           Py_ssize_t *buffer_len);
# 542 "/usr/include/python2.7/abstract.h"
     int PyObject_GetBuffer(PyObject *obj, Py_buffer *view,
                                        int flags);
# 552 "/usr/include/python2.7/abstract.h"
     void * PyBuffer_GetPointer(Py_buffer *view, Py_ssize_t *indices);





     int PyBuffer_SizeFromFormat(const char *);






     int PyBuffer_ToContiguous(void *buf, Py_buffer *view,
                                           Py_ssize_t len, char fort);

     int PyBuffer_FromContiguous(Py_buffer *view, void *buf,
                                             Py_ssize_t len, char fort);
# 588 "/usr/include/python2.7/abstract.h"
     int PyObject_CopyData(PyObject *dest, PyObject *src);




     int PyBuffer_IsContiguous(Py_buffer *view, char fort);


     void PyBuffer_FillContiguousStrides(int ndims,
                                                    Py_ssize_t *shape,
                                                    Py_ssize_t *strides,
                                                    int itemsize,
                                                    char fort);







     int PyBuffer_FillInfo(Py_buffer *view, PyObject *o, void *buf,
                                       Py_ssize_t len, int readonly,
                                       int flags);







     void PyBuffer_Release(Py_buffer *view);




     PyObject * PyObject_Format(PyObject* obj,
                                            PyObject *format_spec);







     PyObject * PyObject_GetIter(PyObject *);
# 642 "/usr/include/python2.7/abstract.h"
     PyObject * PyIter_Next(PyObject *);







     int PyNumber_Check(PyObject *o);
# 660 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Add(PyObject *o1, PyObject *o2);
# 669 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Subtract(PyObject *o1, PyObject *o2);
# 678 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Multiply(PyObject *o1, PyObject *o2);
# 688 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Divide(PyObject *o1, PyObject *o2);
# 697 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_FloorDivide(PyObject *o1, PyObject *o2);
# 707 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_TrueDivide(PyObject *o1, PyObject *o2);
# 717 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Remainder(PyObject *o1, PyObject *o2);
# 727 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Divmod(PyObject *o1, PyObject *o2);
# 737 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Power(PyObject *o1, PyObject *o2,
                                          PyObject *o3);
# 747 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Negative(PyObject *o);







     PyObject * PyNumber_Positive(PyObject *o);







     PyObject * PyNumber_Absolute(PyObject *o);







     PyObject * PyNumber_Invert(PyObject *o);
# 781 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Lshift(PyObject *o1, PyObject *o2);
# 791 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Rshift(PyObject *o1, PyObject *o2);
# 800 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_And(PyObject *o1, PyObject *o2);
# 810 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Xor(PyObject *o1, PyObject *o2);
# 820 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Or(PyObject *o1, PyObject *o2);
# 853 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Index(PyObject *o);






     Py_ssize_t PyNumber_AsSsize_t(PyObject *o, PyObject *exc);
# 871 "/usr/include/python2.7/abstract.h"
     PyObject * _PyNumber_ConvertIntegralToInt(
         PyObject *integral,
         const char* error_format);
# 883 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Int(PyObject *o);
# 892 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Long(PyObject *o);
# 901 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_Float(PyObject *o);
# 911 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceAdd(PyObject *o1, PyObject *o2);
# 920 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceSubtract(PyObject *o1, PyObject *o2);
# 929 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceMultiply(PyObject *o1, PyObject *o2);
# 938 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceDivide(PyObject *o1, PyObject *o2);
# 947 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceFloorDivide(PyObject *o1,
                                                       PyObject *o2);
# 958 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceTrueDivide(PyObject *o1,
                                                      PyObject *o2);
# 969 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceRemainder(PyObject *o1, PyObject *o2);
# 978 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlacePower(PyObject *o1, PyObject *o2,
                                                 PyObject *o3);
# 988 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceLshift(PyObject *o1, PyObject *o2);
# 997 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceRshift(PyObject *o1, PyObject *o2);
# 1006 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceAnd(PyObject *o1, PyObject *o2);
# 1015 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceXor(PyObject *o1, PyObject *o2);
# 1024 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_InPlaceOr(PyObject *o1, PyObject *o2);
# 1034 "/usr/include/python2.7/abstract.h"
     PyObject * PyNumber_ToBase(PyObject *n, int base);
# 1045 "/usr/include/python2.7/abstract.h"
     int PySequence_Check(PyObject *o);
# 1055 "/usr/include/python2.7/abstract.h"
     Py_ssize_t PySequence_Size(PyObject *o);
# 1064 "/usr/include/python2.7/abstract.h"
     Py_ssize_t PySequence_Length(PyObject *o);



     PyObject * PySequence_Concat(PyObject *o1, PyObject *o2);
# 1077 "/usr/include/python2.7/abstract.h"
     PyObject * PySequence_Repeat(PyObject *o, Py_ssize_t count);
# 1086 "/usr/include/python2.7/abstract.h"
     PyObject * PySequence_GetItem(PyObject *o, Py_ssize_t i);






     PyObject * PySequence_GetSlice(PyObject *o, Py_ssize_t i1, Py_ssize_t i2);
# 1102 "/usr/include/python2.7/abstract.h"
     int PySequence_SetItem(PyObject *o, Py_ssize_t i, PyObject *v);
# 1111 "/usr/include/python2.7/abstract.h"
     int PySequence_DelItem(PyObject *o, Py_ssize_t i);







     int PySequence_SetSlice(PyObject *o, Py_ssize_t i1, Py_ssize_t i2,
                                        PyObject *v);







     int PySequence_DelSlice(PyObject *o, Py_ssize_t i1, Py_ssize_t i2);







     PyObject * PySequence_Tuple(PyObject *o);







     PyObject * PySequence_List(PyObject *o);





     PyObject * PySequence_Fast(PyObject *o, const char* m);
# 1186 "/usr/include/python2.7/abstract.h"
     Py_ssize_t PySequence_Count(PyObject *o, PyObject *value);
# 1195 "/usr/include/python2.7/abstract.h"
     int PySequence_Contains(PyObject *seq, PyObject *ob);
# 1204 "/usr/include/python2.7/abstract.h"
     Py_ssize_t _PySequence_IterSearch(PyObject *seq,
                                        PyObject *obj, int operation);
# 1219 "/usr/include/python2.7/abstract.h"
     int PySequence_In(PyObject *o, PyObject *value);
# 1230 "/usr/include/python2.7/abstract.h"
     Py_ssize_t PySequence_Index(PyObject *o, PyObject *value);
# 1240 "/usr/include/python2.7/abstract.h"
     PyObject * PySequence_InPlaceConcat(PyObject *o1, PyObject *o2);
# 1249 "/usr/include/python2.7/abstract.h"
     PyObject * PySequence_InPlaceRepeat(PyObject *o, Py_ssize_t count);
# 1260 "/usr/include/python2.7/abstract.h"
     int PyMapping_Check(PyObject *o);
# 1269 "/usr/include/python2.7/abstract.h"
     Py_ssize_t PyMapping_Size(PyObject *o);
# 1279 "/usr/include/python2.7/abstract.h"
     Py_ssize_t PyMapping_Length(PyObject *o);
# 1303 "/usr/include/python2.7/abstract.h"
     int PyMapping_HasKeyString(PyObject *o, char *key);
# 1313 "/usr/include/python2.7/abstract.h"
     int PyMapping_HasKey(PyObject *o, PyObject *key);
# 1356 "/usr/include/python2.7/abstract.h"
     PyObject * PyMapping_GetItemString(PyObject *o, char *key);







     int PyMapping_SetItemString(PyObject *o, char *key,
                                            PyObject *value);
# 1374 "/usr/include/python2.7/abstract.h"
int PyObject_IsInstance(PyObject *object, PyObject *typeorclass);


int PyObject_IsSubclass(PyObject *object, PyObject *typeorclass);



int _PyObject_RealIsInstance(PyObject *inst, PyObject *cls);

int _PyObject_RealIsSubclass(PyObject *derived, PyObject *cls);



void _Py_add_one_to_index_F(int nd, Py_ssize_t *index,
                                        const Py_ssize_t *shape);
void _Py_add_one_to_index_C(int nd, Py_ssize_t *index,
                                        const Py_ssize_t *shape);
# 134 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/compile.h" 1





# 1 "/usr/include/python2.7/code.h" 1
# 10 "/usr/include/python2.7/code.h"
typedef struct {
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
    int co_argcount;
    int co_nlocals;
    int co_stacksize;
    int co_flags;
    PyObject *co_code;
    PyObject *co_consts;
    PyObject *co_names;
    PyObject *co_varnames;
    PyObject *co_freevars;
    PyObject *co_cellvars;

    PyObject *co_filename;
    PyObject *co_name;
    int co_firstlineno;
    PyObject *co_lnotab;

    void *co_zombieframe;
    PyObject *co_weakreflist;
} PyCodeObject;
# 65 "/usr/include/python2.7/code.h"
extern PyTypeObject PyCode_Type;





PyCodeObject * PyCode_New(
 int, int, int, int, PyObject *, PyObject *, PyObject *, PyObject *,
 PyObject *, PyObject *, PyObject *, PyObject *, int, PyObject *);



PyCodeObject *
PyCode_NewEmpty(const char *filename, const char *funcname, int firstlineno);




int PyCode_Addr2Line(PyCodeObject *, int);






typedef struct _addr_pair {
        int ap_lower;
        int ap_upper;
} PyAddrPair;




int _PyCode_CheckLineNumber(PyCodeObject* co,
                                        int lasti, PyAddrPair *bounds);

PyObject* PyCode_Optimize(PyObject *code, PyObject* consts,
                                      PyObject *names, PyObject *lineno_obj);
# 6 "/usr/include/python2.7/compile.h" 2






struct _node;
PyCodeObject * PyNode_Compile(struct _node *, const char *);



typedef struct {
    int ff_features;
    int ff_lineno;
} PyFutureFeatures;
# 31 "/usr/include/python2.7/compile.h"
struct _mod;
PyCodeObject * PyAST_Compile(struct _mod *, const char *,
     PyCompilerFlags *, PyArena *);
PyFutureFeatures * PyFuture_FromAST(struct _mod *, const char *);
# 136 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/eval.h" 1
# 10 "/usr/include/python2.7/eval.h"
PyObject * PyEval_EvalCode(PyCodeObject *, PyObject *, PyObject *);

PyObject * PyEval_EvalCodeEx(PyCodeObject *co,
     PyObject *globals,
     PyObject *locals,
     PyObject **args, int argc,
     PyObject **kwds, int kwdc,
     PyObject **defs, int defc,
     PyObject *closure);

PyObject * _PyEval_CallTracing(PyObject *func, PyObject *args);
# 137 "/usr/include/python2.7/Python.h" 2


# 1 "/usr/include/python2.7/pyctype.h" 1
# 12 "/usr/include/python2.7/pyctype.h"
extern const unsigned int _Py_ctype_table[256];
# 25 "/usr/include/python2.7/pyctype.h"
extern const unsigned char _Py_ctype_tolower[256];
extern const unsigned char _Py_ctype_toupper[256];
# 139 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/pystrtod.h" 1
# 9 "/usr/include/python2.7/pystrtod.h"
double PyOS_ascii_strtod(const char *str, char **ptr);
double PyOS_ascii_atof(const char *str);


char * PyOS_ascii_formatd(char *buffer, size_t buf_len,
                                      const char *format, double d);
double PyOS_string_to_double(const char *str,
                                         char **endptr,
                                         PyObject *overflow_exception);



char * PyOS_double_to_string(double val,
                                         char format_code,
                                         int precision,
                                         int flags,
                                         int *type);

double _Py_parse_inf_or_nan(const char *p, char **endptr);
# 140 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/pystrcmp.h" 1







int PyOS_mystrnicmp(const char *, const char *, Py_ssize_t);
int PyOS_mystricmp(const char *, const char *);
# 141 "/usr/include/python2.7/Python.h" 2

# 1 "/usr/include/python2.7/dtoa.h" 1





double _Py_dg_strtod(const char *str, char **ptr);
char * _Py_dg_dtoa(double d, int mode, int ndigits,
                        int *decpt, int *sign, char **rve);
void _Py_dg_freedtoa(char *s);
# 142 "/usr/include/python2.7/Python.h" 2


PyObject* _Py_Mangle(PyObject *p, PyObject *name);
# 156 "/usr/include/python2.7/Python.h"

# 1 "/usr/include/python2.7/pyfpe.h" 1
# 129 "/usr/include/python2.7/pyfpe.h"

# 1 "/usr/include/signal.h" 1 3 4
# 31 "/usr/include/signal.h" 3 4



# 1 "/usr/include/bits/sigset.h" 1 3 4
# 104 "/usr/include/bits/sigset.h" 3 4
extern int __sigismember (__const __sigset_t *, int);
extern int __sigaddset (__sigset_t *, int);
extern int __sigdelset (__sigset_t *, int);
# 34 "/usr/include/signal.h" 2 3 4







typedef __sig_atomic_t sig_atomic_t;
# 58 "/usr/include/signal.h" 3 4

# 1 "/usr/include/bits/signum.h" 1 3 4
# 59 "/usr/include/signal.h" 2 3 4
# 79 "/usr/include/signal.h" 3 4

# 1 "/usr/include/bits/siginfo.h" 1 3 4
# 25 "/usr/include/bits/siginfo.h" 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 26 "/usr/include/bits/siginfo.h" 2 3 4







typedef union sigval
  {
    int sival_int;
    void *sival_ptr;
  } sigval_t;
# 51 "/usr/include/bits/siginfo.h" 3 4
typedef struct siginfo
  {
    int si_signo;
    int si_errno;

    int si_code;

    union
      {
 int _pad[((128 / sizeof (int)) - 3)];


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
   } _kill;


 struct
   {
     int si_tid;
     int si_overrun;
     sigval_t si_sigval;
   } _timer;


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
     sigval_t si_sigval;
   } _rt;


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
     int si_status;
     __clock_t si_utime;
     __clock_t si_stime;
   } _sigchld;


 struct
   {
     void *si_addr;
   } _sigfault;


 struct
   {
     long int si_band;
     int si_fd;
   } _sigpoll;
      } _sifields;
  } siginfo_t;
# 129 "/usr/include/bits/siginfo.h" 3 4
enum
{
  SI_ASYNCNL = -60,

  SI_TKILL = -6,

  SI_SIGIO,

  SI_ASYNCIO,

  SI_MESGQ,

  SI_TIMER,

  SI_QUEUE,

  SI_USER,

  SI_KERNEL = 0x80

};



enum
{
  ILL_ILLOPC = 1,

  ILL_ILLOPN,

  ILL_ILLADR,

  ILL_ILLTRP,

  ILL_PRVOPC,

  ILL_PRVREG,

  ILL_COPROC,

  ILL_BADSTK

};


enum
{
  FPE_INTDIV = 1,

  FPE_INTOVF,

  FPE_FLTDIV,

  FPE_FLTOVF,

  FPE_FLTUND,

  FPE_FLTRES,

  FPE_FLTINV,

  FPE_FLTSUB

};


enum
{
  SEGV_MAPERR = 1,

  SEGV_ACCERR

};


enum
{
  BUS_ADRALN = 1,

  BUS_ADRERR,

  BUS_OBJERR

};


enum
{
  TRAP_BRKPT = 1,

  TRAP_TRACE

};


enum
{
  CLD_EXITED = 1,

  CLD_KILLED,

  CLD_DUMPED,

  CLD_TRAPPED,

  CLD_STOPPED,

  CLD_CONTINUED

};


enum
{
  POLL_IN = 1,

  POLL_OUT,

  POLL_MSG,

  POLL_ERR,

  POLL_PRI,

  POLL_HUP

};
# 273 "/usr/include/bits/siginfo.h" 3 4
typedef struct sigevent
  {
    sigval_t sigev_value;
    int sigev_signo;
    int sigev_notify;

    union
      {
 int _pad[((64 / sizeof (int)) - 3)];



 __pid_t _tid;

 struct
   {
     void (*_function) (sigval_t);
     void *_attribute;
   } _sigev_thread;
      } _sigev_un;
  } sigevent_t;






enum
{
  SIGEV_SIGNAL = 0,

  SIGEV_NONE,

  SIGEV_THREAD,


  SIGEV_THREAD_ID = 4

};
# 80 "/usr/include/signal.h" 2 3 4




typedef void (*__sighandler_t) (int);




extern __sighandler_t __sysv_signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__));

extern __sighandler_t sysv_signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__));







extern __sighandler_t signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__));
# 113 "/usr/include/signal.h" 3 4





extern __sighandler_t bsd_signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__));






extern int kill (__pid_t __pid, int __sig) __attribute__ ((__nothrow__));






extern int killpg (__pid_t __pgrp, int __sig) __attribute__ ((__nothrow__));




extern int raise (int __sig) __attribute__ ((__nothrow__));




extern __sighandler_t ssignal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__));
extern int gsignal (int __sig) __attribute__ ((__nothrow__));




extern void psignal (int __sig, __const char *__s);




extern void psiginfo (__const siginfo_t *__pinfo, __const char *__s);
# 168 "/usr/include/signal.h" 3 4
extern int __sigpause (int __sig_or_mask, int __is_sig);
# 177 "/usr/include/signal.h" 3 4
extern int sigpause (int __sig) __asm__ ("__xpg_sigpause");
# 196 "/usr/include/signal.h" 3 4
extern int sigblock (int __mask) __attribute__ ((__nothrow__)) __attribute__ ((__deprecated__));


extern int sigsetmask (int __mask) __attribute__ ((__nothrow__)) __attribute__ ((__deprecated__));


extern int siggetmask (void) __attribute__ ((__nothrow__)) __attribute__ ((__deprecated__));
# 211 "/usr/include/signal.h" 3 4
typedef __sighandler_t sighandler_t;




typedef __sighandler_t sig_t;





extern int sigemptyset (sigset_t *__set) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int sigfillset (sigset_t *__set) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int sigaddset (sigset_t *__set, int __signo) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int sigdelset (sigset_t *__set, int __signo) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int sigismember (__const sigset_t *__set, int __signo)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));



extern int sigisemptyset (__const sigset_t *__set) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int sigandset (sigset_t *__set, __const sigset_t *__left,
        __const sigset_t *__right) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern int sigorset (sigset_t *__set, __const sigset_t *__left,
       __const sigset_t *__right) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2, 3)));





# 1 "/usr/include/bits/sigaction.h" 1 3 4
# 25 "/usr/include/bits/sigaction.h" 3 4
struct sigaction
  {


    union
      {

 __sighandler_t sa_handler;

 void (*sa_sigaction) (int, siginfo_t *, void *);
      }
    __sigaction_handler;







    __sigset_t sa_mask;


    int sa_flags;


    void (*sa_restorer) (void);
  };
# 253 "/usr/include/signal.h" 2 3 4


extern int sigprocmask (int __how, __const sigset_t *__restrict __set,
   sigset_t *__restrict __oset) __attribute__ ((__nothrow__));






extern int sigsuspend (__const sigset_t *__set) __attribute__ ((__nonnull__ (1)));


extern int sigaction (int __sig, __const struct sigaction *__restrict __act,
        struct sigaction *__restrict __oact) __attribute__ ((__nothrow__));


extern int sigpending (sigset_t *__set) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern int sigwait (__const sigset_t *__restrict __set, int *__restrict __sig)
     __attribute__ ((__nonnull__ (1, 2)));






extern int sigwaitinfo (__const sigset_t *__restrict __set,
   siginfo_t *__restrict __info) __attribute__ ((__nonnull__ (1)));






extern int sigtimedwait (__const sigset_t *__restrict __set,
    siginfo_t *__restrict __info,
    __const struct timespec *__restrict __timeout)
     __attribute__ ((__nonnull__ (1)));



extern int sigqueue (__pid_t __pid, int __sig, __const union sigval __val)
     __attribute__ ((__nothrow__));
# 310 "/usr/include/signal.h" 3 4
extern __const char *__const _sys_siglist[65];
extern __const char *__const sys_siglist[65];


struct sigvec
  {
    __sighandler_t sv_handler;
    int sv_mask;

    int sv_flags;

  };
# 334 "/usr/include/signal.h" 3 4
extern int sigvec (int __sig, __const struct sigvec *__vec,
     struct sigvec *__ovec) __attribute__ ((__nothrow__));




# 1 "/usr/include/bits/sigcontext.h" 1 3 4
# 26 "/usr/include/bits/sigcontext.h" 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 27 "/usr/include/bits/sigcontext.h" 2 3 4

struct _fpreg
{
  unsigned short significand[4];
  unsigned short exponent;
};

struct _fpxreg
{
  unsigned short significand[4];
  unsigned short exponent;
  unsigned short padding[3];
};

struct _xmmreg
{
  __uint32_t element[4];
};





struct _fpstate
{

  __uint32_t cw;
  __uint32_t sw;
  __uint32_t tag;
  __uint32_t ipoff;
  __uint32_t cssel;
  __uint32_t dataoff;
  __uint32_t datasel;
  struct _fpreg _st[8];
  unsigned short status;
  unsigned short magic;


  __uint32_t _fxsr_env[6];
  __uint32_t mxcsr;
  __uint32_t reserved;
  struct _fpxreg _fxsr_st[8];
  struct _xmmreg _xmm[8];
  __uint32_t padding[56];
};
# 81 "/usr/include/bits/sigcontext.h" 3 4
struct sigcontext
{
  unsigned short gs, __gsh;
  unsigned short fs, __fsh;
  unsigned short es, __esh;
  unsigned short ds, __dsh;
  unsigned long edi;
  unsigned long esi;
  unsigned long ebp;
  unsigned long esp;
  unsigned long ebx;
  unsigned long edx;
  unsigned long ecx;
  unsigned long eax;
  unsigned long trapno;
  unsigned long err;
  unsigned long eip;
  unsigned short cs, __csh;
  unsigned long eflags;
  unsigned long esp_at_signal;
  unsigned short ss, __ssh;
  struct _fpstate * fpstate;
  unsigned long oldmask;
  unsigned long cr2;
};
# 340 "/usr/include/signal.h" 2 3 4


extern int sigreturn (struct sigcontext *__scp) __attribute__ ((__nothrow__));







# 1 "/usr/lib/gcc/i686-linux-gnu/4.4.5/include/stddef.h" 1 3 4
# 350 "/usr/include/signal.h" 2 3 4




extern int siginterrupt (int __sig, int __interrupt) __attribute__ ((__nothrow__));


# 1 "/usr/include/bits/sigstack.h" 1 3 4
# 26 "/usr/include/bits/sigstack.h" 3 4
struct sigstack
  {
    void *ss_sp;
    int ss_onstack;
  };



enum
{
  SS_ONSTACK = 1,

  SS_DISABLE

};
# 50 "/usr/include/bits/sigstack.h" 3 4
typedef struct sigaltstack
  {
    void *ss_sp;
    int ss_flags;
    size_t ss_size;
  } stack_t;
# 357 "/usr/include/signal.h" 2 3 4



# 1 "/usr/include/sys/ucontext.h" 1 3 4
# 23 "/usr/include/sys/ucontext.h" 3 4

# 1 "/usr/include/signal.h" 1 3 4
# 24 "/usr/include/sys/ucontext.h" 2 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 25 "/usr/include/sys/ucontext.h" 2 3 4
# 148 "/usr/include/sys/ucontext.h" 3 4
typedef int greg_t;





typedef greg_t gregset_t[19];



enum
{
  REG_GS = 0,

  REG_FS,

  REG_ES,

  REG_DS,

  REG_EDI,

  REG_ESI,

  REG_EBP,

  REG_ESP,

  REG_EBX,

  REG_EDX,

  REG_ECX,

  REG_EAX,

  REG_TRAPNO,

  REG_ERR,

  REG_EIP,

  REG_CS,

  REG_EFL,

  REG_UESP,

  REG_SS

};



struct _libc_fpreg
{
  unsigned short int significand[4];
  unsigned short int exponent;
};

struct _libc_fpstate
{
  unsigned long int cw;
  unsigned long int sw;
  unsigned long int tag;
  unsigned long int ipoff;
  unsigned long int cssel;
  unsigned long int dataoff;
  unsigned long int datasel;
  struct _libc_fpreg _st[8];
  unsigned long int status;
};


typedef struct _libc_fpstate *fpregset_t;


typedef struct
  {
    gregset_t gregs;


    fpregset_t fpregs;
    unsigned long int oldmask;
    unsigned long int cr2;
  } mcontext_t;


typedef struct ucontext
  {
    unsigned long int uc_flags;
    struct ucontext *uc_link;
    stack_t uc_stack;
    mcontext_t uc_mcontext;
    __sigset_t uc_sigmask;
    struct _libc_fpstate __fpregs_mem;
  } ucontext_t;
# 360 "/usr/include/signal.h" 2 3 4





extern int sigstack (struct sigstack *__ss, struct sigstack *__oss)
     __attribute__ ((__nothrow__)) __attribute__ ((__deprecated__));



extern int sigaltstack (__const struct sigaltstack *__restrict __ss,
   struct sigaltstack *__restrict __oss) __attribute__ ((__nothrow__));







extern int sighold (int __sig) __attribute__ ((__nothrow__));


extern int sigrelse (int __sig) __attribute__ ((__nothrow__));


extern int sigignore (int __sig) __attribute__ ((__nothrow__));


extern __sighandler_t sigset (int __sig, __sighandler_t __disp) __attribute__ ((__nothrow__));







# 1 "/usr/include/bits/sigthread.h" 1 3 4
# 31 "/usr/include/bits/sigthread.h" 3 4
extern int pthread_sigmask (int __how,
       __const __sigset_t *__restrict __newmask,
       __sigset_t *__restrict __oldmask)__attribute__ ((__nothrow__));


extern int pthread_kill (pthread_t __threadid, int __signo) __attribute__ ((__nothrow__));



extern int pthread_sigqueue (pthread_t __threadid, int __signo,
        const union sigval __value) __attribute__ ((__nothrow__));
# 396 "/usr/include/signal.h" 2 3 4






extern int __libc_current_sigrtmin (void) __attribute__ ((__nothrow__));

extern int __libc_current_sigrtmax (void) __attribute__ ((__nothrow__));
# 130 "/usr/include/python2.7/pyfpe.h" 2

# 1 "/usr/include/setjmp.h" 1 3 4
# 28 "/usr/include/setjmp.h" 3 4



# 1 "/usr/include/bits/setjmp.h" 1 3 4
# 27 "/usr/include/bits/setjmp.h" 3 4

# 1 "/usr/include/bits/wordsize.h" 1 3 4
# 28 "/usr/include/bits/setjmp.h" 2 3 4






typedef int __jmp_buf[6];
# 31 "/usr/include/setjmp.h" 2 3 4

# 1 "/usr/include/bits/sigset.h" 1 3 4
# 32 "/usr/include/setjmp.h" 2 3 4



struct __jmp_buf_tag
  {




    __jmp_buf __jmpbuf;
    int __mask_was_saved;
    __sigset_t __saved_mask;
  };




typedef struct __jmp_buf_tag jmp_buf[1];



extern int setjmp (jmp_buf __env) __attribute__ ((__nothrow__));






extern int __sigsetjmp (struct __jmp_buf_tag __env[1], int __savemask) __attribute__ ((__nothrow__));




extern int _setjmp (struct __jmp_buf_tag __env[1]) __attribute__ ((__nothrow__));
# 78 "/usr/include/setjmp.h" 3 4




extern void longjmp (struct __jmp_buf_tag __env[1], int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));







extern void _longjmp (struct __jmp_buf_tag __env[1], int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));







typedef struct __jmp_buf_tag sigjmp_buf[1];
# 110 "/usr/include/setjmp.h" 3 4
extern void siglongjmp (sigjmp_buf __env, int __val)
     __attribute__ ((__nothrow__)) __attribute__ ((__noreturn__));
# 120 "/usr/include/setjmp.h" 3 4
# 131 "/usr/include/python2.7/pyfpe.h" 2

extern jmp_buf PyFPE_jbuf;
extern int PyFPE_counter;
extern double PyFPE_dummy(void *);
# 157 "/usr/include/python2.7/Python.h" 2
# 34 "csrc/eyelinkmodule.c" 2



# 1 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h" 1
# 35 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"

# 1 "../EyeLinkDisplaySoftwareLinux1.5/include/eyetypes.h" 1
# 41 "../EyeLinkDisplaySoftwareLinux1.5/include/eyetypes.h"
        typedef unsigned char byte;
        typedef signed short INT16;
        typedef unsigned short UINT16;


        typedef signed long INT32;
        typedef unsigned long UINT32;
# 57 "../EyeLinkDisplaySoftwareLinux1.5/include/eyetypes.h"
    typedef struct {
        INT32 msec;
        INT16 usec;
    } MICRO ;
# 36 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h" 2

# 1 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h" 1
# 31 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"

# 1 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h" 1
# 124 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef struct {
    UINT32 time;
    INT16 type;
    UINT16 flags;
    INT16 px[2];
    INT16 py[2];
    INT16 hx[2];
    INT16 hy[2];
    UINT16 pa[2];
    INT16 gx[2];
    INT16 gy[2];
    INT16 rx;
    INT16 ry;
    UINT16 status;
    UINT16 input;
    UINT16 buttons;
    INT16 htype;
    INT16 hdata[8];
} ISAMPLE;
# 162 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef struct {
    UINT32 time;
    INT16 type;
    UINT16 flags;
    float px[2];
    float py[2];
    float hx[2];
    float hy[2];
    float pa[2];
    float gx[2];
    float gy[2];
    float rx;
    float ry;
    UINT16 status;
    UINT16 input;
    UINT16 buttons;
    INT16 htype;
    INT16 hdata[8];
} FSAMPLE;
# 196 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef struct {
    double time;
    INT16 type;
    UINT16 flags;
    float px[2];
    float py[2];
    float hx[2];
    float hy[2];
    float pa[2];
    float gx[2];
    float gy[2];
    float rx;
    float ry;
    UINT16 status;
    UINT16 input;
    UINT16 buttons;
    INT16 htype;
    INT16 hdata[8];
} DSAMPLE;
# 229 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef struct {
 UINT32 struct_size;


 float raw_pupil[2];
 float raw_cr[2];
 UINT32 pupil_area;
 UINT32 cr_area;
 UINT32 pupil_dimension[2];
 UINT32 cr_dimension[2];
 UINT32 window_position[2];
 float pupil_cr[2];

 UINT32 cr_area2;
 float raw_cr2[2];
} FSAMPLE_RAW;
# 263 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef struct {
    UINT32 time;
    INT16 type;
    UINT16 read;
    INT16 eye;
    UINT32 sttime;
    UINT32 entime;
    INT16 hstx;
    INT16 hsty;
    INT16 gstx;
    INT16 gsty;
    UINT16 sta;
    INT16 henx;
    INT16 heny;
    INT16 genx;
    INT16 geny;
    UINT16 ena;
    INT16 havx;
    INT16 havy;
    INT16 gavx;
    INT16 gavy;
    UINT16 ava;
    INT16 avel;
    INT16 pvel;
    INT16 svel;
    INT16 evel;
    INT16 supd_x;
    INT16 eupd_x;
    INT16 supd_y;
    INT16 eupd_y;
    UINT16 status;
} IEVENT;
# 319 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef struct {
    UINT32 time;
    INT16 type;
    UINT16 read;
    INT16 eye;
    UINT32 sttime;
    UINT32 entime;
    float hstx;
    float hsty;
    float gstx;
    float gsty;
    float sta;
    float henx;
    float heny;
    float genx;
    float geny;
    float ena;
    float havx;
    float havy;
    float gavx;
    float gavy;
    float ava;
    float avel;
    float pvel;
    float svel;
    float evel;
    float supd_x;
    float eupd_x;
    float supd_y;
    float eupd_y;
    UINT16 status;
} FEVENT;
# 372 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef struct {
    double time;
    INT16 type;
    UINT16 read;
    INT16 eye;
    double sttime;
    double entime;
    float hstx;
    float hsty;
    float gstx;
    float gsty;
    float sta;
    float henx;
    float heny;
    float genx;
    float geny;
    float ena;
    float havx;
    float havy;
    float gavx;
    float gavy;
    float ava;
    float avel;
    float pvel;
    float svel;
    float evel;
    float supd_x;
    float eupd_x;
    float supd_y;
    float eupd_y;
    UINT16 status;
} DEVENT;
# 420 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef struct {
    UINT32 time;
    INT16 type;
    UINT16 length;
    byte text[260];
} IMESSAGE;
# 443 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef struct {
    double time;
    INT16 type;
    UINT16 length;
    byte text[260];
} DMESSAGE;
# 469 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef struct {
    UINT32 time;
    INT16 type;
    UINT16 data;
} IOEVENT;
# 494 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef struct {
    double time;
    INT16 type;
    UINT16 data;
} DIOEVENT;
# 508 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef union {
    IEVENT ie;
    IMESSAGE im;
    IOEVENT io;
    ISAMPLE is;
} ALL_DATA ;
# 523 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef union {
    FEVENT fe;
    IMESSAGE im;
    IOEVENT io;
    FSAMPLE fs;
} ALLF_DATA ;
# 538 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef union {
    DEVENT fe;
    DMESSAGE im;
    DIOEVENT io;
    DSAMPLE fs;
} ALLD_DATA ;
# 723 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
typedef byte ELINKADDR[16];




typedef struct {
    ELINKADDR addr;
    char name[40];
} ELINKNODE;





typedef struct {

    UINT32 time;
    UINT32 version;

    UINT16 samrate;
    UINT16 samdiv;

    UINT16 prescaler;
    UINT16 vprescaler;
    UINT16 pprescaler;
    UINT16 hprescaler;

    UINT16 sample_data;
    UINT16 event_data;
    UINT16 event_types;

    byte in_sample_block;
    byte in_event_block;
    byte have_left_eye;
    byte have_right_eye;

    UINT16 last_data_gap_types;
    UINT16 last_data_buffer_type;
    UINT16 last_data_buffer_size;

    UINT16 control_read;
    UINT16 first_in_block;

    UINT32 last_data_item_time;
    UINT16 last_data_item_type;
    UINT16 last_data_item_contents;

    ALL_DATA last_data_item;

    UINT32 block_number;
    UINT32 block_sample;
    UINT32 block_event;


    UINT16 last_resx;
    UINT16 last_resy;
    UINT16 last_pupil[2];
    UINT16 last_status;



    UINT16 queued_samples;
    UINT16 queued_events;

    UINT16 queue_size;
    UINT16 queue_free;

    UINT32 last_rcve_time;

    byte samples_on;
    byte events_on;

    UINT16 packet_flags;

    UINT16 link_flags;
    UINT16 state_flags;
    byte link_dstatus;
    byte link_pendcmd;
    UINT16 reserved;
# 810 "../EyeLinkDisplaySoftwareLinux1.5/include/eye_data.h"
    char our_name[40];
    ELINKADDR our_address;
    char eye_name[40];
    ELINKADDR eye_address;

    ELINKADDR ebroadcast_address;
    ELINKADDR rbroadcast_address;

    UINT16 polling_remotes;
    UINT16 poll_responses;
    ELINKNODE nodes[4];

} ILINKDATA;
# 32 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h" 2
# 140 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT16 open_eyelink_system(UINT16 bufsize, char *options);
# 179 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
void eyelink_set_name(char *name);
# 190 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
void close_eyelink_system(void);
# 230 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT32 current_time(void);
# 244 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT32 current_micro(MICRO *m);
# 291 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT32 current_usec(void);
# 319 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
void msec_delay(UINT32 n);
# 333 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
double current_double_usec(void);
# 342 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
extern ELINKADDR eye_broadcast_address;




extern ELINKADDR rem_broadcast_address;




extern ELINKADDR our_address;
# 402 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_open_node(ELINKADDR node, INT16 busytest);
# 441 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_open(void);
# 493 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_broadcast_open(void);
# 521 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_dummy_open(void);
# 549 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_close(INT16 send_msg);
# 559 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_reset_clock(INT16 enable);
# 594 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_is_connected(void);
# 649 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_quiet_mode(INT16 mode);
# 663 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_poll_trackers(void);
# 720 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_poll_remotes(void);
# 735 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_poll_responses(void);
# 754 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_get_node(INT16 resp, void *data);
# 829 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_node_send(ELINKADDR node, void *data,
                                   UINT16 dsize);
# 849 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_node_receive(ELINKADDR node, void *data);
# 909 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_send_command(char *text);
# 922 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_command_result(void);
# 959 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_timed_command(UINT32 msec, char *text);
# 972 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_last_message(char *buf);
# 985 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_send_message(char *msg);
# 1002 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_node_send_message(ELINKADDR node, char *msg);
# 1018 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_send_message_ex(UINT32 exectime, char *msg);
# 1028 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_node_send_message_ex(UINT32 exectime,ELINKADDR node, char *msg);
# 1082 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_read_request(char *text);
# 1098 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_read_reply(char *buf);
# 1133 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT32 eyelink_request_time(void);
# 1149 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT32 eyelink_node_request_time(ELINKADDR node);
# 1162 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT32 eyelink_read_time(void);
# 1191 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_abort(void);




INT16 eyelink_start_setup(void);
# 1236 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_in_setup(void);
# 1323 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_target_check(INT16 *x, INT16 *y);
# 1340 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_accept_trigger(void);
# 1404 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_driftcorr_start(INT16 x, INT16 y);
# 1421 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_cal_result(void);
# 1434 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_apply_driftcorr(void);
# 1473 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_cal_message(char *msg);
# 1517 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_current_mode(void);
# 1609 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_tracker_mode(void);
# 1627 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_wait_for_mode_ready(UINT32 maxwait);
# 1665 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_user_menu_selection(void);
# 1702 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_position_prescaler(void);
# 1715 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_reset_data(INT16 clear);
# 1783 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
  void * eyelink_data_status(void);
# 1851 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_in_data_block(INT16 samples,INT16 events);
# 1905 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_wait_for_block_start(UINT32 maxwait,
                   INT16 samples, INT16 events);
# 1972 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_get_next_data(void *buf);
# 2023 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_get_last_data(void *buf);
# 2063 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_newest_sample(void *buf);
# 2079 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_get_float_data(void *buf);
# 2095 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_get_double_data(void *buf);
# 2178 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_newest_float_sample(void *buf);
# 2194 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_newest_double_sample(void *buf);
# 2238 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_eye_available(void);





UINT16 eyelink_sample_data_flags(void);
# 2297 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT16 eyelink_event_data_flags(void);
# 2320 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT16 eyelink_event_type_flags(void);
# 2370 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_data_count(INT16 samples, INT16 events);
# 2404 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_wait_for_data(UINT32 maxwait,
                INT16 samples, INT16 events);
# 2508 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_get_sample(void *sample);
# 2538 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_data_switch(UINT16 flags);
# 2602 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_data_start(UINT16 flags, INT16 lock);
# 2616 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_data_stop(void);
# 2679 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_playback_start(void);
# 2690 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_playback_stop(void);
# 2717 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_request_image(INT16 type, INT16 xsize, INT16 ysize);






INT16 eyelink_image_status(void);





void eyelink_abort_image(void);






INT16 eyelink_image_data(INT16 *xsize, INT16 *ysize, INT16 *type);





INT16 eyelink_get_line(void *buf);
# 2754 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
typedef struct {
    byte palette_id;
    byte ncolors;

    byte camera;
    byte threshold;
    UINT16 flags;
    UINT16 image_number;
    byte extra[10];

    byte rfirst_color;
    byte rfirst_brite;
    byte rlast_color;
    byte rlast_brite;
    INT16 nspecial;

    struct {
         byte index;
         byte r;
         byte g;
         byte b;
    } spcolors[6];
} IMAGE_PALDATA;
# 2788 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_get_palette(void *pal);
# 2878 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT16 eyelink_read_keybutton(INT16 *mods,
                  INT16 *state, UINT16 *kcode, UINT32 *time);
# 2906 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_send_keybutton(UINT16 code, UINT16 mods, INT16 state);
# 2975 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT16 eyelink_button_states(void);
# 2987 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT16 eyelink_last_button_states(UINT32 *time);
# 3047 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT16 eyelink_last_button_press(UINT32 *time);
# 3111 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_flush_keybuttons(INT16 enable_buttons);
# 3122 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_request_file_read(char *src);
# 3142 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_get_file_block(void *buf, INT32 *offset);





INT16 eyelink_request_file_block(UINT32 offset);






INT16 eyelink_end_file_transfer(void);
# 3186 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_get_tracker_version(char *c);




INT16 eyelink2_mode_data(INT16 *sample_rate, INT16 *crmode,
                                  INT16 *file_filter, INT16 *link_filter);
# 3241 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_mode_data(INT16 *sample_rate, INT16 *crmode,
                                  INT16 *file_filter, INT16 *link_filter);
# 3254 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_bitmap_packet(void *data, UINT16 size, UINT16 seq);
# 3263 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
INT16 eyelink_bitmap_ack_count(void);
# 3287 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
void eyelink_set_tracker_node(ELINKADDR node);
# 3343 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
double eyelink_tracker_double_usec(void);
# 3380 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT32 eyelink_tracker_msec(void);
# 3398 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
double eyelink_double_usec_offset(void);
# 3411 "../EyeLinkDisplaySoftwareLinux1.5/include/eyelink.h"
UINT32 eyelink_msec_offset(void);
# 37 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h" 2
# 79 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
  typedef struct
  {
   INT32 left;
   INT32 top;
   INT32 right;
   INT32 bottom;
   INT32 width;
   INT32 height;
   INT32 bits;
   INT32 palsize;
   INT32 palrsvd;

   INT32 pages;
   float refresh;
   INT32 winnt;
  } DISPLAYINFO;
# 136 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 open_eyelink_connection(INT16 mode);
# 149 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void close_eyelink_connection(void);
# 183 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 set_eyelink_address(char *addr);
# 193 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT32 set_application_priority(INT32 priority);
# 276 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 message_pump();





INT16 key_message_pump(void);
# 322 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void pump_delay(UINT32 delay);
# 359 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void flush_getkey_queue(void);
# 378 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
UINT16 read_getkey_queue(void);
# 435 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
UINT16 echo_key(void);
# 507 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
UINT16 getkey(void);
# 517 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
UINT32 getkey_with_mod(UINT16 *unicode) ;
# 580 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 eyecmd_printf(char *fmt, ...);
# 615 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 eyemsg_printf(char *fmt, ...);
# 655 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 eyemsg_printf_ex(UINT32 exectime, char *fmt, ...);
# 740 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 start_recording(INT16 file_samples, INT16 file_events,
                         INT16 link_samples, INT16 link_events);
# 767 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 check_recording(void);
# 782 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void stop_recording(void);
# 812 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void set_offline_mode(void);
# 832 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 check_record_exit(void);
# 873 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void exit_calibration(void);
# 924 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 do_tracker_setup(void);
# 995 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 do_drift_correct(INT16 x, INT16 y, INT16 draw, INT16 allow_setup);
# 1012 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 target_mode_display(void);
# 1029 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 image_mode_display(void);
# 1048 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void alert_printf(char *fmt, ...);
# 1089 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT32 receive_data_file(char *src, char *dest, INT16 dest_is_path);
# 1117 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT32 receive_data_file_feedback(char *src, char *dest, INT16 dest_is_path,
                  void( *progress)(unsigned int size,unsigned int received));
# 1135 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 open_data_file(char *name);
# 1145 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 close_data_file(void);
# 1169 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 escape_pressed(void);
# 1212 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 break_pressed(void);
# 1266 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void terminal_break(INT16 assert);
# 1275 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 application_terminated(void);
# 1331 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void begin_realtime_mode(UINT32 delay);
# 1348 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void end_realtime_mode(void);





void set_high_priority(void);




void set_normal_priority(void);






INT32 in_realtime_mode(void);






void eyelink_enable_extended_realtime(void);







typedef struct
{
    byte r;
    byte g;
    byte b;
    byte unused;
}EYECOLOR;




typedef struct {
    int ncolors;
    EYECOLOR *colors;
}EYEPALETTE;






typedef struct
{

    byte colorkey;
    INT32 Rmask;
    INT32 Gmask;
    INT32 Bmask;
    INT32 Amask;
    EYEPALETTE *palette;
}EYEPIXELFORMAT;




typedef struct
{
    INT32 w;
    INT32 h;
    INT32 pitch;
    INT32 depth;
    void *pixels;
    EYEPIXELFORMAT *format;
}EYEBITMAP;




typedef enum
{
  JPEG,
  PNG,
  GIF,
  BMP,
  XPM,
}IMAGETYPE;
# 1458 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
char * eyelink_get_error(int id, char *function_name);
# 1502 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void splice_fname(char *fname, char *path, char *ffname);
# 1513 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
int check_filename_characters(char *name);





int file_exists(char *path);
# 1529 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
int create_path(char *path, INT16 create, INT16 is_dir);
# 1574 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
int el_bitmap_save_and_backdrop(EYEBITMAP * hbm, INT16 xs, INT16 ys,
                                   INT16 width, INT16 height,char *fname,
                                   char *path, INT16 sv_options,INT16 xd,
                                   INT16 yd, UINT16 xferoptions);
# 1608 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
int el_bitmap_to_backdrop(EYEBITMAP * hbm, INT16 xs, INT16 ys,
                                   INT16 width, INT16 height,INT16 xd,
                                   INT16 yd, UINT16 xferoptions);
# 1635 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
int el_bitmap_save(EYEBITMAP * hbm, INT16 xs, INT16 ys,
                                   INT16 width, INT16 height,char *fname,
                                   char *path, INT16 sv_options);
# 1687 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
typedef struct {
    byte type;
    byte state;
    UINT16 key;
 UINT16 modifier;
 UINT16 unicode;
} KeyInput;




typedef struct {
    byte type;
    byte which;
    byte state;
    UINT16 x, y;
    UINT16 xrel;
    UINT16 yrel;
} MouseMotionEvent;




typedef struct {
    byte type;
    byte which;
    byte button;
    byte state;
    UINT16 x, y;
} MouseButtonEvent;
# 1726 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
typedef union
{
    byte type;
    KeyInput key;
    MouseMotionEvent motion;
    MouseButtonEvent button;

}InputEvent;
# 1742 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
typedef struct
{




    INT16 ( * setup_cal_display_hook)(void);





    void ( * exit_cal_display_hook)(void) ;




    void ( * record_abort_hide_hook)(void) ;
# 1769 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
    INT16 ( * setup_image_display_hook)(INT16 width, INT16 height) ;







    void ( * image_title_hook)(INT16 threshold, char *cam_name) ;
# 1799 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
    void ( * draw_image_line_hook)(INT16 width, INT16 line,
                         INT16 totlines, byte *pixels) ;
# 1812 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
    void ( * set_image_palette_hook)(INT16 ncolors, byte r[],
                         byte g[], byte b[]) ;






    void ( * exit_image_display_hook)(void) ;




    void ( * clear_cal_display_hook)() ;





    void ( * erase_cal_target_hook)();
# 1841 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
    void ( * draw_cal_target_hook)(INT16 x, INT16 y);




    void ( * cal_target_beep_hook)(void) ;





    void ( * cal_done_beep_hook)(INT16 error) ;





    void ( * dc_done_beep_hook)(INT16 error) ;




    void ( * dc_target_beep_hook)(void) ;
# 1923 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
    short ( * get_input_key_hook)(InputEvent * event);







    void ( * alert_printf_hook)(const char *);
}HOOKFCNS;
# 1969 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void setup_graphic_hook_functions( HOOKFCNS *hooks);
# 1978 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
HOOKFCNS * get_all_hook_functions();






int set_write_image_hook(
               int ( * hookfn)(char *outfilename,
                                         int format,
                                         EYEBITMAP *bitmap),
               int options );



int eyelink_peep_input_event(InputEvent *event, int mask);



int eyelink_get_input_event(InputEvent *event,int mask);



int eyelink_peep_last_input_event(InputEvent *event, int mask);



void eyelink_flush_input_event();
# 2025 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT32 eyelink_initialize_mapping(float left, float top, float right, float bottom);
# 2037 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT32 eyelink_href_to_gaze( float *xp, float *yp, FSAMPLE *sample);
# 2049 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT32 eyelink_gaze_to_href( float *xp, float *yp, FSAMPLE *sample);
# 2058 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
float eyelink_href_angle(float x1,float y1, float x2, float y2);
# 2068 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void eyelink_href_resolution(float x,float y, float *xres, float *yres);
# 2089 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
int get_image_xhair_data(INT16 x[4], INT16 y[4], INT16 *xhairs_on);






int eyelink_get_extra_raw_values(FSAMPLE *s,FSAMPLE_RAW *rv);


int eyelink_get_extra_raw_values_v2(FSAMPLE *s,int eye,FSAMPLE_RAW *rv);
# 2188 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
int eyelink_calculate_velocity_x_y(int slen, float xvel[2], float yvel[2], FSAMPLE *vel_sample);
# 2202 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
int eyelink_calculate_velocity(int slen, float vel[2], FSAMPLE *vel_sample);
# 2219 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
int eyelink_calculate_overallvelocity_and_acceleration(int slen, float vel[2], float acc[2], FSAMPLE *vel_sample);
# 2228 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT16 timemsg_printf(UINT32 t, char *fmt, ...);






int open_message_file(char *fname);



void close_message_file(void);
# 2257 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
typedef struct _CrossHairInfo CrossHairInfo;






struct _CrossHairInfo
{
 short majorVersion;
 short minorVersion;




 int w;





 int h;





 void *privatedata;





 void *userdata;





 void (*drawLine)(CrossHairInfo *dt, int x1, int y1, int x2, int y2, int colorindex);
# 2310 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
 void (*drawLozenge)(CrossHairInfo *dt, int x, int y, int w, int h, int colorindex);




 void (*getMouseState)(CrossHairInfo *dt, int *x, int *y, int *state);

 int reserved1;
 int reserved2;
 int reserved3;
 int reserved4;



};
# 2338 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
INT32 eyelink_draw_cross_hair(CrossHairInfo *chi);
# 2347 "../EyeLinkDisplaySoftwareLinux1.5/include/core_expt.h"
void eyelink_dll_version(char *c);
# 37 "csrc/eyelinkmodule.c" 2





# 1 "csrc/eyelinkmodule.h" 1


typedef struct
{
    Py_ssize_t ob_refcnt; struct _typeobject *ob_type;
}
EyelinkTrackerObject;



char * getMultiByte(char *text,int len);
static PyObject * Eyelink__new__(PyTypeObject *type, PyObject *args, PyObject *kwds);
static void getTrackerModule();
static void eyelink_dealloc(PyObject* self);
static PyObject * eyelink_getattr(PyObject *obj, char *name);
static int eyelink_setattr(PyObject *obj, char *name, PyObject *v);
# 42 "csrc/eyelinkmodule.c" 2

# 1 "csrc/docstr.h" 1
static char alert_doc[]=
 "alert(message)\n"
 "This method is used to give a notification to the user when an error occurs.\n"
 "Parameters\n"
 "<message>: Text message to be displayed.\n"
 "Return Value:\n"
 "None\n"
 "Remarks:\n"
 "This function does not allow printf formatting as in c. However you can do a formatted string argument in python.\n"
 "This is equivalent to the C API void alert_printf(char *fmt, ...);\n";


static char beginRealTimeMode_doc[]=
"beginRealTimeMode(delay)\n"
"Sets the application priority and cleans up pending Windows activity to place the application in realtime\n"
"mode. This could take up to 100 milliseconds, depending on the operation system, to set the application\n"
"priority.\n"
"Parameters\n"
"<delay> an integer, used to set the minimum time this function takes, so that this function can act as\n"
"a useful delay.\n"
"Return Value\n"
"None\n"
"This function is equivalent to the C API void begin_realtime_mode(UINT32 delay);\n";

static char closeGraphics_doc[]=
"closeGraphics()\n"
"Notifies the eyelink_core_graphics to close or release the graphics.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"None\n"
"This is equivalent to the C API void close_expt_graphics(void);\n"
"This function should not be used with custom graphics \n";

static char currentDoubleUsec_doc[]=
"currentDoubleTime()\n"
"Returns the current microsecond time (as a double type) since the initialization\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"A float data for the current microsecond time since the initialization\n"
"Remarks:\n"
"Same as currentUsec except, this function can return large microseconds.\n"
"return up to 2147483648 microseconds starting from initialization.\n"
"up to 36028797018963968 microseconds.\n"
"This is equivalent to the C API double current_double_usec(void);\n";


static char currentTime_doc[]=
"currentTime()\n"
"Returns the current millisecond time since the initialization of the EyeLink library.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"Long integer for the current millisecond time since the initialization of the EyeLink library\n"
"This function is equivalent to the C API UINT32 current_time(void);\n";


static char currentUsec_doc[]=
"currentUsec()\n"
"Returns the current microsecond time since the initialization of the EyeLink library.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"Long integer for the current microsecond time since the initialization of the EyeLink library\n"
"This is equivalent to the C API UINT32 current_usec(void);\n";


static char endRealTimeMode_doc[]=
"endRealTimeMode()\n"
"Returns the application to a priority slightly above normal, to end realtime mode. This function should\n"
"execute rapidly, but there is the possibility that Windows will allow other tasks to run after this call, causing\n"
"delays of 1-20 milliseconds.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"None\n"
"This function is equivalent to the C API void end_realtime_mode(void);\n";

static char flushGetkeyQueue_doc[]=
"flushGetkeyQueue()\n"
"Initializes the key queue used by getkey(). It may be called at any time to get rid any of old keys from the\n"
"queue.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"None\n"
"This is equivalent to the C API void flush_getkey_queue(void);\n";




static char getDisplayInformation_doc[]=
"getDisplayInformation()\n"
"Returns the display configuration.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"Instance of DisplayInfo class. The width, height, bits, and refresh rate of the display can be accessed\n"
"from the returned value.\n"
"For example.\n"
"display = getDisplayInformation()\n"
"print display.width, display.height, display.bits, display.refresh\n";



static char msecDelay_doc[]=
"msecDelay(delay)\n"
"Does a unblocked delay using currentTime().\n"
"Parameters\n"
"<delay>: an integer for number of milliseconds to delay.\n"
"Return Value\n"
"None\n"
"This is equivalent to the C API void msec_delay(UINT32 n);\n";


static char openGraphics_doc[]=
"openGraphics(dimension, bits);\n"
"Opens the graphics if the display mode is not set. If the display mode is already set, uses the existing\n"
"display mode.\n"
"Parameters\n"
"<dimension>: two-item tuple of display containing width and height information.\n"
"<bits>: color bits.\n"
"Return Value\n"
"None or run-time error.\n"
"This is equivalent to the SDL version C API INT16 init_expt_graphics(SDL_Surface * s, DISPLAYINFO *info).\n";


static char pumpDelay_doc[]=
"pumpDelay(delay)\n"
"During calls to msecDelay(), Windows is not able to handle messages. One result of this is that windows\n"
"may not appear. This is the preferred delay function when accurate timing is not needed. It calls\n"
"pumpMessages() until the last 20 milliseconds of the delay, allowing Windows to function properly. In rare\n"
"cases, the delay may be longer than expected. It does not process modeless dialog box messages.\n"
"Parameters\n"
"<delay>: an integer, which sets number of milliseconds to delay.\n"
"Return Value\n"
"None\n"
"Use the This is equivalent to the C API void pump_delay(UINT32 delay);\n";

static char setCalibrationSounds_doc[]=
"setCalibrationSounds(target, good, error)\n"
"Selects the sounds to be played during do_tracker_setup(), including calibration, validation and drift\n"
"correction. These events are the display or movement of the target, successful conclusion of calibration or\n"
"good validation, and failure or interruption of calibration or validation.\n"
"Note: If no sound card is installed, the sounds are produced as beeps from the PC speaker. Otherwise,\n"
"sounds can be selected by passing a string. If the string is  (empty), the default sounds are played. If the\n"
"string is off, no sound will be played for that event. Otherwise, the string should be the name of a .WAV\n"
"file to play.\n"
"Parameters\n"
"<target>: Sets sound to play when target moves;\n"
"<good>: Sets sound to play on successful operation;\n"
"<error>: Sets sound to play on failure or interruption.\n"
"Return Value\n"
"None\n"
"This function is equivalent to the C API void set_cal_sounds(char *target, char *good, char *error);\n";



static char setCalibrationColors_doc[]=
"setCalibrationColors(foreground_color, background_color)\n"
"Passes the colors of the display background and fixation target to the eyelink_core_graphics library. During\n"
"calibration, camera image display, and drift correction, the display background should match the brightness\n"
"of the experimental stimuli as closely as possible, in order to maximize tracking accuracy. This function\n"
"passes the colors of the display background and fixation target to the eyelink_core_graphics library. This\n"
"also prevents flickering of the display at the beginning and end of drift correction.\n"
"Parameters\n"
"<foreground_color>: color for foreground calibration target.\n"
"<background_color>: color for foreground calibration background. Both colors must be a threeinteger\n"
"(from 0 to 255) tuple encoding the red, blue, and green color component.\n"
"Return Value\n"
"None\n"
"This is equivalent to the C API void set_calibration_colors(SDL_Color *fg, SDL_Color *bg);\n"
"Example:\n"
"setCalibrationColors((0, 0, 0), (255, 255, 255))\n"
"This sets the calibration target in black and calibration background in white.\n";


static char setCameraPosition_doc[]=
"setCameraPosition(left, top, right, bottom)\n"
"Sets the camera position on the display computer. Moves the top left hand corner of the camera position\n"
"to new location.\n"
"Parameters\n"
"<left>: x-coord of upper-left corner of the camera image window;\n"
"<top>: y-coord of upper-left corner of the camera image window;\n"
"<right>: x-coord of lower-right corner of the camera image window;\n"
"<bottom>: y-coord of lower-right corner of the camera image window.\n"
"Return Value\n"
"None\n";


static char setDriftCorrectSounds_doc[]=
"setDriftCorrectSounds(target, good, setup)\n"
"Selects the sounds to be played during doDriftCorrect(). These events are the display or movement of\n"
"the target, successful conclusion of drift correction, and pressing the ESC key to start the Setup menu.\n"
"Note:\n"
"If no sound card is installed, the sounds are produced as beeps from the PC speaker. Otherwise, sounds\n"
"can be selected by passing a string. If the string is  (empty), the default sounds are played. If the string\n"
"is off, no sound will be played for that event. Otherwise, the string should be the name of a .WAV file to\n"
"play.\n"
"Parameters\n"
"<target>: Sets sound to play when target moves;\n"
"<good>: Sets sound to play on successful operation;\n"
"<setup>: Sets sound to play on ESC key pressed.\n"
"Return Value\n"
"None\n"
"This function is equivalent to the C API void set_dcorr_sounds(char *target, char *good, char *setup);\n";

static char setTargetSize_doc[]=
"setTargetSize(diameter, holesize)\n"
"The standard calibration and drift correction target is a disk (for peripheral delectability) with a central\n"
"hole target (for accurate fixation). The sizes of these features may be set with this function.\n"
"Parameters\n"
"<diameter>: Size of outer disk, in pixels.\n"
"<holesize>: Size of central feature, in pixels. If holesize is 0, no central feature will be drawn. The\n"
"disk is drawn in the calibration foreground color, and the hole is drawn in the calibration background\n"
"color.\n"
"Return Value\n"
"None\n"
"This function is equivalent to the C API void set_target_size(UINT16 diameter, UINT16 holesize);\n";




static char abort_doc[]=
"abort()\n"
"Places EyeLink tracker in off-line (idle) mode.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"0 if mode switch begun, else link error\n"
"Remarks\n"
"Use before attempting to draw graphics on the tracker display, transferring files, or closing link. Always\n"
"call waitForModeReady() afterwards to ensure tracker has finished the mode transition. This function\n"
"pair is implemented by the EyeLink toolkit library function setOfflineMode().\n"
"This function is equivalent to the C API INT16 eyelink_abort(void);\n";

static char acceptTrigger_doc[]=
"acceptTrigger()\n"
"Triggers the EyeLink tracker to accept a fixation on a target, similar to the �Enter� key or spacebar on the\n"
"tracker.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"NO_REPLY if drift correction not completed yet\n"
"OK_RESULT (0) if success\n"
"ABORT_REPLY (27) if �Esc� key aborted operation\n"
"-1 if operation failed\n"
"1 if poor calibration or excessive validation error.\n"
"This function is equivalent to the C API INT16 eyelink_accept_trigger(void);\n";

static char applyDriftCorrect_doc[]=
"applyDriftCorrect()\n"
"Applies the results of the last drift correction. This is not done automatically after a drift correction, allowing\n"
"the message returned by getCalibrationMessage() to be examined first.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"0 if command sent ok, else link error.\n"
"This function is equivalent to the C API INT16 eyelink_apply_driftcorr(void);\n";

static char breakPressed_doc[]=
"breakPressed()\n"
"Tests if the program is being interrupted. You should break out of loops immediately if this function does\n"
"not return 0, if getkey() return TERMINATE_KEY, or if isConnected() method of the class returns 0.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"1 if CTRL-C is pressed, terminalBreak() was called, or the program has been terminated with ALT-F4;\n"
"0 otherwise\n"
"Remarks\n"
"Under Windows XP, this call will not work in realtime mode at all, and will take several seconds to\n"
"respond if graphics are being drawn continuously. This function works well in realtime mode under\n"
"Windows 2000.\n"
"This function is equivalent to the C API INT16 break_pressed(void);\n";



static char broadcastOpen_doc[]=
"broadcastOpen()\n"
"Allows a third computer to listen in on a session between the eye tracker and a controlling remote machine.\n"
"This allows it to receive data during recording and playback, and to monitor the eye tracker mode. The\n"
"local computer will not be able to send commands to the eye tracker, but may be able to send messages or\n"
"request the tracker time.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"0 if successful.\n"
"LINK_INITIALIZE_FAILED if link could not be established.\n"
"CONNECT_TIMEOUT_FAILED if tracker did not respond.\n"
"WRONG_LINK_VERSION if the versions of the EyeLink library and tracker are incompatible\n"
"Remarks\n"
"This may not function properly, if there are more than one Ethernet cards installed.\n"
"This function is equivalent to the C API INT16 eyelink_broadcast_open(void);\n";

static char close_doc[]=
"close()\n"
"Sends a disconnect message to the EyeLink tracker.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"0 if successful, otherwise linkerror.\n"
"This function is equivalent to the C API INT16 eyelink_close(int send_msg); with send_msg parameter 1.\n";

static char closeDataFile_doc[]=
"closeDataFile()\n"
"Closes any currently opened EDF file on the EyeLink tracker computer�s hard disk. This may take several\n"
"seconds to complete.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"0 if command executed successfully else error code.\n"
"This function is equivalent to the C API int close_data_file(void);\n";

static char commandResult_doc[]=
"commandResult()\n"
"Check for and retrieves the numeric result code sent by the tracker from the last command.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"NO_REPLY if no reply to last command\n"
"OK_RESULT (0) if OK\n"
"Other error codes represent tracker execution error.\n"
"This function is equivalent to the C API INT16 eyelink_command_result(void);\n";

static char dataSwitch_doc[]=
"dataSwitch(flag)\n"
"Sets what data from tracker will be accepted and placed in queue. Note: This does not start the tracker\n"
"recording, and so can be used with broadcastOpen(). It also does not clear old data from the queue.\n"
"Parameters\n"
"<flags> bitwise OR of the following flags:\n"
"RECORD_LINK_SAMPLES - send samples on link\n"
"RECORD_LINK_EVENTS - send events on link\n"
"Return Value\n"
"0 if no error, else link error code\n"
"This function is equivalent to the C API INT16 eyelink_data_switch(UINT16 flags);\n";

static char doDriftCorrect_doc[]=
"doDriftCorrect(x, y, draw, allow_setup)\n"
"Performs a drift correction before a trial.\n"
"Parameters:\n"
"<x, y>: Position (in pixels) of drift correction target.\n"
"<draw>: If 1, the drift correction will clear the screen to the target background color, draw the target,\n"
"and clear the screen again when the drift correction is done. If 0, the fixation target must be drawn by\n"
"the user.\n"
"<allow_setup>: if 1, accesses Setup menu before returning, else aborts drift correction.\n"
"Return value\n"
"0 if successful, 27 if �Esc� key was pressed to enter Setup menu or abort\n"
"This is equivalent to the C API int do_drift_correct(int x, int y, int draw, int allow_setup);\n";

static char doTrackerSetup_doc[]=
"doTrackerSetup(position)\n"
"Switches the EyeLink tracker to the Setup menu, from which camera setup, calibration, validation, drift\n"
"correction, and configuration may be performed. Pressing the �Esc� key on the tracker keyboard will exit the\n"
"Setup menu and return from this function. Calling exitCalibration() from an event handler will cause any\n"
"call to doTrackerSetup() in progress to return immediately.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"None\n"
"This is equivalent to the C API int do_tracker_setup(void);";


static char drawCalTarget_doc[]=
"drawCaltarget()\n"
"Allow the normal calibration target drawing to proceed at different locations.\n"
"Parameters\n"
"Position: A tuple in the format of (x, y), passing along the position of drift correction target. X and y\n"
"are in screen pixels.\n"
"Return Value\n"
"None\n"
"This is equivalent to the C API INT16 CALLTYPE set_draw_cal_target_hook(INT16 (CALLBACK *\n"
"erase_cal_target_hook)(HDC hdc), INT16 options);\n";

static char echo_key_doc[]=
"echo_key()\n"
"Checks for Windows keystroke events and dispatches messages; similar to getkey(), but also sends\n"
"keystroke to tracker.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"0 if no key pressed, else key code TERMINATE_KEY if CTRL-C held down or program has been\n"
"terminated.\n"
"Remarks\n"
"Warning: Under Windows XP, this call will not work in realtime mode at all, and will take several\n"
"seconds to respond if graphics are being drawn continuously. This function works well in realtime\n"
"mode under Windows 2000.\n"
"This function is equivalent to the C API unsigned echo_key(void);\n";


static char escapePressed_doc[]=
"escapePressed()\n"
"This function tests if the ESC key is held down, and is usually used to break out of nested loops.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"1 if ESC key held down 0 if not\n"
"Remarks\n"
"Under Windows XP, this call will not work in realtime mode at all, and will take several seconds t\n"
"o respond if graphics are being drawn continuously. This function works well in realtime mode under\n"
"Windows 2000.\n"
"This function is equivalent to the C API INT16 escape_pressed(void);\n";


static char exitCalibration_doc[]=
"exitCalibration()\n"
"This function should be called from a message or event handler if an ongoing call to doDriftCorrect() or\n"
"doTrackerSetup() should return immediately.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"None.\n"
"This function is equivalent to the C API void exit_calibration(void);\n";

static char eyeAvailable_doc[]=
"eyeAvailable()\n"
"After calling the waitForBlockStart() method, or after at least one sample or eye event has been read, this\n"
"function can be used to check which eyes data is available for.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"LEFT_EYE (0) if left eye data\n"
"RIGHT_EYE (1) if right eye data\n"
"BINOCULAR (2) if both left and right eye data\n"
"-1 if no eye data is available\n"
"This is equivalent to the C API INT16 eyelink_eye_available(void);\n";

static char flushKeybuttons_doc[]=
"flushKeyButtons(enable_buttons)\n"
"Causes the EyeLink tracker and the EyeLink library to flush any stored button or key events. This should be\n"
"used before a trial to get rid of old button responses. The <enable_buttons> argument controls whether\n"
"the EyeLink library will store button press and release events. It always stores tracker key events. Even if\n"
"disabled, the last button pressed and button flag bits are updated.\n"
"Parameters\n"
"Sets to 0 to monitor last button press only, 1 to queue button events.\n"
"Return Value\n"
"Always 0\n"
"This is equivalent to the C API INT16 eyelink_flush_keybuttons(INT16 enable_buttons);\n";


static char getButtonStates_doc[]=
"getButtonStates()\n"
"Returns a flag word with bits set to indicate which tracker buttons are currently pressed. This is button 1\n"
"for the LSB, up to button 16 for the MSB. Note: Buttons above 8 are not realized on the EyeLink tracker.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"Flag bits for buttons currently pressed.\n"
"This function is equivalent to the C API UINT16 eyelink_button_states(void);\n";

static char getCalibrationMessage_doc[]=
"getCalibrationMessage()\n"
"Returns text associated with result of last calibration, validation, or drift correction. This usually specifies\n"
"errors or other statistics.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"Message string associated with result of last calibration, validation, or drift correction.\n"
"This function is equivalent to the C API INT16 eyelink_cal_message(char *msg);\n";


static char getCalibrationResult_doc[]=
"getCalibrationResult()\n"
"Checks for a numeric result code returned by calibration, validation, or drift correction.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"NO_REPLY if drift correction not completed yet\n"
"OK_RESULT (0) if success\n"
"ABORT_REPLY (27) if �Esc� key aborted operation\n"
"-1 if operation failed\n"
"1 if poor calibration or excessive validation error.\n"
"This function is equivalent to the C API INT16 eyelink_cal_result(void);\n";

static char getCurrentMode_doc[]=
"getCurrentMode()\n"
"This function tests the current tracker mode, and returns a set of flags based of what the mode is doing.\n"
"The most useful flag using the EyeLink experiment toolkit is IN_USER_MENU to test if the EyeLink Abort\n"
"menu has been activated.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"Set of bit flags that mark mode function:\n"
"IN_DISCONNECT_MODE if disconnected\n"
"IN_IDLE_MODE if off-line (Idle mode)\n"
"IN_SETUP_MODE if in Setup-menu related mode\n"
"IN_RECORD_MODE if tracking is in progress\n"
"IN_PLAYBACK_MODE if currently playing back data\n"
"IN_TARGET_MODE if in mode that requires a fixation target\n"
"IN_DRIFTCORR_MODE if in drift-correction\n"
"IN_IMAGE_MODE if displaying grayscale camera image\n"
"IN_USER_MENU if displaying Abort or user-defined menu\n"
"This is equivalent to the C API INT16 eyelink_current_mode(void);\n";


static char getDataCount_doc[]=
"getDataCount(samples, events)\n"
"Counts total items in queue: samples, events, or both.\n"
"Parameters\n"
"<samples>: if non-zero count the samples.\n"
"<events>: if non-zero count the events..\n"
"Return Value\n"
"Total number of samples and events is in the queue.\n"
"This function is equivalent to the C API INT16 eyelink_data_count(INT16 samples, INT16 events);\n";



static char getEventDataFlags_doc[]=
"getEventDataFlags()\n"
"Returns the event data content flags.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"Possible return values are a set of the following bit flags:\n"
"+-------------------------------------------------------------+\n"
"|Constant Name   |Value  |Description                         |\n"
"+-------------------------------------------------------------+\n"
"|EVENT_VELOCITY  |0x8000 |Has velocity data                   |\n"
"|EVENT_PUPILSIZE |0x4000 |Has pupil size data                 |\n"
"|EVENT_GAZERES   |0x2000 |Has gaze resolution                 |\n"
"|EVENT_STATUS    |0x1000 |Has status flags                    |\n"
"|EVENT_GAZEXY    |0x0400 |Has gaze x, y position              |\n"
"|EVENT_HREFXY    |0x0200 |Has head-ref x, y position          |\n"
"|EVENT_PUPILXY   |0x0100 |Has pupil x, y position             |\n"
"|FIX_AVG_ONLY    |0x0008 |Only average data to fixation events|\n"
"|START_TIME_ONLY |0x0004 |Only start-time in start events     |\n"
"|PARSEDBY_GAZE   |0x00C0 |Events were generated by GAZE data  |\n"
"|PARSEDBY_HREF   |0x0080 |Events were generated by HREF data  |\n"
"|PARSEDBY_PUPIL  |0x0040 |Events were generated by PUPIL data |\n"
"+-------------------------------------------------------------+\n"
"\n"
"This is equivalent to the C API UINT16 eyelink_event_data_flags(void);\n";




static char getEventTypeFlags_doc[]=
"getEventTypeFlags()\n"
"After at least one button or eye event has been read, can be used to check what type of events will be\n"
"available.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"Possible return values are a set of the following bit flags:\n"
"Constant Name Value Description\n"
"LEFTEYE_EVENTS 0x8000 Has left eye events\n"
"RIGHTEYE_EVENTS 0x4000 Has right eye events\n"
"BLINK_EVENTS 0x2000 Has blink events\n"
"FIXATION_EVENTS 0x1000 Has fixation events\n"
"FIXUPDATE_EVENTS 0x0800 Has fixation updates\n"
"SACCADE_EVENTS 0x0400 Has saccade events\n"
"MESSAGE_EVENTS 0x0200 Has message events\n"
"BUTTON_EVENTS 0x0040 Has button events\n"
"INPUT_EVENTS 0x0020 Has input port events\n"
"This is equivalent to the C API UINT16 eyelink_event_type_flags(void);\n";

static char getFloatData_doc[]=
"getFloatData()\n"
"Reads data of a specific type returned by getNextData. If this function called multiple times without calling\n"
"getNextData(), the same data is returned.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"None if no data available. Otherwise, a valid data is returned. The returned data type can be:\n"
"1. Sample\n"
"2. StartBlinkEvent\n"
"3. EndBlinkEvent\n"
"4. StartSacadeEvent\n"
"5. EndSacadeEvent\n"
"6. StartFixationEvent\n"
"7. EndFixationEvent\n"
"8. FixUpdateEvent\n"
"9. IOEvent\n"
"10. MessageEvent\n"
"This function is equivalent to the C API INT16 eyelink_get_next_data(void *buf);\n";

static char getkeyEx_doc[] =
"getKeyEx()\n"
"Returns the key pressed.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"None if no key pressed, else key code. TERMINATE_KEY if CTRL-C held down or program has been\n"
"terminated.\n"
"Remarks\n"
"Warning: This function processes and dispatches any waiting messages. This will allow Windows to\n"
"perform disk access and negates the purpose of realtime mode. Usually these delays will be only a few\n"
"milliseconds, but delays over 20 milliseconds have been observed. You may wish to call\n"
"escapePressed() or breakPressed() in recording loops instead of getkey() if timing is critical, for\n"
"example in a gaze-contingent display. Under Windows XP, these calls will not work in realtime mode at\n"
"all (although these do work under Windows 2000). Under Windows 95/98/Me, realtime performance is\n"
"impossible even with this strategy.\n"
"Some useful keys are:\n"
"CURS_UP\n"
"CURS_DOWN\n"
"CURS_LEFT\n"
"CURS_RIGHT\n"
"ESC_KEY\n"
"ENTER_KEY\n"
"TERMINATE_KEY\n"
"JUNK_KEY\n"
"This function is equivalent to the C API unsigned getkey(void);\n";


static char getkey_doc[]=
"getKey()\n"
"Returns the key pressed.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"0 if no key pressed, else key code. TERMINATE_KEY if CTRL-C held down or program has been\n"
"terminated.\n"
"Remarks\n"
"Warning: This function processes and dispatches any waiting messages. This will allow Windows to\n"
"perform disk access and negates the purpose of realtime mode. Usually these delays will be only a few\n"
"milliseconds, but delays over 20 milliseconds have been observed. You may wish to call\n"
"escapePressed() or breakPressed() in recording loops instead of getkey() if timing is critical, for\n"
"example in a gaze-contingent display. Under Windows XP, these calls will not work in realtime mode at\n"
"all (although these do work under Windows 2000). Under Windows 95/98/Me, realtime performance is\n"
"impossible even with this strategy.\n"
"Some useful keys are:\n"
"CURS_UP\n"
"CURS_DOWN\n"
"CURS_LEFT\n"
"CURS_RIGHT\n"
"ESC_KEY\n"
"ENTER_KEY\n"
"TERMINATE_KEY\n"
"JUNK_KEY\n"
"This function is equivalent to the C API unsigned getkey(void);\n";

static char getLastButtonPress_doc[]=
"getLastButtonPress()\n"
"Reads the number of the last button detected by the EyeLink tracker. This is 0 if no buttons were pressed\n"
"since the last call, or since the buttons were flushed. If a pointer to a variable is supplied the eye-tracker\n"
"timestamp of the button may be read. This could be used to see if a new button has been pressed since the\n"
"last read. If multiple buttons were pressed since the last call, only the last button is reported.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"Two-item tuple, recording the button last pressed (0 if no button pressed since last read) and the time\n"
"of the button press.\n"
"This function is equivalent to the C API UINT16 eyelink_last_button_press(UINT32 *time);\n";

static char getLastData_doc[]=
"getLastData()\n"
"Gets an integer (unconverted) copy of the last/newest link data (sample or event) seen by\n"
"getNextData().\n"
"Parameters\n"
"None\n"
"Return Value\n"
"Object of type Sample or Event.\n"
"This function is equivalent to the C API INT16 eyelink_get_last_data(void *buf);\n";

static char getLastMessage_doc[]=
"getLastMessage()\n"
"Returns text associated with last command response: may have error message.\n"
"Parameters:\n"
"None.\n"
"Return Value:\n"
"Text associated with last command response or None.\n"
"This is equivalent to the C API INT16 eyelink_last_message(char *buf);\n";

static char getModeData_doc[]=
"getModeData()\n"
"After calling waitForBlockStart(), or after at least one sample or eye event has been read, returns EyeLink\n"
"II extended mode data.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"A five-item tuple holding (in the following order):\n"
"� eye information (LEFT_EYE if left eye data, RIGHT_EYE if right eye data, BINOCULAR if both left\n"
"and right eye data, -1 if no eye data is available),\n"
"� sampling rate (samples per second),\n"
"� CR mode flag (0 if pupil-only mode, else pupil-CR mode),\n"
"� filter level applied to file samples (0=off, 1=std, 2=extra),\n"
"� filter level applied to link and analog output samples (0=off, 1=std, 2=extra).\n"
"This function is equivalent to the C API INT16 eyelink2_mode_data(INT16 *sample_rate, INT16\n"
"*crmode, INT16 *file_filter, INT16 *link_filter);\n";

static char getNewestSample_doc[]=
"getNewestSample()\n"
"Check if a new sample has arrived from the link. This is the latest sample, not the oldest sample that is\n"
"read by getNextData(), and is intended to drive gaze cursors and gaze-contingent displays.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"None if there is no sample, instance of Sample type otherwise.\n"
"This function is equivalent to the C API INT16 CALLTYPE eyelink_newest_sample(void FARTYPE\n"
"*buf);\n";


static char getNextData_doc[]=
"getNextData()\n"
"Fetches next data item from link buffer.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"0 if no data, SAMPLE_TYPE (200) if sample, else event type. Possible return values are,\n"
"+-----------------------------------------------------------------------+\n"
"|Constant Name |Value |Description                                      |\n"
"+-----------------------------------------------------------------------+\n"
"|STARTBLINK    |3     |Pupil disappeared, time only                     |\n"
"|ENDBLINK      |4     |Pupil reappeared (duration data)                 |\n"
"|STARTSACC     |5     |Start of saccade (with time only)                |\n"
"|ENDSACC       |6     |End of saccade (with summary data)               |\n"
"|STARTFIX      |7     |Start of fixation (with time only)               |\n"
"|ENDFIX        |8     |End of fixation (with summary data)              |\n"
"|FIXUPDATE     |9     |Update within fixation, summary data for interval|\n"
"|MESSAGEEVENT  |24    |User-definable text (IMESSAGE structure)         |\n"
"|BUTTONEVENT   |25    |Button state change (IOEVENT structure)          |\n"
"|INPUTEVENT    |28    |Change of input port (IOEVENT structure)         |\n"
"|SAMPLE_TYPE   |200   |Event flags gap in data stream                   |\n"
"+-----------------------------------------------------------------------+\n"
"This function is equivalent to the C API INT16 eyelink_get_next_data(void *buf);\n";


static char getNode_doc[]=
"getNode(response)\n"
"Reads the responses returned by other trackers or remotes in response to pollTrackers() or pollRemotes().\n"
"It can also read the tracker broadcast address and remote broadcast addresses.\n"
"Parameters\n"
"<resp>\n"
"Nmber of responses to read: 0 gets our data, 1 get first response, 2 gets the second response, etc. -1\n"
"to read the tracker broadcast address. -2 to read remote broadcast addresses.\n"
"Return Value\n"
"If successful, an instance of EyelinkMessage class returned.\n"
"This function is equivalent to the C API INT16 eyelink_get_node(INT16 resp, void *data);\n";


static char getPositionScalar_doc[]=
"getPositionScalar()\n"
"Returns the divisor used to convert integer eye data to floating point data.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"Integer for the divisor (usually 10)\n"
"This function is equivalent to the C API INT16 eyelink_position_prescaler(void);\n";

static char getRecordingStatus_doc[]=
"getRecordingStatus()\n"
"Checks if we are in Abort menu after recording stopped and returns trial exit code. Call this function on\n"
"leaving a trial. It checks if the EyeLink tracker is displaying the Abort menu, and handles it if required. The\n"
"return value from this function should be returned as the trial result code.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"TRIAL_OK if no error\n"
"REPEAT_TRIAL, SKIP_TRIAL, ABORT_EXPT if Abort menu activated.\n"
"This function is equivalent to the C API INT16 check_record_exit(void);\n";


static char getSample_doc[]=
"getSample()\n"
"Gets an integer (unconverted) sample from end of queue, discards any events encountered.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"Object of type Sample\n"
"This is equivalent to the C API INT16 eyelink_get_sample(void *sample);\n";

static char getSampleDataFlags_doc[]=
"getSampleDataFlag()\n"
"After calling waitForBlockStart(), or after at least one sample or eye event has been read, returns sample\n"
"data content flag (0 if not in sample block).\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"Possible return values are a set of the following bit flags:\n"
"+-----------------------------------------------------------------------+\n"
"|Constant Name    |Value  |Description                                  |\n"
"+-----------------------------------------------------------------------+\n"
"|SAMPLE_LEFT      |0x8000 |Data for left eye                            |\n"
"|SAMPLE_RIGHT     |0x4000 |Data for right eye                           |\n"
"|SAMPLE_TIMESTAMP |0x2000 |always for link, used to compress files      |\n"
"|SAMPLE_PUPILXY   |0x1000 |pupil x,y pair                               |\n"
"|SAMPLE_HREFXY    |0x0800 |head-referenced x,y pair                     |\n"
"|SAMPLE_GAZEXY    |0x0400 |gaze x,y pair                                |\n"
"|SAMPLE_GAZERES   |0x0200 |gaze res (x,y pixels per degree) pair        |\n"
"|SAMPLE_PUPILSIZE |0x0100 |pupil size                                   |\n"
"|SAMPLE_STATUS    |0x0080 |error flags                                  |\n"
"|SAMPLE_INPUTS    |0x0040 |input data port                              |\n"
"|SAMPLE_BUTTONS   |0x0020 |button state: LSBy state, MSBy changes       |\n"
"|SAMPLE_HEADPOS   |0x0010 |head-position: byte tells # words            |\n"
"|SAMPLE_TAGGED    |0x0008 |reserved variable-length tagged              |\n"
"|SAMPLE_UTAGGED   |0x0004 |user-defineabe variable-length tagged        |\n"
"+-----------------------------------------------------------------------+\n"
"This function is equivalent to the C API INT16 eyelink_sample_data_flags(void);\n";

static char getTargetPositionAndState_doc[]=
"getTargetPositionAndState()\n"
"Returns the current target position and state.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"A three-item tuple holding (in the following order):\n"
"� the target visibility (0 if visible),\n"
"� x position of the target,\n"
"� and y position of the target.\n"
"This function is equivalent to the C API INT16 eyelink_target_check(INT16 *x, INT16 *y);\n";

static char getTrackerInfo_doc[]=
"getTrackerInfo()\n"
"Returns the current tracker information.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"An instance of the ILinkData class (see section 3.12).\n";

static char getTrackerMode_doc[]=
"getTrackerMode()\n"
"Returns raw EyeLink mode numbers.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"Raw EyeLink mode, -1 if link disconnected.\n"
"+-------------------------------------------+\n"
"|Constant Name         |Value               |\n"
"+-------------------------------------------+\n"
"|EL_IDLE_MODE          |1                   |\n"
"|EL_IMAGE_MODE         |2                   |\n"
"|EL_SETUP_MENU_MODE    |3                   |\n"
"|EL_USER_MENU_1        |5                   |\n"
"|EL_USER_MENU_2        |6                   |\n"
"|EL_USER_MENU_3        |7                   |\n"
"|EL_OPTIONS_MENU_MODE  |8                   |\n"
"|EL_OUTPUT_MENU_MODE   |9                   |\n"
"|EL_DEMO_MENU_MODE     |10                  |\n"
"|EL_CALIBRATE_MODE     |11                  |\n"
"|EL_VALIDATE_MODE      |12                  |\n"
"|EL_DRIFT_CORR_MODE    |13                  |\n"
"|EL_RECORD_MODE        |14                  |\n"
"|USER_MENU_NUMBER(mode)|((mode)-4)          |\n"
"+-------------------------------------------+\n"
"This function is equivalent to the C API INT16 eyelink_tracker_mode(void);\n";

static char getTrackerVersion_doc[]=
"getTrackerVersion()\n"
"After connection, determines if the connected tracker is an EyeLink I or II. Use getTrackerVersionString to get the string\n"
"value.\n"
"Parameters:\n"
"None\n"
"Return Values:\n"
"The returned value is a number (0 if not connected, 1 for EyeLink I, 2 for EyeLink II).\n"
"This is equivalent to the C API INT16 eyelink_get_tracker_version(char *c);\n";

static char getTrackerVersionString_doc[]=
"getTrackerVersionString()\n"
"After connection, determines if the connected tracker is an EyeLink I or II (use getTrackerVersion) to get\n"
"number value.\n"
"Parameters:\n"
"None\n"
"Return Value:\n"
"A string indicating EyeLink tracker version.\n"
"This is equivalent to the C API INT16 eyelink_get_tracker_version(char *c);\n";


static char inSetup_doc[]=
"inSetup()\n"
"Checks if tracker is still in a Setup menu activity (includes camera image view, calibration, and validation).\n"
"Used to terminate the subject setup loop.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"0 if no longer in setup mode.\n"
"This function is equivalent to the C API INT16 eyelink_in_setup(void);\n";

static char isConnected_doc[]=
"isConnected()\n"
"Checks whether the connection to the tracker is alive.\n"
"Parameters:\n"
"None\n"
"Return Values:\n"
"Returns 0 if link closed, -1 if simulating connection, 1 for normal connection, 2 for broadcast connection.\n"
"This is equivalent to the C API INT16 eyelink_is_connected(void);\n";

static char isInDataBlock_doc[]=
"isInDataBlock(samples, events)\n"
"Checks to see if framing events read from queue indicate that the data is in a block containing samples,\n"
"events, or both.\n"
"Parameters\n"
"<samples>: if non-zero, check if in a block with samples.\n"
"<events>: if non-zero, check if in a block with events.\n"
"Return Value\n"
"0 if no data of either masked type is being sent.\n"
"Remarks\n"
"The first item in queue may not be a block start even, so this should be used in a loop while discarding\n"
"items using eyelink_get_next_data(NULL). NOTE: this function did not work reliably in versions of the\n"
"DLL before v2.0 (did not detect end of blocks).\n"
"This function is equivalent to the C API INT16 eyelink_in_data_block(INT16 samples, INT16 events);\n";

static char isRecording_doc[]=
"isRecording()\n"
"Check if we are recording: if not, report an error. Call this function while recording. It will return true if\n"
"recording is still in progress, otherwise it will throw an exception. It will also handle the EyeLink Abort\n"
"menu. Any errors returned by this function should be returned by the trial function. On error, this will\n"
"disable realtime mode and restore the heuristic.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"TRIAL_OK (0) if no error\n"
"REPEAT_TRIAL, SKIP_TRIAL, ABORT_EXPT, TRIAL_ERROR if recording aborted.\n"
"This function is equivalent to the C API int check_recording(void);\n";

static char nodeReceive_doc[]=
"nodeReceive()\n"
"Checks for and gets the last packet received, stores the data and the node address sent from. Note: Data\n"
"can only be read once, and is overwritten if a new packet arrives before the last packet has been read.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"An instance of EyelinkMessage class is returned, if successful.\n"
"This function is equivalent to the C API INT16 eyelink_node_receive(ELINKADDR node, void *data);\n";

static char nodeRequestTime_doc[]=
"nodeRequestTime(address)\n"
"Sends a request the connected eye tracker to return its current time. Note: The time reply can be read\n"
"with getTrackerTime().\n"
"Parameters\n"
"<address>: text IP address (for example, �100.1.1.1�) for a specific tracker.\n"
"Return Value\n"
"0 if no error, else link error code\n"
"This function is equivalent to the C API UINT32 eyelink_node_request_time(ELINKADDR node);\n";

static char nodeSend_doc[]=
"nodeSend(address, data, length)\n"
"Sends a given data to the given node.\n"
"Parameters\n"
"<addr>: the address of the node;\n"
"<data>: Pointer to buffer containing data to send;\n"
"<length>: Number of bytes of data\n"
"Return Value\n"
"0 if successful, otherwise link error.\n"
"This function is equivalent to the C API INT16 eyelink_node_send(ELINKADDR node, void *data,\n"
"UINT16 dsize);\n";


static char nodeSendMessage_doc[]=
"nodeSendMessage(address, message)\n"
"Sends a text message the connected eye tracker. The text will be added to the EDF file. Note: If the link\n"
"is initialized but not connected to a tracker, the message will be sent to the tracker set by setAddress() of\n"
"the pylink module.\n"
"Parameters\n"
"<address>: Address of a specific tracker.\n"
"<message>: Text to send to the tracker.\n"
"Return Value\n"
"0 if no error, else link error code\n"
"This function is equivalent to the C API INT16 eyelink_node_send_message(ELINKADDR node, char\n"
"*msg);\n";





static char open_doc[]=
"open(eyelink_address = �100.1.1.1�, busytest=0)\n"
"Opens connection to single tracker. If no parameters are given, it tries to open connection to the default\n"
"host (100.1.1.1).\n"
"Parameters\n"
"<eyelink_address>: text IP address of the host PC (the default value is, �100.1.1.1�);\n"
"<busytest>: if non-zero the call to eyelink_open_node will not disconnect an existing connection.\n"
"Return Value\n"
"Returns None. Throws Runtime error exception if it cannot open the connection.\n"
"This is equivalent to the C API INT16 eyelink_open_node(ELINKADDR node, INT16 busytest);\n";



static char openDataFile_doc[]=
"openDataFile(name)\n"
"Opens a new EDF file on the EyeLink tracker computer�s hard disk. By calling this function will close any\n"
"currently opened file. This may take several seconds to complete. The file name should be formatted for\n"
"MS-DOS, usually 8 or less characters with only 0-9, A-Z, and �_� allowed.\n"
"Parameters\n"
"<name>: Name of eye tracker file, 8 characters or less.\n"
"Return Value\n"
"0 if file was opened successfully else error code.\n"
"This function is equivalent to the C API int open_data_file(char *name);\n";



static char openNode_doc[]=
"openNode(eyelink_address , busytest)\n"
"Allows the computer to connect to tracker, where the tracker is on the same network.\n"
"Parameters:\n"
"<eyelink_address>: text IP address of the host PC (the default value is, �100.1.1.1�);\n"
"<busytest>: if non-zero the call to openNode will not disconnect an existing connection.\n"
"Return Values:\n"
"None. Throws Runtime Exception if it connects to the remote host.\n"
"This is equivalent to the C API INT16 eyelink_open_node(ELINKADDR node, INT16 busytest); with\n"
"node parameter converted from text to ELINKADDR.\n";



static char pollRemotes_doc[]=
"pollRemotes()\n"
"Asks all non-tracker computers (with EyeLink software running) on the network to send their names and\n"
"node address.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"0 if successful, otherwise link error.\n"
"This function is equivalent to the C API INT16 eyelink_poll_ remotes(void);\n";



static char pollResponses_doc[]=
"pollResponses()\n"
"Returns the count of node addresses received so far following the call of pollRemotes() or pollTrackers().\n"
"Note: You should allow about 100 milliseconds for all nodes to respond. Up to 4 node responses are saved.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"Number of nodes responded. 0 if no responses.\n"
"This function is equivalent to the C API INT16 eyelink_poll_responses(void);\n";



static char pollTrackers_doc[]=
"pollTrackers()\n"
"Asks all trackers (with EyeLink software running) on the network to send their names and node address.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"0 if successful, otherwise link error.\n"
"This function is equivalent to the C API INT16 eyelink_poll_trackers(void);\n";



static char pumpMessages_doc[]=
"pumpMessages()\n"
"Forces the graphical environment to process any pending key or mouse events.\n"
"Parameter:\n"
"None\n"
"Return Value:\n"
"None\n"
"This function is equivalent to the C API INT16 message_pump(HWND dialog_hook).\n";



static char quietMode_doc[]=
"quietMode(mode)\n"
"Controls the level of control an application has over the tracker.\n"
"Parameters\n"
"<mode>: 0 to allow all communication; 1 to block commands (allows only key presses, messages, and\n"
"time or variable read requests); 2 to disable all commands, requests and messages; -1 to just return\n"
"current setting\n"
"Return Value\n"
"Returns the previous mode settings.\n"
"This function is equivalent to the C API INT16 eyelink_quiet_mode(INT16 mode);\n";



static char readKeyButton_doc[]=
"readKeyButton()\n"
"Reads any queued key or button events from tracker.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"A five-item tuple, recording (in the following order):\n"
"� Key character if key press/release/repeat, KB_BUTTON (0xFF00) if button press or release,\n"
"� Button number or key modifier (Shift, Alt and Ctrl key states),\n"
"� Key or button change (KB_PRESS, KB_RELEASE, or KB_REPEAT),\n"
"� Key scan code,\n"
"� Tracker time of the key or button change.\n"
"This function is equivalent to the C API UINT16 eyelink_read_keybutton(INT16 *mods,INT16 *state,\n"
"UINT16 *kcode, UINT32 *time);\n";



static char readKeyQueue_doc[]=
"readKeyQueue()\n"
"Read keys from the key queue. It is similar to getkey(), but does not process Windows messages. This can\n"
"be used to build key-message handlers in languages other than C.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"0 if no key pressed\n"
"JUNK_KEY (1) if untranslatable key\n"
"TERMINATE_KEY (0x7FFF) if CTRL-C is pressed, terminal_break() was called, or the program has been\n"
"terminated with ALT-F4.\n"
"or code of key if any key pressed.\n"
"This function is equivalent to the C API UINT16 read_getkey_queue(void);\n";



static char readReply_doc[]=
"readReply()\n"
"Returns text with reply to last read request.\n"
"Parameters:\n"
"None.\n"
"Return Value:\n"
"String to contain text or None.\n"
"This is equivalent to the C API INT16 eyelink_read_reply(char *buf);\n";


static char readRequest_doc[]=
"readRequest(text)\n"
"Sends a text variable name whose value is read and returned by the tracker as a text string.\n"
"Parameters:\n"
"<text>: String with message to send.\n"
"Return Value:\n"
"0 if success, otherwise link error code.\n"
"Remarks\n"
"If the link is initialized but not connected to a tracker, the message will be sent to the tracker set by\n"
"setAddress(). However, these requests will be ignored by tracker versions older than EyeLink I v2.1\n"
"and EyeLink II v1.1.\n"
"This is equivalent to the C API INT16 eyelink_read_request(char *text);\n";



static char receiveDataFile_doc[]=
"receiveDataFile(src, dest)\n"
"This receives a data file from the EyeLink tracker PC. Source file name and destination file name should be\n"
"given.\n"
"Parameters\n"
"<Src>: Name of eye tracker file (including extension).\n"
"<Dest>: Name of local file to write to (including extension).\n"
"Return Value\n"
"Size of file if successful,\n"
"Otherwise Runtime Exception is raised.\n"
"This function is equivalent to the C API int receive_data_file(char *src, char *dest, int is_path);\n";


static char reset_doc[]=
"reset()\n"
"Resets the link data system if it is listening in on a broadcast data session. This does not shut down the\n"
"link, which remains available for other operations.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"0 if successful, otherwise linkerror.\n"
"This function is equivalent to the C API INT16 eyelink_close(int send_msg); with send_msg parameter 0.\n";



static char resetData_doc[]=
"resetData()\n"
"Prepares link buffers to receive new data.\n"
"Parameters\n"
"<clear>: If nonzero, removes old data from buffer.\n"
"Return Value\n"
"Always 0.\n"
"This function is equivalent to the C API INT16 eyelink_reset_data(INT16 clear);\n";



static char sendCommand_doc[]=
"sendCommand(command_text)\n"
"Sends the given command to connected eyelink tracker and returns the command result.\n"
"Parameters:\n"
"<command_text>: text command to be sent. It does not support printf() kind of formatting.\n"
"Return Values:\n"
"Command result. If there is any problem sending the command, a runtime exception is raised.\n"
"This is equivalent to the C API int eyecmd_printf(char *fmt, ...); without any formatting.\n";



static char sendKeybutton_doc[]=
"sendKeybutton(code, mods, state)\n"
"Sends a key or button event to tracker. Only key events are handled for remote control.\n"
"Parameters\n"
"<code>: key character, or KB_BUTTON (0xFF00) if sending button event\n"
"<mods>: button number, or key modifier (Shift, Alt and Ctrl key states).\n"
"<state>: key or button change (KB_PRESS or KB_RELEASE)\n"
"Return Value\n"
"0 if ok, else send link error.\n"
"This function is equivalent to the C API INT16 eyelink_send_keybutton(UINT16 code, UINT16 mods,\n"
"INT16 state);\n";



static char sendMessage_doc[]=
"sendMessage(message_text)\n"
"Sends the given message to the connected eyelink tracker. The message will be written to the eyelink\n"
"tracker.\n"
"Parameters:\n"
"<message_text>: text message to be sent. It does not support printf() kind of formatting.\n"
"Return Values:\n"
"If there is any problem sending the message, a runtime exception is raised.\n"
"This is equivalent to the C API int eyecmd_printf(char *fmt, ...);\n";



static char setAddress_doc[]=
"setAddress(text_IP_address)\n"
"Sets the IP address used for connection to the EyeLink tracker. This is set to �100.1.1.1� in the DLL, but\n"
"may need to be changed for some network configurations. This must be set before attempting to open a\n"
"connection to the tracker.\n"
"A\n"
"�broadcast� address (�255.255.255.255�) may be used if the tracker address is not known�this will work\n"
"only if a single Ethernet card is installed, or if DLL version 2.1 or higher, and the latest tracker software\n"
"versions (EyeLink I v2.1 or higher, and EyeLink II v1.1 or higher) are installed.\n"
"Parameters:\n"
"<text_IP_address>: Pointer to a string containing a �dotted� 4-digit IP address;\n"
"Return Value:\n"
"0 if success, -1 if could not parse address string\n"
"This is equivalent to the C API INT16 set_eyelink_address(char *addr);\n";



static char setName_doc[]=
"SetName(name)\n"
"Sets the node name of this computer (up to 35 characters).\n"
"Parameters\n"
"<name>: String to become new name.\n"
"Return Value\n"
"None.\n"
"This function is equivalent to the C API INT16 eyelink_set_name(char *name);\n";



static char setOfflineMode_doc[]=
"setOfflineMode()\n"
"Places EyeLink tracker in off-line (idle) mode. Wait till the tracker has finished the mode transition.\n"
"Parameters:\n"
"None\n"
"Return Values:\n"
"None\n"
"This is equivalent to the C API INT16 set_offline_mode(void);\n";



static char startData_doc[]=
"startData(flags, lock)\n"
"Switches tracker to Record mode, enables data types for recording to EDF file or sending to link. These\n"
"types are set with a bit wise OR of these flags:\n"
"+-----------------------------------------------------------------------+\n"
"|Constant Name       |Value |Description                                |\n"
"+-----------------------------------------------------------------------+\n"
"|RECORD_FILE_SAMPLES |1     |Enables sample recording to EDF file       |\n"
"|RECORD_FILE_EVENTS  |2     |Enables event recording to EDF file        |\n"
"|RECORD_LINK_SAMPLES |4     |Enables sending samples to the link        |\n"
"|RECORD_LINK_EVENTS  |8     |Enables sending events to the link         |\n"
"+-----------------------------------------------------------------------+\n"
"Parameters\n"
"<flags>: Bitwise OR of flags to control what data is recorded. If 0, recording will be stopped.\n"
"<lock>: If nonzero, prevents �Esc� key from ending recording.\n"
"Return Value\n"
"0 if command sent ok, else link error.\n"
"Remarks\n"
"If <lock> is nonzero, the recording may only be terminated through stopRecording() or stopData()\n"
"method of the EyeLinkListener class, or by the Abort menu (�Ctrl��Alt��A� keys on the eye tracker). If\n"
"zero, the tracker �Esc� key may be used to halt recording.\n"
"This function is equivalent to the C API INT16 eyelink_data_start(UINT16 flags, INT16 lock);\n";


static char startDriftCorrect_doc[]=
"startDriftCorrect(x, y)\n"
"Sets the position of the drift correction target, and switches the tracker to drift-correction mode. Should be\n"
"followed by a call to waitForModeReady() method.\n"
"Parameters\n"
"<x>: x position of the target.\n"
"<y>: y position of the target.\n"
"Return Value\n"
"0 if command sent ok, else link error.\n"
"This function is equivalent to the C API INT16 eyelink_driftcorr_start(INT16 x, INT16 y);\n";

static char startPlayBack_doc[]=
"startPlayBack()\n"
"Flushes data from queue and starts data playback. An EDF file must be open and have at least one\n"
"recorded trial. Use waitForData() method to wait for data: this will time out if the playback failed. Playback\n"
"begins from start of file or from just after the end of the next-but-last recording block. Link data is\n"
"determined by file contents, not by link sample and event settings.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"0 if command sent ok, else link error.\n"
"This function is equivalent to the C API INT16 eyelink_playback_start(void);\n";



static char startRecording_doc[]=
"startRecording(File_samples, File_events, Link_samples, Link_events)\n"
"Starts the EyeLink tracker recording, sets up link for data reception if enabled.\n"
"Parameters:\n"
"<File_samples>: If 1, writes samples to EDF file. If 0, disables sample recording\n"
".<File_events>: If 1, writes events to EDF file. If 0, disables event recording.\n"
"<Link_samples>: If 1, sends samples through link. If 0, disables link sample access.\n"
"<Link_events>: If 1, sends events through link. If 0, disables link event access.\n"
"Return Values:\n"
"0 if successful, else trial return code\n"
"This is equivalent to the C API INT16 start_recording(INT16 file_samples, INT16 file_events, INT16\n"
"link_samples, INT16 link_events);\n"
"Note:\n"
"Recording may take 10 to 30 milliseconds to begin from this command. The function also waits until at\n"
"least one of all requested link data types have been received. If the return value is not zero, return the\n"
"result as the trial result code.\n";



static char startSetup_doc[]=
"startSetup()\n"
"Switches the EyeLink tracker to the setup menu, for calibration, validation, and camera setup. Should be\n"
"followed by a call to waitForModeReady().\n"
"Parameters:\n"
"None\n"
"Return Value:\n"
"0 if command send OK.\n"
"This is equivalent to the C API INT16 eyelink_start_setup(void);\n";


static char stopData_doc[]=
"StopData()\n"
"Places tracker in idle (off-line) mode, does not flush data from queue.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"0 if command sent ok, else link error.\n"
"Remark:\n"
"Should be followed by a call to waitForModeReady() method.\n"
"This function is equivalent to the C API INT16 eyelink_data_stop(void);\n";


static char stopPlayBack_doc[]=
"StopPlayBack()\n"
"Stops playback if in progress. Flushes any data in queue.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"None.\n"
"This function is equivalent to the C API INT16 eyelink_playback_stop(void);\n";



static char stopRecording_doc[]=
"stopRecording()\n"
"Stops recording, resets EyeLink data mode. Call 50 to 100 msec after an event occurs that ends the trial.\n"
"This function waits for mode switch before returning.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"None\n"
"This is equivalent to the C API void stop_recording(void);\n";



static char terminalBreak_doc[]=
"terminalBreak(assert)\n"
"This function can be called in an event handler to signal that the program is terminating. Calling this\n"
"function with an argument of 1 will cause breakPressed() to return 1, and getkey() to return\n"
"TERMINATE_KEY. These functions can be re-enabled by calling terminalBreak() with an argument of 0.\n"
"Parameters\n"
"<Assert>: 1 to signal a program break, 0 to reset break.\n"
"Return Value\n"
"None.\n"
"This function is equivalent to the C API void terminal_break(INT16 assert);\n";



static char trackerTime_doc[]=
"trackerTime()\n"
"Returns the current tracker time (in milliseconds) since the tracker application started.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"An integer data for the current tracker time (in milliseconds) since tracker initialization.\n"
"This is equivalent to the C API UINT32 eyelink_tracker_time();\n";



static char trackerTimeOffset_doc[]=
"trackerTimeOffset()\n"
"Returns the time difference between the tracker time and display pc time.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"An integer data for the time difference (in milliseconds) between the tracker time and display pc time.\n"
"This is equivalent to the C API UINT32 eyelink_time_offset();\n";


static char trackerTimeUsec_doc[]=
"trackerTimeUsec()\n"
"Returns the current tracker time (in microseconds) since the tracker application started.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"A double precision data for the current tracker time (in microseconds) since tracker initialization.\n"
"This is equivalent to the C API UINT32 eyelink_tracker_time();\n";


static char trackerTimeUsecOffset_doc[]=
"trackerTimeUsecOffset()\n"
"Returns the time difference between the tracker time and display pc time.\n"
"Parameters\n"
"None.\n"
"Return Value\n"
"A double precision data for the time difference (in microseconds) between the tracker time and display\n"
"pc time.\n"
"This is equivalent to the C API double eyelink_time_usec_offset();\n";



static char userMenuSelection_doc[]=
"userMenuSelection()\n"
"Checks for a user-menu selection, clears response for next call.\n"
"Parameters\n"
"None\n"
"Return Value\n"
"0 if no selection made since last call, else code of selection\n"
"This function is equivalent to the C API INT16 eyelink_user_menu_selection(void);\n";


static char waitForBlockStart_doc[]=
"waitForBlockStart(tiemout, samples, events)\n"
"Reads and discards events in data queue until in a recording block. Waits for up to <timeout> milliseconds\n"
"for a block containing samples, events, or both to be opened. Items in the queue are discarded until the\n"
"block start events are found and processed. This function will fail if both samples and events are selected\n"
"but only one of link samples and events were enabled by startRecording().\n"
"Parameters\n"
"<timeout>: time in milliseconds to wait.\n"
"<samples>: if non-zero, check if in a block with samples.\n"
"<events>: if non-zero, check if in a block with events..\n"
"Return Value\n"
"0 if time expired without any data of masked types available.\n"
"Remarks\n"
"This function did not work in versions previous to 2.0.\n"
"This function is equivalent to the C API INT16 eyelink_wait_for_block_start(UINT32 maxwait,INT16\n"
"samples, INT16 events);\n";




static char waitForData_doc[]=
"waitForData(maxwait, samples, events)\n"
"Waits for data to be received from the eye tracker. Can wait for an event, a sample, or either. Typically\n"
"used after record start to check if data is being sent.\n"
"Parameters\n"
"<maxwait>: time in milliseconds to wait for data.\n"
"<samples>: if 1, return when first sample available.\n"
"<events>: if 1, return when first event available.\n"
"Return Value\n"
"1 if data is available; 0 if timed out.\n"
"This function is equivalent to the C API INT16 eyelink_wait_for_data (UINT32 maxwait, INT16 samples,\n"
"INT16 events);\n";



static char waitForModeReady_doc[]=
"waitForModeReady(maxwait)\n"
"After a mode-change command is given to the EyeLink tracker, an additional 5 to 30 milliseconds may be\n"
"needed to complete mode setup. Call this function after mode change functions.\n"
"Parameters\n"
"<maxwait>: Maximum milliseconds to wait for the mode to change.\n"
"Return Value\n"
"0 if mode switching is done, else still waiting.\n"
"Remarks\n"
"If it does not return 0, assume a tracker error has occurred.\n"
"This function is equivalent to the C API INT16 eyelink_wait_for_mode_ready(UINT32 maxwait);\n";



static char request_cross_hair_draw_doc [] = "DOC UNDONE";
static char inRealTimeMode_doc []= "DOC UNDONE";
static char enableExtendedRealtime_doc[]= "DOC UNDONE";
static char resetBackground_doc[]= "DOC UNDONE";
static char disableCustomBackgroundOnImageMode_doc[]= "DOC UNDONE";
static char openCustomGraphicsInternal_doc[]= "DOC UNDONE";
static char sendMessageToFile_doc[]= "DOC UNDONE";
static char openMessageFile_doc[]= "DOC UNDONE";
static char closeMessageFile_doc[]= "DOC UNDONE";

static char dummy_open_doc[]= "DOC UNDONE";
static char sendTimedCommand_doc[]= "DOC UNDONE";
static char sendTimedCommandEx_doc[]= "DOC UNDONE";
static char getLastButtonStates_doc[]= "DOC UNDONE";
static char requestFileRead_doc[]= "DOC UNDONE";
static char key_message_pump_doc[]= "DOC UNDONE";
static char endFileTransfer_doc[]= "DOC UNDONE";
static char requestFileBlock_doc[]= "DOC UNDONE";
static char buttonStates_doc[]= "DOC UNDONE";
static char imageModeDisplay_doc[]= "DOC UNDONE";
static char targetModeDisplay_doc[]= "DOC UNDONE";
static char _getDataStatus_doc[]= "DOC UNDONE";
static char requestTime_doc[]= "DOC UNDONE";
static char readTime_doc[]= "DOC UNDONE";
static char _drawCalTarget_doc[]= "DOC UNDONE";
static char getImageCrossHairData_doc[]= "DOC UNDONE";
# 43 "csrc/eyelinkmodule.c" 2





static PyTypeObject EyelinkTrackerType;
static PyObject *newSample = ((void *)0);
static PyObject *newStartBlinkEvent = ((void *)0);
static PyObject *newEndBlinkEvent = ((void *)0);
static PyObject *newStartSacadeEvent = ((void *)0);
static PyObject *newEndSacadeEvent = ((void *)0);
static PyObject *newStartFixationEvent = ((void *)0);
static PyObject *newEndFixationEvent = ((void *)0);
static PyObject *newIOEvent = ((void *)0);
static PyObject *newMessageEvent = ((void *)0);
static PyObject *newFixUpdateEvent = ((void *)0);
static PyObject *newDisplayInfo = ((void *)0);
static PyObject *EyelinkMessage = ((void *)0);
static PyObject *trackerModule = ((void *)0);

static PyObject *updatePerTrialDynamic = ((void *)0);
static PyObject *updateBooleanFlags = ((void *)0);
static PyObject *updateTimeStamps = ((void *)0);
static PyObject *updateStatusFlags = ((void *)0);
static PyObject *updateTypeFlags = ((void *)0);
static PyObject *updateSampleEventData = ((void *)0);
static PyObject *updateNetworkData = ((void *)0);
static PyObject *updateAddresses = ((void *)0);
static PyObject *updateReserved = ((void *)0);
static PyObject *drawCalTarget = ((void *)0);


inline INT32 eyelink_in_realtime_mode(void)
{
    return in_realtime_mode();
}
# 105 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_broadcast_open(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_broadcast_open(); char *rvm = eyelink_get_error(rv, "eyelink_""broadcast_open"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}






static PyObject* eyelink_eyelink_dummy_open(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_dummy_open(); char *rvm = eyelink_get_error(rv, "eyelink_""dummy_open"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 124 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_is_connected(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_is_connected(); char *rvm = eyelink_get_error(rv, "eyelink_""is_connected"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 135 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_poll_trackers(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_poll_trackers(); char *rvm = eyelink_get_error(rv, "eyelink_""poll_trackers"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 146 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_poll_remotes(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_poll_remotes(); char *rvm = eyelink_get_error(rv, "eyelink_""poll_remotes"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 158 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_poll_responses(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_poll_responses(); char *rvm = eyelink_get_error(rv, "eyelink_""poll_responses"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 170 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_command_result(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_command_result(); char *rvm = eyelink_get_error(rv, "eyelink_""command_result"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 184 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_abort(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_abort(); char *rvm = eyelink_get_error(rv, "eyelink_""abort"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 195 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_start_setup(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_start_setup(); char *rvm = eyelink_get_error(rv, "eyelink_""start_setup"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 206 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_in_setup(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_in_setup(); char *rvm = eyelink_get_error(rv, "eyelink_""in_setup"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 221 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_accept_trigger(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_accept_trigger(); char *rvm = eyelink_get_error(rv, "eyelink_""accept_trigger"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 235 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_cal_result(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_cal_result(); char *rvm = eyelink_get_error(rv, "eyelink_""cal_result"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 246 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_apply_driftcorr(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_apply_driftcorr(); char *rvm = eyelink_get_error(rv, "eyelink_""apply_driftcorr"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 276 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_tracker_mode(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_tracker_mode(); char *rvm = eyelink_get_error(rv, "eyelink_""tracker_mode"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 286 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_user_menu_selection(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_user_menu_selection(); char *rvm = eyelink_get_error(rv, "eyelink_""user_menu_selection"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 300 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_eye_available(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_eye_available(); char *rvm = eyelink_get_error(rv, "eyelink_""eye_available"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 328 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_sample_data_flags(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_sample_data_flags(); char *rvm = eyelink_get_error(rv, "eyelink_""sample_data_flags"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 353 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_event_data_flags(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_event_data_flags(); char *rvm = eyelink_get_error(rv, "eyelink_""event_data_flags"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 376 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_event_type_flags(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_event_type_flags(); char *rvm = eyelink_get_error(rv, "eyelink_""event_type_flags"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 388 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_position_prescaler(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_position_prescaler(); char *rvm = eyelink_get_error(rv, "eyelink_""position_prescaler"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 399 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_data_stop(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_data_stop(); char *rvm = eyelink_get_error(rv, "eyelink_""data_stop"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 413 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_playback_start(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_playback_start(); char *rvm = eyelink_get_error(rv, "eyelink_""playback_start"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 422 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_playback_stop(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_playback_stop(); char *rvm = eyelink_get_error(rv, "eyelink_""playback_stop"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}



static PyObject* eyelink_eyelink_image_status(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_image_status(); char *rvm = eyelink_get_error(rv, "eyelink_""image_status"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 438 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_button_states(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_button_states(); char *rvm = eyelink_get_error(rv, "eyelink_""button_states"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 462 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_current_mode(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_current_mode(); char *rvm = eyelink_get_error(rv, "eyelink_""current_mode"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}



static PyObject* eyelink_eyelink_bitmap_ack_count(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_bitmap_ack_count(); char *rvm = eyelink_get_error(rv, "eyelink_""bitmap_ack_count"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}



static PyObject* eyelink_eyelink_end_file_transfer(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv = eyelink_end_file_transfer(); char *rvm = eyelink_get_error(rv, "eyelink_""end_file_transfer"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}



static PyObject* eyelink_eyelink_send_command(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { char * str = ((void *)0); UINT16 rv = eyelink_send_command(str); char *rvm = eyelink_get_error(rv, "eyelink_""send_command"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}



static PyObject* eyelink_eyelink_send_message(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { char * str = ((void *)0); UINT16 rv = eyelink_send_message(str); char *rvm = eyelink_get_error(rv, "eyelink_""send_message"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 489 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_get_tracker_version(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { char * str = ((void *)0); UINT16 rv = eyelink_get_tracker_version(str); char *rvm = eyelink_get_error(rv, "eyelink_""get_tracker_version"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
static PyObject* eyelink_eyelink_request_file_read(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { char * str = ((void *)0); UINT16 rv = eyelink_request_file_read(str); char *rvm = eyelink_get_error(rv, "eyelink_""request_file_read"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 502 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelinks_last_message(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { char str[1024]; memset(str,0,sizeof(str)); eyelink_last_message(str); return Py_BuildValue("s", str); } return ((void *)0);}
# 512 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelinks_read_reply(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { char str[1024]; memset(str,0,sizeof(str)); eyelink_read_reply(str); return Py_BuildValue("s", str); } return ((void *)0);}
# 523 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelinks_cal_message(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { char str[1024]; memset(str,0,sizeof(str)); eyelink_cal_message(str); return Py_BuildValue("s", str); } return ((void *)0);}
# 534 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelinks_get_tracker_version(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { char str[1024]; memset(str,0,sizeof(str)); eyelink_get_tracker_version(str); return Py_BuildValue("s", str); } return ((void *)0);}
# 543 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_in_realtime_mode(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT32 rv = eyelink_in_realtime_mode(); char *rvm = eyelink_get_error(rv, "eyelink_""in_realtime_mode"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}







static PyObject* eyelink_eyelink_request_time(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT32 rv = eyelink_request_time(); char *rvm = eyelink_get_error(rv, "eyelink_""request_time"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}






static PyObject* eyelink_eyelink_read_time(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT32 rv = eyelink_read_time(); char *rvm = eyelink_get_error(rv, "eyelink_""read_time"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}





static PyObject* eyelink_eyelink_reset_data(PyObject* self, PyObject* args)
{
 if (PyArg_ParseTuple(args,":"))
 {
  eyelink_reset_data(1);
  return Py_BuildValue("");
 }
 return ((void *)0);
}
# 587 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_quiet_mode(PyObject* self, PyObject* args){ UINT16 arg =0; if (PyArg_ParseTuple(args,"h", &arg)) { int rv = eyelink_quiet_mode(arg); char *rvm = eyelink_get_error(rv, "eyelink_""quiet_mode"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 602 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_flush_keybuttons(PyObject* self, PyObject* args){ UINT16 arg =0; if (PyArg_ParseTuple(args,"h", &arg)) { int rv = eyelink_flush_keybuttons(arg); char *rvm = eyelink_get_error(rv, "eyelink_""flush_keybuttons"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 615 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_data_switch(PyObject* self, PyObject* args){ UINT16 arg =0; if (PyArg_ParseTuple(args,"h", &arg)) { int rv = eyelink_data_switch(arg); char *rvm = eyelink_get_error(rv, "eyelink_""data_switch"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 628 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_wait_for_mode_ready(PyObject* self, PyObject* args){ int arg =0; if (PyArg_ParseTuple(args,"i", &arg)) { int rv = eyelink_wait_for_mode_ready(arg); char *rvm = eyelink_get_error(rv, "eyelink_""wait_for_mode_ready"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}



static PyObject* eyelink_eyelink_request_file_block(PyObject* self, PyObject* args){ int arg =0; if (PyArg_ParseTuple(args,"i", &arg)) { int rv = eyelink_request_file_block(arg); char *rvm = eyelink_get_error(rv, "eyelink_""request_file_block"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 657 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_data_start(PyObject* self, PyObject* args){ INT16 arg1 =0; INT16 arg2 =0; if (PyArg_ParseTuple(args,"hh", &arg1, &arg2)) { int rv = eyelink_data_start(arg1, arg2); char *rvm = eyelink_get_error(rv, "eyelink_""data_start"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 670 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_driftcorr_start(PyObject* self, PyObject* args){ INT16 arg1 =0; INT16 arg2 =0; if (PyArg_ParseTuple(args,"hh", &arg1, &arg2)) { int rv = eyelink_driftcorr_start(arg1, arg2); char *rvm = eyelink_get_error(rv, "eyelink_""driftcorr_start"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 682 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_data_count(PyObject* self, PyObject* args){ INT16 arg1 =0; INT16 arg2 =0; if (PyArg_ParseTuple(args,"hh", &arg1, &arg2)) { int rv = eyelink_data_count(arg1, arg2); char *rvm = eyelink_get_error(rv, "eyelink_""data_count"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 698 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_in_data_block(PyObject* self, PyObject* args){ INT16 arg1 =0; INT16 arg2 =0; if (PyArg_ParseTuple(args,"hh", &arg1, &arg2)) { int rv = eyelink_in_data_block(arg1, arg2); char *rvm = eyelink_get_error(rv, "eyelink_""in_data_block"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 715 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_wait_for_block_start(PyObject* self, PyObject* args){ INT16 arg1 =0; INT16 arg2 =0; INT16 arg3 =0; if (PyArg_ParseTuple(args,"hhh", &arg1, &arg2, &arg3)) { int rv = eyelink_wait_for_block_start(arg1, arg2, arg3); char *rvm = eyelink_get_error(rv, "eyelink_""wait_for_block_start"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 729 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_wait_for_data(PyObject* self, PyObject* args){ INT16 arg1 =0; INT16 arg2 =0; INT16 arg3 =0; if (PyArg_ParseTuple(args,"hhh", &arg1, &arg2, &arg3)) { int rv = eyelink_wait_for_data(arg1, arg2, arg3); char *rvm = eyelink_get_error(rv, "eyelink_""wait_for_data"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 742 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_send_keybutton(PyObject* self, PyObject* args){ INT16 arg1 =0; INT16 arg2 =0; INT16 arg3 =0; if (PyArg_ParseTuple(args,"hhh", &arg1, &arg2, &arg3)) { int rv = eyelink_send_keybutton(arg1, arg2, arg3); char *rvm = eyelink_get_error(rv, "eyelink_""send_keybutton"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 765 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_stop_recording(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) {stop_recording(); return Py_BuildValue(""); } return ((void *)0);}
# 775 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_set_offline_mode(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) {set_offline_mode(); return Py_BuildValue(""); } return ((void *)0);}
# 786 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_flush_getkey_queue(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) {flush_getkey_queue(); return Py_BuildValue(""); } return ((void *)0);}
# 796 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_exit_calibration(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) {exit_calibration(); return Py_BuildValue(""); } return ((void *)0);}
# 807 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_end_realtime_mode(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) {end_realtime_mode(); return Py_BuildValue(""); } return ((void *)0);}
# 822 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_message_pump(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { INT16 rv =message_pump(); char *rvm = eyelink_get_error(rv, "message_pump"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 837 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_check_recording(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { INT16 rv =check_recording(); char *rvm = eyelink_get_error(rv, "check_recording"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 851 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_check_record_exit(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { INT16 rv =check_record_exit(); char *rvm = eyelink_get_error(rv, "check_record_exit"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 861 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_do_tracker_setup(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { INT16 rv =do_tracker_setup(); char *rvm = eyelink_get_error(rv, "do_tracker_setup"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 874 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_image_mode_display(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { INT16 rv =image_mode_display(); char *rvm = eyelink_get_error(rv, "image_mode_display"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 886 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_target_mode_display(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { INT16 rv =target_mode_display(); char *rvm = eyelink_get_error(rv, "target_mode_display"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 897 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_close_data_file(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { INT16 rv =close_data_file(); char *rvm = eyelink_get_error(rv, "close_data_file"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}




static PyObject* eyelink_eyelink_key_message_pump(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { INT16 rv =key_message_pump(); char *rvm = eyelink_get_error(rv, "key_message_pump"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 914 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_escape_pressed(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { INT16 rv =escape_pressed(); char *rvm = eyelink_get_error(rv, "escape_pressed"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 929 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_break_pressed(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { INT16 rv =break_pressed(); char *rvm = eyelink_get_error(rv, "break_pressed"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}



static PyObject* eyelink_eyelink_eyelink_enable_extended_realtime(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) {eyelink_enable_extended_realtime(); return Py_BuildValue(""); } return ((void *)0);}



static PyObject* eyelink_eyelink_close_message_file(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) {close_message_file(); return Py_BuildValue(""); } return ((void *)0);}
# 965 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_getkey(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv =getkey(); return Py_BuildValue("i",rv); } return ((void *)0);}
# 993 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_getkey_with_mod(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 unicode[2] ={0,0}; UINT32 rv =getkey_with_mod(unicode); unicode[1] =0; if(rv) { return Py_BuildValue("(iis)",rv&0x0000ffff,rv>>16, unicode);} return Py_BuildValue("O",(&_Py_NoneStruct)); } return ((void *)0);}
# 1006 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_echo_key(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv =echo_key(); return Py_BuildValue("i",rv); } return ((void *)0);}
# 1021 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_read_getkey_queue(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { UINT16 rv =read_getkey_queue(); return Py_BuildValue("i",rv); } return ((void *)0);}
# 1032 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_current_time(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { double rv =current_time(); return Py_BuildValue("d",rv); } return ((void *)0);}
# 1042 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_current_usec(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { double rv =current_usec(); return Py_BuildValue("d",rv); } return ((void *)0);}
# 1055 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_current_double_usec(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { double rv =current_double_usec(); return Py_BuildValue("d",rv); } return ((void *)0);}
# 1067 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_eyecmd_printf(PyObject* self, PyObject* args){ char *arg =((void *)0); if (PyArg_ParseTuple(args,"s", &arg)) { char *rvm=((void *)0); int rv = 0; if(strlen(arg) > 129) { PyErr_Format(PyExc_RuntimeError, "Command too long: %s", arg); return ((void *)0); } rv =eyecmd_printf(arg); rvm = eyelink_get_error(rv, "eyecmd_printf"); if(!rvm || !strlen(rvm) || rv == 1000) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 1081 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_eyelink_read_request(PyObject* self, PyObject* args){ char *arg =((void *)0); if (PyArg_ParseTuple(args,"s", &arg)) { int rv =eyelink_read_request(arg); char *rvm = eyelink_get_error(rv, "eyelink_read_request"); if(!rvm || !strlen(rvm) || rv == 1000) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 1096 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_eyemsg_printf(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_timemsg_printf(PyObject* self, PyObject* args);
# 1112 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_open_data_file(PyObject* self, PyObject* args){ char *arg =((void *)0); if (PyArg_ParseTuple(args,"s", &arg)) { int rv =open_data_file(arg); char *rvm = eyelink_get_error(rv, "open_data_file"); if(!rvm || !strlen(rvm) || rv == 1000) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}






static PyObject* eyelink_eyelink_open_message_file(PyObject* self, PyObject* args){ char *arg =((void *)0); if (PyArg_ParseTuple(args,"s", &arg)) { int rv =open_message_file(arg); char *rvm = eyelink_get_error(rv, "open_message_file"); if(!rvm || !strlen(rvm) || rv == 1000) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 1136 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_set_eyelink_address(PyObject* self, PyObject* args){ char *arg =((void *)0); if (PyArg_ParseTuple(args,"s", &arg)) { int rv =set_eyelink_address(arg); char *rvm = eyelink_get_error(rv, "set_eyelink_address"); if(!rvm || !strlen(rvm) || rv == 1000) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 1154 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_start_recording(PyObject* self, PyObject* args){ INT16 arg1 =0; INT16 arg2 =0; INT16 arg3 =0; INT16 arg4 =0; if (PyArg_ParseTuple(args,"hhhh", &arg1, &arg2, &arg3, &arg4)) { int rv =start_recording(arg1, arg2, arg3, arg4); return Py_BuildValue("i",rv); } return ((void *)0);}
# 1170 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_do_drift_correct(PyObject* self, PyObject* args){ INT16 arg1 =0; INT16 arg2 =0; INT16 arg3 =0; INT16 arg4 =0; if (PyArg_ParseTuple(args,"hhhh", &arg1, &arg2, &arg3, &arg4)) { int rv =do_drift_correct(arg1, arg2, arg3, arg4); char *rvm = eyelink_get_error(rv, "do_drift_correct"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); } return ((void *)0);}
# 1182 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_double_usec_offset(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { double rv = eyelink_double_usec_offset(); return Py_BuildValue("d",rv); } return ((void *)0);};
# 1193 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_tracker_double_usec(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { double rv = eyelink_tracker_double_usec(); return Py_BuildValue("d",rv); } return ((void *)0);};
# 1204 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_msec_offset(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { double rv = eyelink_msec_offset(); return Py_BuildValue("d",rv); } return ((void *)0);};
# 1215 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_tracker_msec(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { double rv = eyelink_tracker_msec(); return Py_BuildValue("d",rv); } return ((void *)0);};
static PyObject* eyelink_eyelink_set_name(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_node_send(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_timed_command(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_timed_commandEx(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_node_send_message(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_node_request_time(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_open(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_get_node(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_node_receive(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_open_node(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_last_button_press(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_target_check(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_mode_data(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_read_keybutton(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_receiveDataFile(PyObject* self, PyObject* args);



static PyObject* eyelink_eyelink_map_eyelink_py_draw_cal_target_hook(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_eyelink_last_button_states(PyObject* self, PyObject* args);
# 1263 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_data_status(PyObject* self, PyObject* args);
# 1279 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_pump_delay(PyObject* self, PyObject* args){ UINT32 arg = 0; if (PyArg_ParseTuple(args,"i",&arg)) {pump_delay(arg); return Py_BuildValue(""); } return ((void *)0);};
# 1292 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_begin_realtime_mode(PyObject* self, PyObject* args){ UINT32 arg = 0; if (PyArg_ParseTuple(args,"i",&arg)) {begin_realtime_mode(arg); return Py_BuildValue(""); } return ((void *)0);};
# 1302 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_msec_delay(PyObject* self, PyObject* args){ UINT32 arg = 0; if (PyArg_ParseTuple(args,"i",&arg)) {msec_delay(arg); return Py_BuildValue(""); } return ((void *)0);};
# 1315 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_terminal_break(PyObject* self, PyObject* args){ UINT16 arg = 0; if (PyArg_ParseTuple(args,"h",&arg)) {terminal_break(arg); return Py_BuildValue(""); } return ((void *)0);};
# 1326 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_alert_printf(PyObject* self, PyObject* args){ char *arg =((void *)0); if (PyArg_ParseTuple(args,"s", &arg)) {alert_printf(arg); return Py_BuildValue(""); } return ((void *)0);};

static PyObject* eyelink_eyelink_bitmapSaveAndBackdrop(PyObject* self, PyObject* args);
static PyObject* eyelink_eyelink_bitmapSave(PyObject* self, PyObject* args);





static PyObject* eyelink_eyelink_bitmapBackdrop(PyObject* self, PyObject* args);
# 1398 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_close(PyObject* self, PyObject* args){

 if (PyArg_ParseTuple(args,":"))
 {
  int rv = eyelink_close(1);
  return Py_BuildValue("i",rv);
 }
 return ((void *)0);
}
# 1417 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_reset(PyObject* self, PyObject* args){

 if (PyArg_ParseTuple(args,":"))
 {
  int rv = eyelink_close(0);
  return Py_BuildValue("i",rv);
 }
 return ((void *)0);
}







static PyObject* eyelink_eyelink_get_next_data(PyObject* self, PyObject* args)
{
 if (PyArg_ParseTuple(args,":"))
 {
  void *data = ((void *)0);
  UINT16 rv = eyelink_get_next_data(data);
  return Py_BuildValue("i",rv);
 }
 return ((void *)0);
}


static PyObject* allf_data_ctopyobj(ALLF_DATA *data, INT16 type)
{

 if(!trackerModule)
  getTrackerModule();
 if(data && type)
 {
  switch(type)
  {
  case 200:
    return PyObject_CallFunction(newSample,"di(dd)(dd)(dd)(dd)(dd)(dd)(dd)ddiiii(iiiiiiii)",
     (((double)((&(data->fs))->time)) + (((&(data->fs))->type==200 && (&(data->fs))->flags & 0x0002)?0.5:0.0)),
     data->fs.flags,
     data->fs.px[0], data->fs.px[1],
     data->fs.py[0], data->fs.py[1],
     data->fs.hx[0], data->fs.hx[1],
     data->fs.hy[0], data->fs.hy[1],
     data->fs.pa[0], data->fs.pa[1],
     data->fs.gx[0], data->fs.gx[1],
     data->fs.gy[0], data->fs.gy[1],
     data->fs.rx,
     data->fs.ry,
     data->fs.status,
     data->fs.input,
     data->fs.buttons,
     data->fs.htype,
     data->fs.hdata[0],
     data->fs.hdata[1],
     data->fs.hdata[2],
     data->fs.hdata[3],
     data->fs.hdata[4],
     data->fs.hdata[5],
     data->fs.hdata[6],
     data->fs.hdata[7]
     );

  case 3:
   return PyObject_CallFunction(newStartBlinkEvent,"diiid",
    (double)(data->fe.time),
    data->fe.type,
    data->fe.eye,
    data->fe.read,
    (double)(data->fe.sttime));

  case 4:
   return PyObject_CallFunction(newEndBlinkEvent,"diiidd",
    (double)(data->fe.time),
    data->fe.type,
    data->fe.eye,
    data->fe.read,
    (double)(data->fe.sttime),
    (double)(data->fe.entime)
    );

  case 5:
   return PyObject_CallFunction(newStartSacadeEvent,"diiddddddddd",
    (double)(data->fe.time),
    data->fe.type,
    data->fe.eye,
    (double)(data->fe.sttime),
    data->fe.hstx,
    data->fe.hsty,
    data->fe.gstx,
    data->fe.gsty,
    data->fe.supd_x,
    data->fe.supd_y,
    data->fe.sta,
    data->fe.svel);
  case 6:
   return PyObject_CallFunction(newEndSacadeEvent,"diiidddddddddddddddddd",
    (double)(data->fe.time),
    data->fe.type,
    data->fe.eye,
    data->fe.read,
    (double)(data->fe.sttime),

    data->fe.gstx,
    data->fe.gsty,
    data->fe.hstx,
    data->fe.hsty,
    data->fe.svel,
    data->fe.supd_x,
    data->fe.supd_y,

    (double)(data->fe.entime),

    data->fe.genx,
    data->fe.geny,
    data->fe.henx,
    data->fe.heny,
    data->fe.evel,
    data->fe.avel,
    data->fe.pvel,
    data->fe.eupd_x,
    data->fe.eupd_y);



  case 7:
   return PyObject_CallFunction(newStartFixationEvent,"diiiddddddddd",
    (double)(data->fe.time),
    data->fe.type,
    data->fe.eye,
    data->fe.read,
    (double)(data->fe.sttime),
    data->fe.gstx,
    data->fe.gsty,
    data->fe.hstx,
    data->fe.hsty,
    data->fe.sta,
    data->fe.svel,
    data->fe.supd_x,
    data->fe.supd_y);

  case 8:
   return PyObject_CallFunction(newEndFixationEvent,"diiiddddddddddddddddddddddddd",
    (double)(data->fe.time),
    data->fe.type,
    data->fe.eye,
    data->fe.read,
    (double)(data->fe.sttime),
    data->fe.gstx,
    data->fe.gsty,
    data->fe.hstx,
    data->fe.hsty,
    data->fe.sta,
    data->fe.svel,
    data->fe.supd_x,
    data->fe.supd_y,
    (double)(data->fe.entime),
    data->fe.genx,
    data->fe.geny,
    data->fe.gavx,
    data->fe.gavy,
    data->fe.henx,
    data->fe.heny,
    data->fe.havx,
    data->fe.havy,
    data->fe.ena,
    data->fe.ava,
    data->fe.evel,
    data->fe.avel,
    data->fe.pvel,
    data->fe.eupd_x,
    data->fe.eupd_y);
  case 9:
   return PyObject_CallFunction(newFixUpdateEvent,"diiiddddddddddddddddddddddddd",
    (double)(data->fe.time),
    data->fe.type,
    data->fe.eye,
    data->fe.read,
    (double)(data->fe.sttime),
    data->fe.gstx,
    data->fe.gsty,
    data->fe.hstx,
    data->fe.hsty,
    data->fe.sta,
    data->fe.svel,
    data->fe.supd_x,
    data->fe.supd_y,
    (double)(data->fe.entime),
    data->fe.genx,
    data->fe.geny,
    data->fe.gavx,
    data->fe.gavy,
    data->fe.henx,
    data->fe.heny,
    data->fe.havx,
    data->fe.havy,
    data->fe.ena,
    data->fe.ava,
    data->fe.evel,
    data->fe.avel,
    data->fe.pvel,
    data->fe.eupd_x,
    data->fe.eupd_y);
# 1648 "csrc/eyelinkmodule.c"
  case 25:
  case 28:
   if (data->io.data != 0)
       return PyObject_CallFunction(newIOEvent,"idi",type, (double)(data->io.time), data->io.data);
   else
    return Py_BuildValue("");
  case 24:
   return PyObject_CallFunction(newMessageEvent,"dis",(double)(data->im.time), type,data->im.text);

  }
 }
 return Py_BuildValue("");
}

static PyObject* all_data_ctopyobj(ALL_DATA *data, INT16 type)
{
 if(data && type)
 {
  switch(type)
  {
  case 200:
    return PyObject_CallFunction(newSample,"ii(ii)(ii)(ii)(ii)(ii)(ii)(ii)iiiiii(iiiiiiii)",
     data->is.time, data->is.flags,
     data->is.px[0], data->is.px[1],
     data->is.py[0], data->is.py[1],
     data->is.hx[0], data->is.hx[1],
     data->is.hy[0], data->is.hy[1],
     data->is.pa[0], data->is.pa[1],
     data->is.gx[0], data->is.gx[1],
     data->is.gy[0], data->is.gy[1],
     data->is.rx,
     data->is.ry,
     data->is.status,
     data->is.input,
     data->is.buttons,
     data->is.htype,
     data->is.hdata[0],
     data->is.hdata[1],
     data->is.hdata[2],
     data->is.hdata[3],
     data->is.hdata[4],
     data->is.hdata[5],
     data->is.hdata[6],
     data->is.hdata[7]
     );

  case 3:
   return PyObject_CallFunction(newStartBlinkEvent,"iiiiiiiiii",
    data->ie.eye,
    data->ie.sttime,
    data->ie.hstx,
    data->ie.hsty,
    data->ie.gstx,
    data->ie.gsty,
    data->ie.supd_x,
    data->ie.supd_y,
    data->ie.sta,
    data->ie.svel);

  case 4:
   return PyObject_CallFunction(newEndBlinkEvent,"iiiiiiiiiiiiiiiiiiiiiii",
    data->ie.eye,
    data->ie.sttime,
    data->ie.hstx,
    data->ie.hsty,
    data->ie.gstx,
    data->ie.gsty,
    data->ie.supd_x,
    data->ie.supd_y,
    data->ie.sta,
    data->ie.svel,
    data->ie.entime,
    data->ie.henx,
    data->ie.heny,
    data->ie.genx,
    data->ie.geny,
    data->ie.eupd_x,
    data->ie.eupd_y,
    data->ie.ena,
    data->ie.evel,
    data->ie.gavx,
    data->ie.gavy,
    data->ie.havx,
    data->ie.havy
    );

  case 5:
   return PyObject_CallFunction(newStartSacadeEvent,"iiiiiiiiii",
    data->ie.eye,
    data->ie.sttime,
    data->ie.hstx,
    data->ie.hsty,
    data->ie.gstx,
    data->ie.gsty,
    data->ie.supd_x,
    data->ie.supd_y,
    data->ie.sta,
    data->ie.svel);
  case 6:
   return PyObject_CallFunction(newEndSacadeEvent,"iiiiiiiiiiiiiiiiiiiiiii",
    data->ie.eye,
    data->ie.sttime,
    data->ie.hstx,
    data->ie.hsty,
    data->ie.gstx,
    data->ie.gsty,
    data->ie.supd_x,
    data->ie.supd_y,
    data->ie.sta,
    data->ie.svel,
    data->ie.entime,
    data->ie.henx,
    data->ie.heny,
    data->ie.genx,
    data->ie.geny,
    data->ie.eupd_x,
    data->ie.eupd_y,
    data->ie.ena,
    data->ie.evel,
    data->ie.gavx,
    data->ie.gavy,
    data->ie.havx,
    data->ie.havy);

  case 7:
   return PyObject_CallFunction(newStartFixationEvent,"iiiiiiiiii",
    data->ie.eye,
    data->ie.sttime,
    data->ie.hstx,
    data->ie.hsty,
    data->ie.gstx,
    data->ie.gsty,
    data->ie.supd_x,
    data->ie.supd_y,
    data->ie.sta,
    data->ie.svel);

  case 8:
   return PyObject_CallFunction(newEndFixationEvent,"iiiiiiiiiiiiiiiiiiiiiii",
    data->ie.eye,
    data->ie.sttime,
    data->ie.hstx,
    data->ie.hsty,
    data->ie.gstx,
    data->ie.gsty,
    data->ie.supd_x,
    data->ie.supd_y,
    data->ie.sta,
    data->ie.svel,
    data->ie.entime,
    data->ie.henx,
    data->ie.heny,
    data->ie.genx,
    data->ie.geny,
    data->ie.eupd_x,
    data->ie.eupd_y,
    data->ie.ena,
    data->ie.evel,
    data->ie.gavx,
    data->ie.gavy,
    data->ie.havx,
    data->ie.havy);
  case 9:
   return PyObject_CallFunction(newFixUpdateEvent,"iiiiiiiiiiiiiiiiiiiiiii",
    data->ie.eye,
    data->ie.sttime,
    data->ie.hstx,
    data->ie.hsty,
    data->ie.gstx,
    data->ie.gsty,
    data->ie.supd_x,
    data->ie.supd_y,
    data->ie.sta,
    data->ie.svel,
    data->ie.entime,
    data->ie.henx,
    data->ie.heny,
    data->ie.genx,
    data->ie.geny,
    data->ie.eupd_x,
    data->ie.eupd_y,
    data->ie.ena,
    data->ie.evel,
    data->ie.gavx,
    data->ie.gavy,
    data->ie.havx,
    data->ie.havy);


  case 25:
  case 28:
   if (data->io.data != 0)
       return PyObject_CallFunction(newIOEvent,"iii",type, data->io.time, data->io.data);
   else
    return Py_BuildValue("");
  case 24:
   return PyObject_CallFunction(newMessageEvent,"is",data->im.time, data->im.text);

  }
 }
 return Py_BuildValue("");
}
# 1895 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_get_float_data(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { ALLF_DATA data; UINT16 rv =0; memset(&data,0,sizeof(data)); rv = eyelink_get_float_data(&data); return allf_data_ctopyobj(&data, rv); } return ((void *)0);}
# 1906 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_get_last_data(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { ALLF_DATA data; UINT16 rv =0; memset(&data,0,sizeof(data)); rv = eyelink_get_last_data(&data); return allf_data_ctopyobj(&data, rv); } return ((void *)0);}

static PyObject* eyelink_eyelink_newest_sample(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { ALLF_DATA data; INT16 rv = 0; memset(&data,0,sizeof(ALLF_DATA)); rv = eyelink_newest_sample(&data); return allf_data_ctopyobj(&data, (UINT16)(rv!=-1?200:0) ); } return ((void *)0);}
# 1919 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_newest_float_sample(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { ALLF_DATA data; INT16 rv = 0; memset(&data,0,sizeof(ALLF_DATA)); rv = eyelink_newest_float_sample(&data); return allf_data_ctopyobj(&data, (UINT16)(rv!=-1?200:0) ); } return ((void *)0);}
# 1929 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_get_sample(PyObject* self, PyObject* args){ if (PyArg_ParseTuple(args,":")) { ALLF_DATA data; INT16 rv = 0; memset(&data,0,sizeof(ALLF_DATA)); rv = eyelink_get_sample(&data); return allf_data_ctopyobj(&data, (UINT16)(rv!=-1?200:0) ); } return ((void *)0);}
PyObject* eyelink_eyelink_init_custom_graphics(PyObject* self, PyObject* args);
PyObject* eyelink_eyelink_request_cross_hair_draw(PyObject* self, PyObject* args);


static PyMethodDef eyelink_module_methods[] =
{

 { "inRealTimeMode", eyelink_eyelink_in_realtime_mode,0x0001,inRealTimeMode_doc},
 { "flushGetkeyQueue", eyelink_eyelink_flush_getkey_queue,0x0001,flushGetkeyQueue_doc},
 { "beginRealTimeMode", eyelink_eyelink_begin_realtime_mode,0x0001,beginRealTimeMode_doc},
 { "currentTime", eyelink_eyelink_current_time,0x0001,currentTime_doc},
 { "currentUsec", eyelink_eyelink_current_usec,0x0001,currentUsec_doc},
 { "currentDoubleUsec", eyelink_eyelink_current_double_usec,0x0001,currentDoubleUsec_doc},
 { "endRealTimeMode", eyelink_eyelink_end_realtime_mode,0x0001,endRealTimeMode_doc},
 { "pumpDelay", eyelink_eyelink_pump_delay,0x0001,pumpDelay_doc},
 { "msecDelay", eyelink_eyelink_msec_delay,0x0001,msecDelay_doc},
 { "alert", eyelink_eyelink_alert_printf,0x0001,alert_doc},
 { "enableExtendedRealtime", eyelink_eyelink_eyelink_enable_extended_realtime,0x0001,enableExtendedRealtime_doc},
# 1965 "csrc/eyelinkmodule.c"
 { "sendMessageToFile", eyelink_eyelink_timemsg_printf,0x0001,sendMessageToFile_doc},
 { "openMessageFile", eyelink_eyelink_open_message_file,0x0001,openMessageFile_doc},
 { "closeMessageFile", eyelink_eyelink_close_message_file,0x0001,closeMessageFile_doc},
 { "request_cross_hair_draw", eyelink_eyelink_request_cross_hair_draw,0x0001,request_cross_hair_draw_doc},
 {"bitmapSave",eyelink_eyelink_bitmapSave,0x0001,"bitmapSave(iwidth,iheight,pixels,xs, ys, width,  height,fname,path, sv_options)""iwidth  - original image width""iheight - original image height""pixels  - pixels of the image in the following format.pixel=[line1, line2, ... linen] line=[pix1,pix2,...,pixn],pix=(r,g,b) ""xs - crop x position""ys - crop y position""width - crop width""height - crop height""fname - file name to save""path -  path to save""svoptions - save options(SV_NOREPLACE,SV_MAKEPATH)"},
 { "openCustomGraphicsInternal",eyelink_eyelink_init_custom_graphics,0x0001,openCustomGraphicsInternal_doc},





    {((void *)0), ((void *)0), 0, ((void *)0)}
};


static PyMethodDef eyeTrackerType_methods[] =
{
 { "open", eyelink_eyelink_open,0x0001,open_doc},
 { "dummy_open", eyelink_eyelink_dummy_open,0x0001,dummy_open_doc},
 { "getNextData", eyelink_eyelink_get_next_data,0x0001,getNextData_doc},
 { "getFloatData", eyelink_eyelink_get_float_data,0x0001,getFloatData_doc},
 { "close", eyelink_eyelink_close,0x0001,close_doc},
 { "reset", eyelink_eyelink_reset,0x0001,reset_doc},
 { "stopRecording", eyelink_eyelink_stop_recording,0x0001,stopRecording_doc},
 { "doTrackerSetup", eyelink_eyelink_do_tracker_setup,0x0001,doTrackerSetup_doc},
 { "setAddress", eyelink_eyelink_set_eyelink_address,0x0001,setAddress_doc},
 { "startRecording", eyelink_eyelink_start_recording,0x0001,startRecording_doc},
 { "doDriftCorrect", eyelink_eyelink_do_drift_correct,0x0001,doDriftCorrect_doc},
 { "isConnected", eyelink_eyelink_is_connected,0x0001,isConnected_doc},
 { "getTrackerVersion", eyelink_eyelink_get_tracker_version,0x0001,getTrackerVersion_doc},
 { "openNode", eyelink_eyelink_open_node,0x0001,openNode_doc},
 { "setOfflineMode", eyelink_eyelink_set_offline_mode,0x0001,setOfflineMode_doc},
 { "sendTimedCommand", eyelink_eyelink_timed_command,0x0001,sendTimedCommand_doc},
 { "sendTimedCommandEx", eyelink_eyelink_timed_commandEx,0x0001,sendTimedCommandEx_doc},
 { "sendCommand", eyelink_eyelink_eyecmd_printf,0x0001,sendCommand_doc},
 { "sendMessage", eyelink_eyelink_eyemsg_printf,0x0001,sendMessage_doc},
 { "getkey", eyelink_eyelink_getkey,0x0001,getkey_doc},
 { "getkeyEx", eyelink_eyelink_getkey_with_mod,0x0001,getkeyEx_doc},
 { "abort", eyelink_eyelink_abort,0x0001,abort_doc},
 { "commandResult", eyelink_eyelink_command_result,0x0001,commandResult_doc},
 { "inSetup", eyelink_eyelink_in_setup,0x0001,inSetup_doc},
 { "getCalibrationResult", eyelink_eyelink_cal_result,0x0001,getCalibrationResult_doc},
 { "applyDriftCorrect", eyelink_eyelink_apply_driftcorr,0x0001,applyDriftCorrect_doc},
 { "startSetup", eyelink_eyelink_start_setup,0x0001,startSetup_doc},

 { "getTrackerVersionString",eyelink_eyelinks_get_tracker_version,0x0001,getTrackerVersionString_doc},
 { "getLastMessage", eyelink_eyelinks_last_message,0x0001,getLastMessage_doc},
 { "readRequest", eyelink_eyelink_eyelink_read_request,0x0001,readRequest_doc},
 { "readReply", eyelink_eyelinks_read_reply,0x0001,readReply_doc},
 { "getCalibrationMessage", eyelink_eyelinks_cal_message,0x0001,getCalibrationMessage_doc},
 { "getLastData", eyelink_eyelink_get_last_data,0x0001,getLastData_doc},

 { "getNewestSample", eyelink_eyelink_newest_float_sample,0x0001,getNewestSample_doc},

 { "getSample", eyelink_eyelink_get_sample,0x0001,getSample_doc},




 { "trackerTime", eyelink_eyelink_tracker_msec,0x0001,trackerTime_doc},
 { "trackerTimeOffset", eyelink_eyelink_msec_offset,0x0001,trackerTimeOffset_doc},

 { "trackerTimeUsec", eyelink_eyelink_tracker_double_usec,0x0001,trackerTimeUsec_doc},
 { "trackerTimeUsecOffset", eyelink_eyelink_double_usec_offset,0x0001,trackerTimeUsecOffset_doc},


 { "eyeAvailable", eyelink_eyelink_eye_available,0x0001,eyeAvailable_doc},
 { "getCurrentMode", eyelink_eyelink_current_mode,0x0001,getCurrentMode_doc},
 { "getEventDataFlags", eyelink_eyelink_event_data_flags,0x0001,getEventDataFlags_doc},
 { "getEventTypeFlags", eyelink_eyelink_event_type_flags,0x0001,getEventTypeFlags_doc},
 { "flushKeybuttons", eyelink_eyelink_flush_keybuttons,0x0001,flushKeybuttons_doc},
 { "waitForModeReady", eyelink_eyelink_wait_for_mode_ready,0x0001,waitForModeReady_doc},
 { "exitCalibration", eyelink_eyelink_exit_calibration,0x0001,exitCalibration_doc},
 { "resetData", eyelink_eyelink_reset_data,0x0001,resetData_doc},
 { "getTrackerMode", eyelink_eyelink_tracker_mode,0x0001,getTrackerMode_doc},
 { "readKeyQueue", eyelink_eyelink_read_getkey_queue,0x0001,readKeyQueue_doc},
 { "acceptTrigger", eyelink_eyelink_accept_trigger,0x0001,acceptTrigger_doc},
 { "startDriftCorrect", eyelink_eyelink_driftcorr_start,0x0001,startDriftCorrect_doc},
 { "setName", eyelink_eyelink_set_name,0x0001,setName_doc},
 { "stopData", eyelink_eyelink_data_stop,0x0001,stopData_doc},
 { "startPlayBack", eyelink_eyelink_playback_start,0x0001,startPlayBack_doc},
 { "stopPlayBack", eyelink_eyelink_playback_stop,0x0001,stopPlayBack_doc},
 { "isRecording", eyelink_eyelink_check_recording,0x0001,isRecording_doc},
 { "getRecordingStatus", eyelink_eyelink_check_record_exit,0x0001,getRecordingStatus_doc},
 { "startData", eyelink_eyelink_data_start,0x0001,startData_doc},
 { "openDataFile", eyelink_eyelink_open_data_file,0x0001,openDataFile_doc},
 { "closeDataFile", eyelink_eyelink_close_data_file,0x0001,closeDataFile_doc},
 { "escapePressed", eyelink_eyelink_escape_pressed,0x0001,escapePressed_doc},
 { "breakPressed", eyelink_eyelink_break_pressed,0x0001,breakPressed_doc},
 { "terminalBreak", eyelink_eyelink_terminal_break,0x0001,terminalBreak_doc},
 { "getLastButtonPress", eyelink_eyelink_last_button_press,0x0001,getLastButtonPress_doc},
 { "pumpMessages", eyelink_eyelink_message_pump,0x0001,pumpMessages_doc},
 { "readKeyButton", eyelink_eyelink_read_keybutton,0x0001,readKeyButton_doc},
 { "receiveDataFile", eyelink_eyelink_receiveDataFile,0x0001,receiveDataFile_doc},


 { "getPositionScalar", eyelink_eyelink_position_prescaler,0x0001,getPositionScalar_doc},
 { "userMenuSelection", eyelink_eyelink_user_menu_selection,0x0001,userMenuSelection_doc},
 { "getButtonStates", eyelink_eyelink_button_states,0x0001,getButtonStates_doc},
 { "getLastButtonStates", eyelink_eyelink_eyelink_last_button_states,0x0001,getLastButtonStates_doc},
 { "getDataCount", eyelink_eyelink_data_count,0x0001,getDataCount_doc},
 { "isInDataBlock", eyelink_eyelink_in_data_block,0x0001,isInDataBlock_doc},
 { "waitForBlockStart", eyelink_eyelink_wait_for_block_start,0x0001,waitForBlockStart_doc},
 { "waitForData", eyelink_eyelink_wait_for_data,0x0001,waitForData_doc},
 { "sendKeybutton", eyelink_eyelink_send_keybutton,0x0001,sendKeybutton_doc},
 { "getTargetPositionAndState",eyelink_eyelink_target_check,0x0001,getTargetPositionAndState_doc},
 { "getModeData", eyelink_eyelink_mode_data,0x0001,getModeData_doc},



 { "getSampleDataFlags", eyelink_eyelink_sample_data_flags,0x0001,getSampleDataFlags_doc},

 { "echo_key", eyelink_eyelink_echo_key,0x0001,echo_key_doc},

 { "key_message_pump", eyelink_eyelink_key_message_pump,0x0001,key_message_pump_doc},






 { "broadcastOpen", eyelink_eyelink_broadcast_open,0x0001,broadcastOpen_doc},
 { "nodeSend", eyelink_eyelink_node_send,0x0001,nodeSend_doc},
 { "nodeReceive", eyelink_eyelink_node_receive,0x0001,nodeReceive_doc},
 { "dataSwitch", eyelink_eyelink_data_switch,0x0001,dataSwitch_doc},
 { "nodeSendMessage", eyelink_eyelink_node_send_message,0x0001,nodeSendMessage_doc},
 { "nodeRequestTime", eyelink_eyelink_node_request_time,0x0001,nodeRequestTime_doc},
 { "getNode", eyelink_eyelink_get_node,0x0001,getNode_doc},

 { "pollTrackers", eyelink_eyelink_poll_trackers,0x0001,pollTrackers_doc},
 { "pollRemotes", eyelink_eyelink_poll_remotes,0x0001,pollRemotes_doc},
 { "pollResponses", eyelink_eyelink_poll_responses,0x0001,pollResponses_doc},

 { "quietMode", eyelink_eyelink_quiet_mode,0x0001,quietMode_doc},

 { "imageModeDisplay", eyelink_eyelink_image_mode_display,0x0001,imageModeDisplay_doc},
 { "targetModeDisplay", eyelink_eyelink_target_mode_display,0x0001,targetModeDisplay_doc},
 { "_getDataStatus", eyelink_eyelink_data_status,0x0001,_getDataStatus_doc},
 { "requestTime", eyelink_eyelink_request_time,0x0001,requestTime_doc},
 { "readTime", eyelink_eyelink_read_time,0x0001,readTime_doc},
 { "_drawCalTarget",eyelink_eyelink_map_eyelink_py_draw_cal_target_hook,0x0001,_drawCalTarget_doc},




 {"bitmapSaveAndBackdrop",eyelink_eyelink_bitmapSaveAndBackdrop,0x0001,"bitmapSaveAndBackdrop(iwidth,iheight,pixels,xs, ys, width,  height,fname,path, sv_options,xd,yd,  xferoptions)""iwidth  - original image width""iheight - original image height""pixels  - pixels of the image in the following format.pixel=[line1, line2, ... linen] line=[pix1,pix2,...,pixn],pix=(r,g,b) ""xs - crop x position""ys - crop y position""width - crop width""height - crop height""fname - file name to save""path -  path to save""svoptions - save options(SV_NOREPLACE,SV_MAKEPATH)""xd - xposition - transfer""yd - yposition - transfer""xferoptions - transfer options(BX_AVERAGE,BX_DARKEN,BX_LIGHTEN,BX_MAXCONTRAST,BX_NODITHER,BX_GRAYSCALE)"},
 {"bitmapBackdrop",eyelink_eyelink_bitmapBackdrop,0x0001,"bitmapBackdrop(iwidth,iheight,pixels,xs, ys, width,  height,xd,yd,  xferoptions)""iwidth  - original image width""iheight - original image height""pixels  - pixels of the image in the following format.pixel=[line1, line2, ... linen] line=[pix1,pix2,...,pixn],pix=(r,g,b) ""xs - crop x position""ys - crop y position""width - crop width""height - crop height""xd - xposition - transfer""yd - yposition - transfer""xferoptions - transfer options(BX_AVERAGE,BX_DARKEN,BX_LIGHTEN,BX_MAXCONTRAST,BX_NODITHER,BX_GRAYSCALE)"},






    {((void *)0), ((void *)0), 0, ((void *)0)}
};


static PyTypeObject EyelinkTrackerType = {
    1, ((void *)0),
    0,
    "EyeLinkCBind",
    sizeof(EyelinkTrackerObject),
    0,
    eyelink_dealloc,
    0,
    eyelink_getattr,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
 0,
 0,
 0,
 0,
 0,
 ( (1L<<0) | (1L<<1) | (1L<<3) | (1L<<5) | (1L<<6) | (1L<<7) | (1L<<8) | 0 | (1L<<17) | 0) | (1L<<10) | (1L<<4),
 "EyeLinkCBind",
 0,
 0,
 0,
 0,
 0,
 0,
 eyeTrackerType_methods,
 0,
 0,
 0,
 0,
 0,
 0,
 0,
 0,
 0,
 Eyelink__new__,

};



void getTrackerModule()
{

  static int moduleLoad = 0;

  if(2 >= 2 && 7 >=6)
   trackerModule = PyImport_ImportModule("pylink.tracker");
  else
   trackerModule = PyImport_ImportModule("tracker");


  if(!trackerModule)
  {
   if(moduleLoad)
    {
     printf("PyLink: Could not load module tracker!.\n");
     exit(1);
    }
   else
   {
    moduleLoad = 1;
    printf("PyLink: Could not load module tracker! delaying module loading.\n");
    return;
   }

  }

  {
   newSample = PyDict_GetItemString(PyModule_GetDict(trackerModule),"newSample");
   newStartBlinkEvent = PyDict_GetItemString(PyModule_GetDict(trackerModule),"newStartBlinkEvent");
   newEndBlinkEvent = PyDict_GetItemString(PyModule_GetDict(trackerModule),"newEndBlinkEvent");
   newStartSacadeEvent = PyDict_GetItemString(PyModule_GetDict(trackerModule),"newStartSaccadeEvent");
   newEndSacadeEvent = PyDict_GetItemString(PyModule_GetDict(trackerModule),"newEndSaccadeEvent");
   newStartFixationEvent = PyDict_GetItemString(PyModule_GetDict(trackerModule),"newStartFixationEvent");
   newEndFixationEvent = PyDict_GetItemString(PyModule_GetDict(trackerModule),"newEndFixationEvent");
   newFixUpdateEvent = PyDict_GetItemString(PyModule_GetDict(trackerModule),"newFixUpdateEvent");
   newDisplayInfo = PyDict_GetItemString(PyModule_GetDict(trackerModule),"newDisplayInfo");
   updatePerTrialDynamic = PyDict_GetItemString(PyModule_GetDict(trackerModule),"_updatePerTrialDynamic");
   updateBooleanFlags = PyDict_GetItemString(PyModule_GetDict(trackerModule),"_updateBooleanFlags");
   updateTimeStamps = PyDict_GetItemString(PyModule_GetDict(trackerModule),"_updateTimeStamps");
   updateStatusFlags = PyDict_GetItemString(PyModule_GetDict(trackerModule),"_updateStatusFlags");
   updateTypeFlags = PyDict_GetItemString(PyModule_GetDict(trackerModule),"_updateTypeFlags");
   updateSampleEventData = PyDict_GetItemString(PyModule_GetDict(trackerModule),"_updateSampleEventData");
   updateNetworkData = PyDict_GetItemString(PyModule_GetDict(trackerModule),"_updateNetworkData");
   updateAddresses = PyDict_GetItemString(PyModule_GetDict(trackerModule),"_updateAddresses");
   updateReserved = PyDict_GetItemString(PyModule_GetDict(trackerModule),"_updateReserved");
   drawCalTarget = PyDict_GetItemString(PyModule_GetDict(trackerModule),"drawCalTarget");
# 2224 "csrc/eyelinkmodule.c"
   newIOEvent = PyDict_GetItemString(PyModule_GetDict(trackerModule),"newIOEvent");
   newMessageEvent = PyDict_GetItemString(PyModule_GetDict(trackerModule),"newMessageEvent");
   EyelinkMessage = PyDict_GetItemString(PyModule_GetDict(trackerModule),"EyelinkMessage");


   if(
    !newSample ||
    !newStartBlinkEvent ||
    !newEndBlinkEvent ||
    !newStartSacadeEvent||
    !newEndSacadeEvent ||
    !newStartFixationEvent ||
    !newEndFixationEvent ||
    !newIOEvent ||
    !newMessageEvent ||
    !newFixUpdateEvent ||
    !newDisplayInfo ||
    !updatePerTrialDynamic ||
    !updateBooleanFlags ||
    !updateTimeStamps ||
    !updateStatusFlags ||
    !updateTypeFlags ||
    !updateSampleEventData ||
    !updateNetworkData ||
    !updateAddresses ||
    !updateReserved||
    !EyelinkMessage||
    !drawCalTarget)
    {
     printf("Error: one of the required attribute not found in module pylink\n");
     exit(-1);
    }


 }
}

void initpylink(void)
{
 PyObject *apiobj = ((void *)0);
 static void* c_api[1];
 PyObject *dict = ((void *)0);
 PyObject *thismodule = ((void *)0);
    EyelinkTrackerType.ob_type = &PyType_Type;
    thismodule = Py_InitModule4("pylink", eyelink_module_methods, "Eyelink tracker python interface", (PyObject *)((void *)0), 1013);
    dict = PyModule_GetDict(thismodule);


 PyDict_SetItemString(dict, "EyeLinkType", (PyObject *)&EyelinkTrackerType);
 PyDict_SetItemString(dict, "EyeLinkCBind", (PyObject *)&EyelinkTrackerType);


 c_api[0] = &EyelinkTrackerType;
 apiobj = PyCObject_FromVoidPtr(c_api, ((void *)0));
 PyDict_SetItemString(dict, "_PYGAME_C_API", apiobj);
 do { if ( --((PyObject*)(apiobj))->ob_refcnt != 0) ; else ( (*(((PyObject*)((PyObject *)(apiobj)))->ob_type)->tp_dealloc)((PyObject *)((PyObject *)(apiobj)))); } while (0);

 if(eyelink_reset_clock(1)!=0)
    {
      alert_printf("Cannot initialize link: Check network and TCP/IP setup");
      exit(1);
    }
 getTrackerModule();
}
static void eyelink_dealloc(PyObject* self)
{

}
static PyObject *eyelink_getattr(PyObject *obj, char *name)
{
 return Py_FindMethod(eyeTrackerType_methods, (PyObject *)obj, name);
}
static int eyelink_setattr(PyObject *obj, char *name, PyObject *v)
{
    return -1;
}


INT16 text_to_elinkaddr(char *addr, ELINKADDR node, int remote);
# 2312 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_set_name(PyObject* self, PyObject* args)
{
 char *str = ((void *)0);
 if (PyArg_ParseTuple(args,"s",&str))
 {
  eyelink_set_name(str);
  return Py_BuildValue("");
 }
 return ((void *)0);
}
# 2334 "csrc/eyelinkmodule.c"
void printELINKADDR(ELINKADDR addr)
{
 int i =0;
 printf(" address is ");
 for(i =0; i < 16; i ++)
 {
  printf("%x ", ((char *)addr)[i] &0x000000ff);
 }
 printf("\n");
}



void * toELINKADDR(PyObject *addr, ELINKADDR node)
{
 PyObject *getIP = PyObject_GetAttrString(addr,"getIP");
 PyObject *getPort = PyObject_GetAttrString(addr,"getPort");

 if(!getIP || !getPort)
  {
   PyErr_Format(PyExc_TypeError, "Given object is not an instance of EyeLinkAddress");
   return ((void *)0);
  }
 {
  long pt =0;
  PyObject * ip = PyObject_CallFunction(getIP,"");
  PyObject * port = PyObject_CallFunction(getPort,"");
  if(!ip || !port)
   return ((void *)0);

  memset(node, 0,sizeof(ELINKADDR));
  ((char *)node)[0] = (char)PyInt_AsLong(PyTuple_GetItem(ip,0));
  ((char *)node)[1] = (char)PyInt_AsLong(PyTuple_GetItem(ip,1));
  ((char *)node)[2] = (char)PyInt_AsLong(PyTuple_GetItem(ip,2));
  ((char *)node)[3] = (char)PyInt_AsLong(PyTuple_GetItem(ip,3));
  pt = PyInt_AsLong(port);
  memcpy(((char *)node) + 4, &pt,2);
 }

 return "";
}
# 2388 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_node_send(PyObject* self, PyObject* args)
{
 PyObject *addr = ((void *)0);
 char * data = ((void *)0);
 unsigned short len = 0;
 if (PyArg_ParseTuple(args,"Os#", &addr, &data,&len))
 {
  ELINKADDR node;
  int rv = 0;
  if(toELINKADDR(addr,node))
  {
   rv = eyelink_node_send(node,data,len);
   { char *rvm = eyelink_get_error(rv, "eyelink_node_send"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); return ((void *)0); };
  }
 }
 return ((void *)0);
}
# 2415 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_timed_commandEx(PyObject* self, PyObject* args)
{
 char * cmd = ((void *)0);
 unsigned int dur = 0;
 if (PyArg_ParseTuple(args,"is",&dur, &cmd))
 {
  int rv = 0;
  char *rvm = ((void *)0);
  if(strlen(cmd) > 129)
  {
   PyErr_Format(PyExc_RuntimeError, "Command too long: %s", cmd);
   return ((void *)0);
  }

  rv =eyelink_timed_command(dur,cmd);
  rvm = eyelink_get_error(rv, "eyelink_timed_command");
  if(!rvm)
   rvm = "";
  return Py_BuildValue("[is]", rv,rvm);
 }
 return ((void *)0);
}
# 2445 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_timed_command(PyObject* self, PyObject* args)
{
 char * cmd = ((void *)0);
 unsigned int dur = 0;
 if (PyArg_ParseTuple(args,"is",&dur, &cmd))
 {
  int rv = 0;
  if(strlen(cmd) > 129)
  {
   PyErr_Format(PyExc_RuntimeError, "Command too long: %s", cmd);
   return ((void *)0);
  }

  rv = eyelink_timed_command(dur,cmd);
  { char *rvm = eyelink_get_error(rv, "eyelink_command_result"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); return ((void *)0); };
 }
 return ((void *)0);
}
# 2476 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_node_send_message(PyObject* self, PyObject* args)
{
 PyObject *addr = ((void *)0);
 char * msg = ((void *)0);
 if (PyArg_ParseTuple(args,"Os",&addr, &msg))
 {
  ELINKADDR node;
  int rv;
  if(toELINKADDR(addr,node))
  {
   rv = eyelink_node_send_message(node,msg);
   { char *rvm = eyelink_get_error(rv, "eyelink_node_send_message"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); return ((void *)0); };
  }
 }
 return ((void *)0);
}
# 2503 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_node_request_time(PyObject* self, PyObject* args)
{
 PyObject * addr= ((void *)0);
 if (PyArg_ParseTuple(args,"O",&addr))
 {
  int rv;
  ELINKADDR node;
  if(toELINKADDR(addr,node))
  {
   rv = eyelink_node_request_time(node);
   { char *rvm = eyelink_get_error(rv, "eyelink_node_request_time"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); return ((void *)0); };
  }
 }
 return ((void *)0);
}
# 2531 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_get_node(PyObject* self, PyObject* args)
{
 short resp =0;
 if (PyArg_ParseTuple(args,"i",&resp))
 {
  int rv;
  ELINKNODE node;
  rv = eyelink_get_node(resp,&node);
  if(rv ==0)
  {
   short port =0;
   port = *(((char *)(node.addr))+5);
   port = port << 8;
   port = port| *(((char *)(node.addr))+4);
   return PyObject_CallFunction(EyelinkMessage,"((iiii),i,s)",((char *)(node.addr))[0],((char *)(node.addr))[1],((char *)(node.addr))[2],((char *)(node.addr))[3],port&0x0000ffff,node.name);
  }
  { char *rvm = eyelink_get_error(rv, "eyelink_get_node"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); return ((void *)0); };
 }
 return ((void *)0);
}
# 2561 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_node_receive(PyObject* self, PyObject* args)
{
 if (PyArg_ParseTuple(args,":node_receive"))
 {
  char data[256];
  ELINKADDR node;
  int rv = eyelink_node_receive(node,data);
  if(rv > 0)
  {
   short port =0;
   port = *(((char *)node)+5);
   port = port << 8;
   port = port| *(((char *)node)+4);
   return PyObject_CallFunction(EyelinkMessage,"((iiii),i,s)",((char *)node)[0],((char *)node)[1],((char *)node)[2],((char *)node)[3],port&0x0000ffff,data );
  }
  else
    return Py_BuildValue("");
 }
 return ((void *)0);
}
# 2594 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_open_node(PyObject* self, PyObject* args)
{
 short busytest=0;
 char * addr= ((void *)0);
 if (PyArg_ParseTuple(args,"si",&addr, &busytest))
 {
  int rv = 0;
  ELINKADDR node;
  text_to_elinkaddr(addr,node,0);
  rv = eyelink_open_node(node,busytest);
  { char *rvm = eyelink_get_error(rv, "eyelink_open_node"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); return ((void *)0); };
 }
 return ((void *)0);
}
# 2623 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_last_button_press(PyObject* self, PyObject* args)
{

 if (PyArg_ParseTuple(args,":"))
 {
  UINT32 time=0;
  int rv = eyelink_last_button_press(&time);
  return Py_BuildValue("ii",rv, time) ;
 }
 return ((void *)0);
}
# 2647 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_target_check(PyObject* self, PyObject* args)
{
 if (PyArg_ParseTuple(args,":"))
 {
  short x=0;
  short y=0;
  int rv = eyelink_target_check(&x, &y);
  return Py_BuildValue("iii",rv,x,y) ;
 }
 return ((void *)0);
}
# 2673 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_mode_data(PyObject* self, PyObject* args)
{
 if (PyArg_ParseTuple(args,":"))
 {
  INT16 sample_rate = -32768;
  INT16 crmode = -32768;
  INT16 file_filter = -32768;
  INT16 link_filter = -32768;



        int rv = eyelink2_mode_data(&sample_rate, &crmode, &file_filter, &link_filter);

  if(rv == -1)
  {
   sample_rate = -32768;
   crmode = -32768;
   file_filter = -32768;
   link_filter = -32768;
  }
  return Py_BuildValue("iiiii",rv,sample_rate, crmode, file_filter, link_filter) ;
 }
 return ((void *)0);
}
# 2712 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_read_keybutton(PyObject* self, PyObject* args)
{
 if (PyArg_ParseTuple(args,":"))
 {
  INT16 sample_rate;
  INT16 crmode;
  INT16 file_filter;
  UINT32 link_filter;
  int rv = eyelink_read_keybutton(&sample_rate, &crmode, &file_filter, &link_filter);
  return Py_BuildValue("iiiii",rv,sample_rate, crmode, file_filter, link_filter) ;
 }
 return ((void *)0);
}

static PyObject* eyelink_eyelink_open_eyelink_system(PyObject* self, PyObject* args)
{
 int sz =0;
 if (PyArg_ParseTuple(args,"i",&sz))
 {
  int rv = open_eyelink_system(sz,((void *)0));
  { char *rvm = eyelink_get_error(rv, "open_eyelink_system"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); return ((void *)0); };
 }
 return ((void *)0);
}
static PyObject* eyelink_eyelink_data_status(PyObject* self, PyObject* args)
{
 PyObject *trackerInfo = ((void *)0);
 if (PyArg_ParseTuple(args,"O:_getDataStatus",&trackerInfo))
 {
  ILINKDATA *data = eyelink_data_status();
  if(data)
  {
   PyObject_CallFunction(updatePerTrialDynamic,"O(iiiiiiiii)",trackerInfo,
        data->samrate,data->samdiv,
        data->prescaler,data->vprescaler,
        data->pprescaler,data->hprescaler,
        data->sample_data,data->event_data,
        data->event_types);


   PyObject_CallFunction(updateBooleanFlags,"O(iiiiiiii)",trackerInfo,
        data->in_sample_block,data->in_event_block,
        data->have_left_eye,data->have_right_eye,
        data->samples_on,data->events_on,
        data->control_read, data->first_in_block);


   PyObject_CallFunction(updateTimeStamps,"O(iii)",trackerInfo,
        data->time,data->last_data_item_time,
        data->last_rcve_time);


   PyObject_CallFunction(updateStatusFlags,"O(iiiiii)",trackerInfo,
        data->last_status,data->packet_flags,
        data->link_flags,data->state_flags,
        data->link_dstatus, data->link_pendcmd);


   PyObject_CallFunction(updateTypeFlags,"O(iii)",trackerInfo,
        data->last_data_gap_types,
        data->last_data_buffer_type,
        data->last_data_item_type);


   PyObject_CallFunction(updateReserved,"Oi",trackerInfo,data->reserved);
# 2792 "csrc/eyelinkmodule.c"
   return Py_BuildValue("") ;


  }
  else
   PyErr_Format(PyExc_RuntimeError,"Could not collect data status.");

 }
 return ((void *)0);
}




static void getDisplayConfiguration(int *width, int *height)
{
 PyObject *srgraphics = ((void *)0);
 *width = 640;
 *height = 480;


 srgraphics = PyImport_ImportModule("srgraphics_c");
 if(srgraphics)
 {
  PyObject *display = ((void *)0);
  PyObject * getDisplay = PyDict_GetItemString(PyModule_GetDict(srgraphics),"getDisplay");
  if(getDisplay)
   display = PyObject_CallFunction(getDisplay,"");
  if(display)
  {
   PyObject *w = ((void *)0);
   PyObject *h = ((void *)0);
   w = PyObject_GetAttrString(display,"width");
   h = PyObject_GetAttrString(display,"height");
   if(w&&h)
   {
    *width = PyLong_AsLong(w);
    *height =PyLong_AsLong(h);
   }
  }
 }
 PyErr_Clear();
}
static PyObject* PyEyelink_New(PyTypeObject *type)
{
 PyObject *self;
 self = type->tp_alloc(type, 0);
 return self;
}
# 2856 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_open(PyObject* self, PyObject* args)
{
 char *addr = "100.1.1.1";
 short busytest = 0;
 if (PyArg_ParseTuple(args,"|si",&addr, &busytest))
  {
   int rv = 0;







   ELINKADDR node;
   text_to_elinkaddr(addr,node,0);
   rv = eyelink_open_node(node,busytest);

   if(rv==0)
   {
                return Py_BuildValue("") ;
   }
   else
    PyErr_Format(PyExc_RuntimeError, "Could not connect to tracker at %s", addr);
    return ((void *)0);
  }
  return ((void *)0);
}
static PyObject* Eyelink__new__(PyTypeObject *type, PyObject *args, PyObject *kwds)
{


 if(PyErr_Occurred())
   {
   PyErr_Print();
 }

 if(open_eyelink_connection(-1) == 0)
  return PyEyelink_New(type);
 else
  {
   PyErr_Format(PyExc_RuntimeError, "eyelink_core initialization failed ");
   return ((void *)0);
  }
}
# 3217 "csrc/eyelinkmodule.c"
static struct _DISPFCNS
{
 HOOKFCNS hfcns;
 PyObject *self;
}dispfcns;

static PyObject* eyelink_eyelink_map_eyelink_py_draw_cal_target_hook(PyObject* self, PyObject* args)
{
 INT16 x =0;
 INT16 y =0;
 if(PyArg_ParseTuple(args,"(hh):drawCalTarget", &x, &y))
  {
                         if(dispfcns.hfcns.draw_cal_target_hook)
    dispfcns.hfcns.draw_cal_target_hook(x, y);
    return Py_BuildValue("") ;
  }
 return ((void *)0);
}


void eyelink_py_draw_cal_target_hook(INT16 x, INT16 y)
{
 if(PyErr_Occurred())
 {
  PyErr_Print();
 }

 PyObject_CallFunction(drawCalTarget,"ii",x, y);

        if(PyErr_Occurred())
 {
                printf("except found \n");
  PyErr_Print();
  exit(1);
 }

}


void setup_remap_hooks(PyObject *self)
{
 HOOKFCNS *hooks = get_all_hook_functions();
 memset(&(dispfcns.hfcns),0,sizeof(HOOKFCNS));
 memcpy(&(dispfcns.hfcns),hooks,sizeof(HOOKFCNS));
 dispfcns.self = self;
 hooks->draw_cal_target_hook = eyelink_py_draw_cal_target_hook;
    setup_graphic_hook_functions(hooks);
}
# 3480 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_eyemsg_printf(PyObject* self, PyObject* args)
{
 char *text=((void *)0);
 int offset =0;
 if (PyArg_ParseTuple(args,"s|i",&text, &offset))
 {
  char *rvm = ((void *)0);
  int rv =0;
  char *rtn = malloc(strlen(text)+1);
  if(rtn)
  {
                        strcpy(rtn,text);
   if(strlen(rtn)>130)
    rtn[129]=0;
   rv = eyelink_send_message_ex(offset, rtn);
   free(rtn);
   rvm = eyelink_get_error(rv, "eyelink_send_message_ex");
   if(!rvm || !strlen(rvm) || rv == 1000)
    return Py_BuildValue("i",rv);
   else
    PyErr_Format(PyExc_RuntimeError, "%s", rvm);
  }

 }
        return ((void *)0);
}
static PyObject* eyelink_eyelink_timemsg_printf(PyObject* self, PyObject* args)
{
 char *text=((void *)0);
 int offset =0;
 if (PyArg_ParseTuple(args,"s|i",&text, &offset))
 {
  char *rvm = ((void *)0);
  int rv =0;
  char *rtn = malloc(strlen(text)+1);
  if(rtn)
  {
                        strcpy(rtn,text);
   if(strlen(rtn)>130)
    rtn[129]=0;
   rv = timemsg_printf(offset, rtn);
   free(rtn);
   rvm = eyelink_get_error(rv, "timemsg_printf");
   if(!rvm || !strlen(rvm) || rv == 1000)
    return Py_BuildValue("i",rv);
   else
    PyErr_Format(PyExc_RuntimeError, "%s", rvm);
  }

 }
        return ((void *)0);
}


static PyObject* eyelink_eyelink_receiveDataFile(PyObject* self, PyObject* args)
{
 char *src = ((void *)0);
 char *dest = ((void *)0);
 if (PyArg_ParseTuple(args,"ss",&src,&dest))
 {
                int rv =0;
  receive_data_file(src, dest, 0);
  { char *rvm = eyelink_get_error(rv, "receive_data_file"); if(!rvm || !strlen(rvm)) return Py_BuildValue("i",rv); else PyErr_Format(PyExc_RuntimeError, "%s", rvm); return ((void *)0); };
 }
 return ((void *)0);

}
# 3581 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_bitmapSaveAndBackdrop(PyObject* self, PyObject* args)
{
 PyObject *pixels = ((void *)0);
 int xs;
 int ys;
 int width;
 int height;
 int sv_options;
 int xd;
 int yd;
 int xferoptions;
        int imgwidth;
 int imgheight;
 char *fname=((void *)0);
 char *path = ((void *)0);
# 3604 "csrc/eyelinkmodule.c"
 if (PyArg_ParseTuple(args,"iiOiiiissiiii",&imgwidth, &imgheight, &pixels, &xs, &ys,&width, &height,&fname, &path, &sv_options,&xd,&yd,&xferoptions))
        {


  {
   char *pix;
   int x,y;
   EYEBITMAP *dst = malloc(sizeof(EYEBITMAP));
   memset(dst,0,sizeof(EYEBITMAP));
   dst->w= imgwidth;
   dst->h = imgheight;
   dst->pixels = malloc(dst->w*4*dst->h);
   pix = dst->pixels;
   for(y =0; y <dst->h; y++)
   {
    PyObject *line = PyList_GetItem(pixels,y);
    for(x =0; x <dst->w; x++)
    {
     PyObject *item = PyList_GetItem(line,x);
     int r = PyInt_AsLong(PyTuple_GetItem(item,0));
     int g = PyInt_AsLong(PyTuple_GetItem(item,1));
     int b = PyInt_AsLong(PyTuple_GetItem(item,2));






                                        *(pix++)=0;
     *(pix++)=r;
     *(pix++)=g;
     *(pix++)=b;

    }
   }

   dst->depth = 32;
   dst->pitch = dst->w*4;

   dst->format = malloc(sizeof(EYEPIXELFORMAT));
   memset(dst->format,0,sizeof(EYEPIXELFORMAT));
   el_bitmap_save_and_backdrop(dst,(INT16)xs,(INT16)ys,(INT16)width,(INT16)height,fname,path,(UINT16)sv_options, (INT16)xd,(INT16)yd,(UINT16)xferoptions);
  }

  return Py_BuildValue("");
 }
 return ((void *)0);
}
# 3671 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_bitmapSave(PyObject* self, PyObject* args)
{
 PyObject *pixels = ((void *)0);
 int xs;
 int ys;
 int width;
 int height;
 int sv_options;
        int imgwidth;
 int imgheight;

 char *fname=((void *)0);
 char *path = ((void *)0);
# 3693 "csrc/eyelinkmodule.c"
 if (PyArg_ParseTuple(args,"iiOiiiissi",&imgwidth, &imgheight, &pixels, &xs, &ys,&width, &height,&fname,&path, &sv_options))
 {


  {
   char *pix;
   int x,y;
   EYEBITMAP *dst = malloc(sizeof(EYEBITMAP));
   memset(dst,0,sizeof(EYEBITMAP));
   dst->w= imgwidth;
   dst->h = imgheight;
   dst->pixels = malloc(dst->w*4*dst->h);
   pix = dst->pixels;
   for(y =0; y <dst->h; y++)
   {
    PyObject *line = PyList_GetItem(pixels,y);
    for(x =0; x <dst->w; x++)
    {
     PyObject *item = PyList_GetItem(line,x);
     int r = PyInt_AsLong(PyTuple_GetItem(item,0));
     int g = PyInt_AsLong(PyTuple_GetItem(item,1));
     int b = PyInt_AsLong(PyTuple_GetItem(item,2));
     *(pix++)=b;
     *(pix++)=g;
     *(pix++)=r;
     *(pix++)=0;
    }
   }

   dst->depth = 32;
   dst->pitch = dst->w*4;

   dst->format = malloc(sizeof(EYEPIXELFORMAT));
   memset(dst->format,0,sizeof(EYEPIXELFORMAT));
   dst->format->Rmask = 0x0000ff00;
   dst->format->Gmask = 0x00ff0000;
   dst->format->Bmask = 0xff000000;
   dst->format->Amask = 0x000000ff;
   el_bitmap_save(dst,(INT16)xs,(INT16)ys,(INT16)width,(INT16)height,fname,path,(UINT16)sv_options);
  }

  return Py_BuildValue("");
 }
 return ((void *)0);
}
# 3790 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_bitmapBackdrop(PyObject* self, PyObject* args)
{
 PyObject *pixels = ((void *)0);
 int xs;
 int ys;
 int width;
 int height;
 int xd;
 int yd;
 int xferoptions;

 int imgwidth;
 int imgheight;
 if (PyArg_ParseTuple(args,"iiOiiiiiii",&imgwidth, &imgheight, &pixels, &xs, &ys,&width, &height,&xd,&yd,&xferoptions))
 {
  {
   char *pix;
   int x,y;
   EYEBITMAP *dst = malloc(sizeof(EYEBITMAP));
   memset(dst,0,sizeof(EYEBITMAP));
   dst->w= imgwidth;
   dst->h = imgheight;
   dst->pixels = malloc(dst->w*4*dst->h);
   pix = dst->pixels;
   for(y =0; y <dst->h; y++)
   {
    PyObject *line = PyList_GetItem(pixels,y);
    for(x =0; x <dst->w; x++)
    {
     PyObject *item = PyList_GetItem(line,x);
     int r = PyInt_AsLong(PyTuple_GetItem(item,0));
     int g = PyInt_AsLong(PyTuple_GetItem(item,1));
     int b = PyInt_AsLong(PyTuple_GetItem(item,2));
     *(pix++)=b;
     *(pix++)=g;
     *(pix++)=r;
     *(pix++)=0;
    }
   }

   dst->depth = 32;
   dst->pitch = dst->w*4;

   dst->format = malloc(sizeof(EYEPIXELFORMAT));
   memset(dst->format,0,sizeof(EYEPIXELFORMAT));
   el_bitmap_to_backdrop(dst,(INT16)xs,(INT16)ys,(INT16)width,(INT16)height, (INT16)xd,(INT16)yd,(UINT16)xferoptions);
  }

  return Py_BuildValue("");
 }
 return ((void *)0);
}
# 3990 "csrc/eyelinkmodule.c"
static PyObject* eyelink_eyelink_eyelink_last_button_states(PyObject* self, PyObject* args)
{
 if (PyArg_ParseTuple(args,":"))
 {
  UINT32 time =0;
  UINT16 state = eyelink_last_button_states(&time);
  if(state)
   return Py_BuildValue("(iiiiiiiii)",time,
    state & 0x01,
    (state & 0x02) >> 1,
    (state & 0x04) >> 2,
    (state & 0x08) >> 3,
    (state & 0x10) >> 4,
    (state & 0x20) >> 5,
    (state & 0x40) >> 6,
    (state & 0x80) >> 7
  );
  else
   return Py_BuildValue("O",(&_Py_NoneStruct));

 }
 return ((void *)0);
}
